/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 81: Write a program using an unnamed pipe to send data
 *              from parent to child.
 *
 * Concept: Pipe system call, IPC data exchange between related processes
 *
 * Compilation:
 *   gcc -Wall -O2 q81_unnamed_pipe_data_parent_to_child.c -o q81_unnamed_pipe_data_parent_to_child
 *
 * Execution:
 *   ./q81_unnamed_pipe_data_parent_to_child
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

#define BUFFER_SIZE 256

int main() {
    int pfd[2];
    pid_t pid;

    if (pipe(pfd) == -1) {
        perror("pipe error");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q81: Unnamed Pipe Data Transfer (Parent -> Child)          \n");
    printf("============================================================\n");

    pid = fork();
    if (pid < 0) {
        perror("fork error");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent process sends data
        close(pfd[0]); // Close read end

        char message[BUFFER_SIZE];
        printf("[Parent PID: %d] Enter message to send to child: ", getpid());
        if (fgets(message, sizeof(message), stdin) == NULL) {
            strcpy(message, "Hello Child, this data is sent via unnamed pipe!\n");
        }

        write(pfd[1], message, strlen(message) + 1);
        close(pfd[1]);

        wait(NULL);
        printf("[Parent PID: %d] Child done. Exiting.\n", getpid());
    } else {
        // Child process receives data
        close(pfd[1]); // Close write end

        char received[BUFFER_SIZE];
        ssize_t n = read(pfd[0], received, sizeof(received));
        if (n > 0) {
            printf("[Child PID: %d] Received data from parent: %s", getpid(), received);
        }
        close(pfd[0]);
        exit(EXIT_SUCCESS);
    }

    return 0;
}
