/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 2: Implement a program using named pipe (FIFO) to allow one process
 *             to send input text and another process to receive and display it.
 *             [PART 1: FIFO SENDER PROCESS]
 *
 * Concept: Named Pipe (mkfifo system call), open, write
 *
 * Compilation:
 *   gcc -Wall -O2 q02_fifo_sender.c -o q02_fifo_sender
 *
 * Execution:
 *   Terminal 1: ./q02_fifo_receiver
 *   Terminal 2: ./q02_fifo_sender
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>

#define FIFO_PATH "/tmp/uos_q02_demo_fifo"
#define BUFFER_SIZE 512

int main() {
    int fd;
    char buffer[BUFFER_SIZE];

    // Create named pipe if it doesn't already exist
    if (mkfifo(FIFO_PATH, 0666) == -1) {
        // File exists error (EEXIST) is acceptable
    }

    printf("============================================================\n");
    printf(" Q02: Named Pipe (FIFO) - Sender Process                    \n");
    printf(" FIFO Path: %s\n", FIFO_PATH);
    printf(" Type text and press Enter (type 'exit' to quit)            \n");
    printf("============================================================\n");

    printf("[Sender] Opening FIFO for writing (blocks until receiver opens)...\n");
    fd = open(FIFO_PATH, O_WRONLY);
    if (fd == -1) {
        perror("[Sender] Failed to open FIFO");
        exit(EXIT_FAILURE);
    }
    printf("[Sender] FIFO opened successfully! Start typing:\n");

    while (1) {
        printf("Sender > ");
        if (fgets(buffer, BUFFER_SIZE, stdin) == NULL) {
            break;
        }

        // Strip trailing newline if desired
        buffer[strcspn(buffer, "\r\n")] = '\0';

        write(fd, buffer, strlen(buffer) + 1);

        if (strcmp(buffer, "exit") == 0) {
            printf("[Sender] Exiting...\n");
            break;
        }
    }

    close(fd);
    return 0;
}
