/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 2: Implement a program using named pipe (FIFO) to allow one process
 *             to send input text and another process to receive and display it.
 *             [All-in-one demo using fork()]
 *
 * Compilation:
 *   gcc -Wall -O2 q02_named_pipe_fifo_combined_demo.c -o q02_named_pipe_fifo_combined_demo
 *
 * Execution:
 *   ./q02_named_pipe_fifo_combined_demo
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <string.h>

#define FIFO_NAME "/tmp/uos_q02_combined_fifo"
#define BUFFER_SIZE 256

int main() {
    pid_t pid;

    // Create FIFO
    unlink(FIFO_NAME);
    if (mkfifo(FIFO_NAME, 0666) == -1) {
        perror("mkfifo error");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q02: Named Pipe (FIFO) Combined Fork Demo                 \n");
    printf("============================================================\n");

    pid = fork();
    if (pid < 0) {
        perror("fork error");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {
        // Child: Receiver
        int rfd = open(FIFO_NAME, O_RDONLY);
        if (rfd < 0) {
            perror("[Child-Receiver] open failed");
            exit(EXIT_FAILURE);
        }
        char msg[BUFFER_SIZE];
        ssize_t n = read(rfd, msg, sizeof(msg) - 1);
        if (n > 0) {
            msg[n] = '\0';
            printf("[Child-Receiver] Received from FIFO: \"%s\"\n", msg);
        }
        close(rfd);
        exit(EXIT_SUCCESS);
    } else {
        // Parent: Sender
        int wfd = open(FIFO_NAME, O_WRONLY);
        if (wfd < 0) {
            perror("[Parent-Sender] open failed");
            exit(EXIT_FAILURE);
        }
        const char *data = "Hello from Parent via Named Pipe FIFO!";
        printf("[Parent-Sender] Sending: \"%s\"\n", data);
        write(wfd, data, strlen(data));
        close(wfd);

        wait(NULL);
        unlink(FIFO_NAME);
        printf("[Parent-Sender] Cleaned up FIFO and finished.\n");
    }

    return 0;
}
