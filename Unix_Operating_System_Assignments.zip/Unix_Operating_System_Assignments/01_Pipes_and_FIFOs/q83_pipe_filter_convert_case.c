/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 83: Write a program using a pipe that acts as a filter to convert
 *              uppercase text to lowercase (reading from a command or a file).
 *
 * Concept: Pipe filter, standard I/O redirection (dup2), exec(), character case transformation
 *
 * Compilation:
 *   gcc -Wall -O2 q83_pipe_filter_convert_case.c -o q83_pipe_filter_convert_case
 *
 * Execution:
 *   ./q83_pipe_filter_convert_case [optional_input_file]
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <string.h>

#define BUFFER_SIZE 512

int main(int argc, char *argv[]) {
    int pfd[2];
    pid_t pid;

    if (pipe(pfd) == -1) {
        perror("pipe error");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q83: Pipe Filter Converting Uppercase to Lowercase         \n");
    printf("============================================================\n");

    pid = fork();
    if (pid < 0) {
        perror("fork error");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent: Provides input to the pipe filter (either from file or user/demo input)
        close(pfd[0]); // Close read end

        if (argc > 1) {
            // Read from specified file
            printf("[Parent] Reading input from file '%s'...\n", argv[1]);
            int ffd = open(argv[1], O_RDONLY);
            if (ffd >= 0) {
                char buf[BUFFER_SIZE];
                ssize_t n;
                while ((n = read(ffd, buf, sizeof(buf))) > 0) {
                    write(pfd[1], buf, n);
                }
                close(ffd);
            } else {
                perror("[Parent] Cannot open file");
            }
        } else {
            // Interactive or demo string
            const char *sample = "THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG.\n"
                                 "WELCOME TO UNIX OPERATING SYSTEM PRACTICAL EXAM 2026.\n";
            printf("[Parent] Sending sample UPPERCASE text into filter:\n%s\n", sample);
            write(pfd[1], sample, strlen(sample));
        }

        close(pfd[1]); // Signal EOF to child filter
        wait(NULL);
        printf("[Parent] Filter processing completed.\n");
    } else {
        // Child: Acts as the filter, reads from pipe, converts to lowercase, outputs to stdout
        close(pfd[1]); // Close write end

        printf("[Child Filter] Transformed Lowercase Stream Output:\n");
        printf("------------------------------------------------------------\n");

        char ch;
        while (read(pfd[0], &ch, 1) > 0) {
            putchar(tolower((unsigned char)ch));
        }

        printf("------------------------------------------------------------\n");
        close(pfd[0]);
        exit(EXIT_SUCCESS);
    }

    return 0;
}
