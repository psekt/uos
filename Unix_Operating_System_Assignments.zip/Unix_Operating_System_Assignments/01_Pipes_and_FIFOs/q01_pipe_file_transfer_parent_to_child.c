/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 1: Write a program to transfer the contents of a file from the parent
 *             process to the child process using an unnamed pipe.
 *
 * Concept: Unnamed Pipe (pipe system call), fork(), file I/O (open, read, write)
 *
 * Compilation:
 *   gcc -Wall -O2 q01_pipe_file_transfer_parent_to_child.c -o q01_pipe_file_transfer_parent_to_child
 *
 * Execution:
 *   ./q01_pipe_file_transfer_parent_to_child [filename]
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <string.h>

#define BUFFER_SIZE 512

int main(int argc, char *argv[]) {
    int pipefd[2];
    pid_t pid;
    char buffer[BUFFER_SIZE];
    ssize_t bytes_read, bytes_written;

    const char *filename = (argc > 1) ? argv[1] : "sample_source.txt";

    // Create a dummy sample file if user did not specify one and it doesn't exist
    int test_fd = open(filename, O_RDONLY);
    if (test_fd < 0) {
        printf("[Setup] Creating a demo sample file: %s\n", filename);
        int create_fd = open(filename, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (create_fd >= 0) {
            const char *demo_text = "Hello from Unix Operating System!\nThis file content was transferred via an unnamed pipe.\nParent sent it and Child received it successfully.\n";
            write(create_fd, demo_text, strlen(demo_text));
            close(create_fd);
        }
    } else {
        close(test_fd);
    }

    // Step 1: Create unnamed pipe
    if (pipe(pipefd) == -1) {
        perror("pipe failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q01: Transfer File from Parent to Child via Unnamed Pipe   \n");
    printf(" Source File: %s\n", filename);
    printf("============================================================\n");

    // Step 2: Fork a child process
    pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // ------------------ PARENT PROCESS (Sender) ------------------
        // Close unused read end
        close(pipefd[0]);

        printf("[Parent PID: %d] Opening file '%s' to send to child...\n", getpid(), filename);
        int src_fd = open(filename, O_RDONLY);
        if (src_fd < 0) {
            perror("[Parent] Error opening source file");
            close(pipefd[1]);
            wait(NULL);
            exit(EXIT_FAILURE);
        }

        size_t total_sent = 0;
        while ((bytes_read = read(src_fd, buffer, sizeof(buffer))) > 0) {
            bytes_written = write(pipefd[1], buffer, bytes_read);
            if (bytes_written < 0) {
                perror("[Parent] Write error to pipe");
                break;
            }
            total_sent += bytes_written;
        }

        close(src_fd);
        close(pipefd[1]); // EOF to child
        printf("[Parent PID: %d] Finished sending %zu bytes. Waiting for child...\n", getpid(), total_sent);

        wait(NULL); // Wait for child to finish
        printf("[Parent PID: %d] Child process finished. Parent exiting.\n", getpid());
    } else {
        // ------------------ CHILD PROCESS (Receiver) ------------------
        // Close unused write end
        close(pipefd[1]);

        printf("[Child PID: %d] Reading contents transferred from parent via pipe:\n", getpid());
        printf("---------------------- FILE CONTENTS ----------------------\n");

        size_t total_received = 0;
        while ((bytes_read = read(pipefd[0], buffer, sizeof(buffer) - 1)) > 0) {
            buffer[bytes_read] = '\0';
            printf("%s", buffer);
            total_received += bytes_read;
        }

        if (bytes_read < 0) {
            perror("[Child] Read error from pipe");
        }

        printf("-----------------------------------------------------------\n");
        printf("[Child PID: %d] Reached EOF. Total received: %zu bytes.\n", getpid(), total_received);
        close(pipefd[0]);
        exit(EXIT_SUCCESS);
    }

    return 0;
}
