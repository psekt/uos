/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 3: Write a program using a pipe filter that converts text
 *             from uppercase to lowercase before printing.
 *
 * Concept: Unnamed Pipe filter, fork(), ctype.h tolower(), process chaining
 *
 * Compilation:
 *   gcc -Wall -O2 q03_pipe_filter_upper_to_lower.c -o q03_pipe_filter_upper_to_lower
 *
 * Execution:
 *   ./q03_pipe_filter_upper_to_lower
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>
#include <sys/wait.h>

#define BUFFER_SIZE 512

int main() {
    int pipefd[2];
    pid_t pid;

    if (pipe(pipefd) == -1) {
        perror("pipe creation failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q03: Pipe Filter: Uppercase to Lowercase Conversion        \n");
    printf("============================================================\n");

    pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // ------------------ PARENT (Producer / Filter Input) ------------------
        close(pipefd[0]); // Close read end

        char input[BUFFER_SIZE];
        printf("[Parent] Enter text containing UPPERCASE letters: ");
        if (fgets(input, sizeof(input), stdin) == NULL) {
            strcpy(input, "DEFAULT TEXT: UNIX OPERATING SYSTEM PIPE FILTER DEMO\n");
        }

        printf("[Parent] Sending original text into pipe:\n\"%s\"\n", input);
        write(pipefd[1], input, strlen(input));
        close(pipefd[1]); // Close to signal EOF

        wait(NULL); // Wait for child filter to complete
    } else {
        // ------------------ CHILD (Filter Process) ------------------
        close(pipefd[1]); // Close write end

        char ch;
        printf("[Child Filter] Receiving and converting characters to lowercase:\n");
        printf("-------------------- FILTERED OUTPUT --------------------\n");

        while (read(pipefd[0], &ch, 1) > 0) {
            putchar(tolower((unsigned char)ch));
        }

        printf("---------------------------------------------------------\n");
        close(pipefd[0]);
        exit(EXIT_SUCCESS);
    }

    return 0;
}
