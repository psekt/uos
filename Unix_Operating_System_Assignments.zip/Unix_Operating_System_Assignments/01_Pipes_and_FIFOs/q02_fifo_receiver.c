/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 2: Implement a program using named pipe (FIFO) to allow one process
 *             to send input text and another process to receive and display it.
 *             [PART 2: FIFO RECEIVER PROCESS]
 *
 * Concept: Named Pipe (mkfifo system call), open, read, display
 *
 * Compilation:
 *   gcc -Wall -O2 q02_fifo_receiver.c -o q02_fifo_receiver
 *
 * Execution:
 *   Terminal 1: ./q02_fifo_receiver
 *   Terminal 2: ./q02_fifo_sender
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>

#define FIFO_PATH "/tmp/uos_q02_demo_fifo"
#define BUFFER_SIZE 512

int main() {
    int fd;
    char buffer[BUFFER_SIZE];

    // Create named pipe if it doesn't already exist
    if (mkfifo(FIFO_PATH, 0666) == -1) {
        // EEXIST is fine
    }

    printf("============================================================\n");
    printf(" Q02: Named Pipe (FIFO) - Receiver Process                  \n");
    printf(" FIFO Path: %s\n", FIFO_PATH);
    printf(" Waiting for Sender to connect...                           \n");
    printf("============================================================\n");

    fd = open(FIFO_PATH, O_RDONLY);
    if (fd == -1) {
        perror("[Receiver] Failed to open FIFO");
        exit(EXIT_FAILURE);
    }
    printf("[Receiver] Connected to sender! Receiving messages:\n");

    while (1) {
        ssize_t bytes_read = read(fd, buffer, BUFFER_SIZE);
        if (bytes_read <= 0) {
            printf("[Receiver] Sender disconnected or EOF reached.\n");
            break;
        }

        if (strcmp(buffer, "exit") == 0) {
            printf("[Receiver] Received 'exit' command. Shutting down.\n");
            break;
        }

        printf("[Receiver] Message received: %s\n", buffer);
    }

    close(fd);
    unlink(FIFO_PATH); // Clean up FIFO file
    return 0;
}
