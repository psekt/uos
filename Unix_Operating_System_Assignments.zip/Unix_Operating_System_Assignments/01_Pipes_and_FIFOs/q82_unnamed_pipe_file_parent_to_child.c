/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 82: Write a program using an unnamed pipe to send a file
 *              from parent to child.
 *
 * Concept: File descriptors, streaming file through unnamed pipe, child saves output file
 *
 * Compilation:
 *   gcc -Wall -O2 q82_unnamed_pipe_file_parent_to_child.c -o q82_unnamed_pipe_file_parent_to_child
 *
 * Execution:
 *   ./q82_unnamed_pipe_file_parent_to_child [source_file] [dest_file]
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <string.h>

#define CHUNK_SIZE 1024

int main(int argc, char *argv[]) {
    int pfd[2];
    pid_t pid;
    const char *src_path = (argc > 1) ? argv[1] : "q82_input_demo.txt";
    const char *dst_path = (argc > 2) ? argv[2] : "q82_output_received.txt";

    // Auto-create sample input file if not present
    int test_fd = open(src_path, O_RDONLY);
    if (test_fd < 0) {
        int wfd = open(src_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (wfd >= 0) {
            const char *content = "UNIX OS Assignment - Q82 File Transfer Demonstration.\n"
                                  "Line 1: Operating System concepts.\n"
                                  "Line 2: Pipes are unidirectional byte streams.\n"
                                  "Line 3: File successfully transferred parent to child!\n";
            write(wfd, content, strlen(content));
            close(wfd);
        }
    } else {
        close(test_fd);
    }

    if (pipe(pfd) == -1) {
        perror("pipe error");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q82: Unnamed Pipe File Transfer Parent to Child            \n");
    printf(" Source File: %s  ->  Destination File: %s\n", src_path, dst_path);
    printf("============================================================\n");

    pid = fork();
    if (pid < 0) {
        perror("fork error");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent: Read source file and write into pipe
        close(pfd[0]);

        int sfd = open(src_path, O_RDONLY);
        if (sfd < 0) {
            perror("[Parent] Error opening source file");
            close(pfd[1]);
            wait(NULL);
            exit(EXIT_FAILURE);
        }

        char buffer[CHUNK_SIZE];
        ssize_t rbytes, wbytes;
        size_t total_sent = 0;

        while ((rbytes = read(sfd, buffer, sizeof(buffer))) > 0) {
            wbytes = write(pfd[1], buffer, rbytes);
            if (wbytes < 0) {
                perror("[Parent] Write error");
                break;
            }
            total_sent += wbytes;
        }

        close(sfd);
        close(pfd[1]);
        printf("[Parent] Transferred %zu bytes into pipe. Waiting for child...\n", total_sent);
        wait(NULL);
        printf("[Parent] File transfer completed successfully.\n");
    } else {
        // Child: Read from pipe and write to destination file
        close(pfd[1]);

        int dfd = open(dst_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (dfd < 0) {
            perror("[Child] Error creating destination file");
            close(pfd[0]);
            exit(EXIT_FAILURE);
        }

        char buffer[CHUNK_SIZE];
        ssize_t rbytes;
        size_t total_rcvd = 0;

        while ((rbytes = read(pfd[0], buffer, sizeof(buffer))) > 0) {
            write(dfd, buffer, rbytes);
            total_rcvd += rbytes;
        }

        close(dfd);
        close(pfd[0]);
        printf("[Child] Received %zu bytes from pipe and saved to '%s'.\n", total_rcvd, dst_path);
        exit(EXIT_SUCCESS);
    }

    return 0;
}
