/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 39: Write a program that reports file statistics using stat()
 *              (include important fields such as file access permissions,
 *              file type, etc.).
 *
 * Compilation:
 *   gcc -Wall -O2 q39_file_statistics_stat.c -o q39_file_statistics_stat
 *
 * Execution:
 *   ./q39_file_statistics_stat [filename_or_directory]
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>

void print_file_type(mode_t mode) {
    printf("File Type            : ");
    if (S_ISREG(mode))  printf("Regular File (-)\n");
    else if (S_ISDIR(mode))  printf("Directory (d)\n");
    else if (S_ISCHR(mode))  printf("Character Device (c)\n");
    else if (S_ISBLK(mode))  printf("Block Device (b)\n");
    else if (S_ISFIFO(mode)) printf("FIFO / Named Pipe (p)\n");
    else if (S_ISLNK(mode))  printf("Symbolic Link (l)\n");
    else if (S_ISSOCK(mode)) printf("Socket (s)\n");
    else                     printf("Unknown\n");
}

void print_permissions(mode_t mode) {
    char perms[10];
    perms[0] = (mode & S_IRUSR) ? 'r' : '-';
    perms[1] = (mode & S_IWUSR) ? 'w' : '-';
    perms[2] = (mode & S_IXUSR) ? 'x' : '-';
    perms[3] = (mode & S_IRGRP) ? 'r' : '-';
    perms[4] = (mode & S_IWGRP) ? 'w' : '-';
    perms[5] = (mode & S_IXGRP) ? 'x' : '-';
    perms[6] = (mode & S_IROTH) ? 'r' : '-';
    perms[7] = (mode & S_IWOTH) ? 'w' : '-';
    perms[8] = (mode & S_IXOTH) ? 'x' : '-';
    perms[9] = '\0';

    printf("Access Permissions   : %s (Octal: %04o)\n", perms, mode & 0777);
}

int main(int argc, char *argv[]) {
    const char *path = (argc > 1) ? argv[1] : argv[0];
    struct stat st;

    printf("============================================================\n");
    printf(" Q39: File Statistics Inspection via stat() System Call     \n");
    printf(" Target Path: %s\n", path);
    printf("============================================================\n");

    if (stat(path, &st) == -1) {
        perror("stat failed");
        exit(EXIT_FAILURE);
    }

    print_file_type(st.st_mode);
    print_permissions(st.st_mode);

    printf("Inode Number         : %ld\n", (long)st.st_ino);
    printf("Device ID            : %ld\n", (long)st.st_dev);
    printf("Hard Link Count      : %ld\n", (long)st.st_nlink);
    printf("User ID (UID)        : %d\n", st.st_uid);
    printf("Group ID (GID)       : %d\n", st.st_gid);
    printf("Total Size           : %lld bytes\n", (long long)st.st_size);
    printf("Block Size           : %ld bytes\n", (long)st.st_blksize);
    printf("Blocks Allocated     : %lld\n", (long long)st.st_blocks);

    printf("Last Access Time     : %s", ctime(&st.st_atime));
    printf("Last Modif. Time     : %s", ctime(&st.st_mtime));
    printf("Last Status Change   : %s", ctime(&st.st_ctime));

    printf("============================================================\n");
    return 0;
}
