/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 87: Write a program to demonstrate file locking using flock().
 *
 * Concept:
 *   flock(fd, LOCK_EX) - Apply exclusive lock (blocks until acquired)
 *   flock(fd, LOCK_SH) - Apply shared lock (multiple readers allowed)
 *   flock(fd, LOCK_UN) - Unlock
 *
 * Compilation:
 *   gcc -Wall -O2 q87_file_locking_flock.c -o q87_file_locking_flock
 *
 * Execution:
 *   ./q87_file_locking_flock
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/file.h>
#include <sys/wait.h>
#include <string.h>

#define DEMO_FILE "q87_flock_shared.txt"

void run_process_lock_demo(const char *label, int delay_start) {
    usleep(delay_start * 1000);

    int fd = open(DEMO_FILE, O_RDWR | O_CREAT, 0666);
    if (fd < 0) {
        perror("open error");
        return;
    }

    printf("[%s PID %d] Requesting Exclusive Lock: flock(fd, LOCK_EX)...\n", label, getpid());

    // Acquire exclusive lock
    if (flock(fd, LOCK_EX) == -1) {
        perror("flock LOCK_EX failed");
        close(fd);
        return;
    }

    printf(">>> [%s] LOCK GRANTED! Writing safely to file... <<<\n", label);

    char buf[128];
    snprintf(buf, sizeof(buf), "Data written exclusively by %s (PID %d)\n", label, getpid());
    lseek(fd, 0, SEEK_END);
    write(fd, buf, strlen(buf));

    sleep(2); // Simulate processing

    printf("<<< [%s] Unlocking: flock(fd, LOCK_UN)... >>>\n", label);
    flock(fd, LOCK_UN);
    close(fd);
}

int main() {
    printf("============================================================\n");
    printf(" Q87: File Locking Demonstration using flock()              \n");
    printf(" Lock Target: %s\n", DEMO_FILE);
    printf("============================================================\n");

    // Clean start
    unlink(DEMO_FILE);

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent Process
        run_process_lock_demo("Parent", 0);
        wait(NULL);

        printf("\nVerifying file contents written safely under flock():\n");
        printf("------------------------------------------------------------\n");
        FILE *f = fopen(DEMO_FILE, "r");
        if (f) {
            char line[256];
            while (fgets(line, sizeof(line), f)) printf("%s", line);
            fclose(f);
        }
        printf("------------------------------------------------------------\n");

        unlink(DEMO_FILE);
        printf("flock() file locking demonstration completed successfully!\n");
    } else {
        // Child Process
        run_process_lock_demo("Child ", 200);
        exit(0);
    }

    return 0;
}
