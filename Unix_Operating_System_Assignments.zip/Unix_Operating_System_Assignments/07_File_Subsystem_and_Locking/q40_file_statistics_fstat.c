/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 40: Write a program that reports file statistics using fstat()
 *              (include important fields such as file access permissions,
 *              file type, etc.).
 *
 * Difference from stat():
 *   stat() takes a pathname string, while fstat() operates on an open
 *   integer file descriptor (fd).
 *
 * Compilation:
 *   gcc -Wall -O2 q40_file_statistics_fstat.c -o q40_file_statistics_fstat
 *
 * Execution:
 *   ./q40_file_statistics_fstat [filename]
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <time.h>

void display_mode_details(mode_t m) {
    printf("File Type            : ");
    if (S_ISREG(m))  printf("Regular File\n");
    else if (S_ISDIR(m))  printf("Directory\n");
    else if (S_ISCHR(m))  printf("Character Device\n");
    else if (S_ISBLK(m))  printf("Block Device\n");
    else if (S_ISFIFO(m)) printf("FIFO Pipe\n");
    else if (S_ISLNK(m))  printf("Symbolic Link\n");
    else if (S_ISSOCK(m)) printf("Socket\n");
    else                  printf("Other\n");

    printf("Permissions (rwxrwxrwx): ");
    putchar((m & S_IRUSR) ? 'r' : '-');
    putchar((m & S_IWUSR) ? 'w' : '-');
    putchar((m & S_IXUSR) ? 'x' : '-');
    putchar((m & S_IRGRP) ? 'r' : '-');
    putchar((m & S_IWGRP) ? 'w' : '-');
    putchar((m & S_IXGRP) ? 'x' : '-');
    putchar((m & S_IROTH) ? 'r' : '-');
    putchar((m & S_IWOTH) ? 'w' : '-');
    putchar((m & S_IXOTH) ? 'x' : '-');
    printf(" [Octal: %04o]\n", m & 0777);
}

int main(int argc, char *argv[]) {
    const char *target = (argc > 1) ? argv[1] : argv[0];
    struct stat st;

    printf("============================================================\n");
    printf(" Q40: File Statistics Inspection via fstat() System Call    \n");
    printf(" Opening Target: %s\n", target);
    printf("============================================================\n");

    int fd = open(target, O_RDONLY);
    if (fd == -1) {
        perror("open failed");
        exit(EXIT_FAILURE);
    }

    if (fstat(fd, &st) == -1) {
        perror("fstat failed");
        close(fd);
        exit(EXIT_FAILURE);
    }

    printf("Active File Descriptor: %d\n", fd);
    display_mode_details(st.st_mode);

    printf("Inode Number          : %ld\n", (long)st.st_ino);
    printf("File Size             : %lld bytes\n", (long long)st.st_size);
    printf("Owner UID / Group GID : UID=%d, GID=%d\n", st.st_uid, st.st_gid);
    printf("Number of Hard Links  : %ld\n", (long)st.st_nlink);
    printf("Last Modified Time    : %s", ctime(&st.st_mtime));

    close(fd);
    printf("File descriptor closed cleanly.\n");
    return 0;
}
