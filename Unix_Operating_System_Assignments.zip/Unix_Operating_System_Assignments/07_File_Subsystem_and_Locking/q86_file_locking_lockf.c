/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 86: Write a program to demonstrate file locking using lockf().
 *
 * Concept:
 *   lockf(fd, F_LOCK, size) locks a section of a file (or entire file if size=0).
 *   lockf(fd, F_ULOCK, size) unlocks the section.
 *   This prevents concurrent write collisions between multiple processes.
 *
 * Compilation:
 *   gcc -Wall -O2 q86_file_locking_lockf.c -o q86_file_locking_lockf
 *
 * Execution:
 *   ./q86_file_locking_lockf
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/wait.h>

#define LOCK_FILE "q86_demo_lock_target.txt"

void write_critical_section(int fd, const char *process_name) {
    printf("[%s] Attempting to acquire file lock using lockf(F_LOCK)...\n", process_name);

    // Apply exclusive lock to the file
    if (lockf(fd, F_LOCK, 0) == -1) {
        perror("lockf F_LOCK failed");
        return;
    }

    printf(">>> [%s] LOCK ACQUIRED! Entering Critical Section. <<<\n", process_name);

    char msg[128];
    snprintf(msg, sizeof(msg), "[%s PID %d] Critical write execution timestamp.\n",
             process_name, getpid());
    write(fd, msg, strlen(msg));

    // Simulate work inside critical section
    sleep(2);

    printf("<<< [%s] Releasing file lock using lockf(F_ULOCK)... >>>\n", process_name);
    lseek(fd, 0, SEEK_SET);
    lockf(fd, F_ULOCK, 0);
}

int main() {
    printf("============================================================\n");
    printf(" Q86: File Locking Demonstration using lockf()              \n");
    printf(" Shared File: %s\n", LOCK_FILE);
    printf("============================================================\n");

    int fd = open(LOCK_FILE, O_RDWR | O_CREAT | O_TRUNC, 0666);
    if (fd < 0) {
        perror("open failed");
        exit(EXIT_FAILURE);
    }

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork error");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent Process
        write_critical_section(fd, "Parent Process");
        wait(NULL);

        printf("\nParent reading file contents written with mutual exclusion:\n");
        printf("------------------------------------------------------------\n");
        lseek(fd, 0, SEEK_SET);
        char buf[256];
        ssize_t n;
        while ((n = read(fd, buf, sizeof(buf) - 1)) > 0) {
            buf[n] = '\0';
            printf("%s", buf);
        }
        printf("------------------------------------------------------------\n");

        close(fd);
        unlink(LOCK_FILE);
        printf("lockf() demonstration completed successfully!\n");
    } else {
        // Child Process
        usleep(100000); // Allow parent to lock first
        write_critical_section(fd, "Child Process ");
        close(fd);
        exit(0);
    }

    return 0;
}
