/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 35: Write a program that uses kill() to send signals between two
 *              unrelated processes.
 *              [PART 1: SIGNAL RECEIVER PROCESS]
 *
 * Compilation:
 *   gcc -Wall -O2 q35_kill_unrelated_receiver.c -o q35_kill_unrelated_receiver
 *   gcc -Wall -O2 q35_kill_unrelated_sender.c -o q35_kill_unrelated_sender
 *
 * Execution:
 *   Terminal 1: ./q35_kill_unrelated_receiver
 *   Terminal 2: ./q35_kill_unrelated_sender [PID_from_receiver]
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

volatile sig_atomic_t sigusr1_count = 0;
volatile sig_atomic_t running = 1;

void handle_sigusr1(int sig) {
    sigusr1_count++;
    printf("\n>> [RECEIVER PID %d] Caught SIGUSR1 (Signal #%d)! Total count: %d\n",
           getpid(), sig, sigusr1_count);
}

void handle_sigusr2(int sig) {
    printf("\n>> [RECEIVER PID %d] Caught SIGUSR2 (Signal #%d)!\n", getpid(), sig);
}

void handle_sigterm(int sig) {
    printf("\n>> [RECEIVER PID %d] Caught SIGTERM (Signal #%d)! Gracefully shutting down.\n",
           getpid(), sig);
    running = 0;
}

int main() {
    // Register signal handlers
    signal(SIGUSR1, handle_sigusr1);
    signal(SIGUSR2, handle_sigusr2);
    signal(SIGTERM, handle_sigterm);

    printf("============================================================\n");
    printf(" Q35: Signal Receiver (Unrelated Process)                   \n");
    printf(" RECEIVER PID = %d\n", getpid());
    printf(" Pass this PID to 'q35_kill_unrelated_sender' in Terminal 2\n");
    printf("============================================================\n");

    printf("Waiting for signals (SIGUSR1, SIGUSR2, SIGTERM)...\n");

    while (running) {
        pause(); // Suspend process until a signal arrives
    }

    printf("Receiver process terminated gracefully.\n");
    return 0;
}
