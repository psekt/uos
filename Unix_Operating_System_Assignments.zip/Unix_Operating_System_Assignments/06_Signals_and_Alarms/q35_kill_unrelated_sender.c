/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 35: Write a program that uses kill() to send signals between two
 *              unrelated processes.
 *              [PART 2: SIGNAL SENDER PROCESS]
 *
 * Compilation:
 *   gcc -Wall -O2 q35_kill_unrelated_sender.c -o q35_kill_unrelated_sender
 *
 * Execution:
 *   Terminal 1: ./q35_kill_unrelated_receiver
 *   Terminal 2: ./q35_kill_unrelated_sender [target_pid]
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

int main(int argc, char *argv[]) {
    pid_t target_pid;

    if (argc > 1) {
        target_pid = (pid_t)atoi(argv[1]);
    } else {
        printf("Enter the Receiver PID (displayed by q35_kill_unrelated_receiver): ");
        if (scanf("%d", &target_pid) != 1) {
            printf("Invalid PID.\n");
            exit(EXIT_FAILURE);
        }
    }

    printf("============================================================\n");
    printf(" Q35: Signal Sender (kill system call to PID: %d)          \n", target_pid);
    printf(" 1. Send SIGUSR1\n");
    printf(" 2. Send SIGUSR2\n");
    printf(" 3. Send SIGTERM (Terminate receiver)\n");
    printf(" 0. Exit Sender\n");
    printf("============================================================\n");

    int choice;
    while (1) {
        printf("\nSelect signal to send (1-3, 0 to quit): ");
        if (scanf("%d", &choice) != 1 || choice == 0) break;

        int sig_to_send;
        switch (choice) {
            case 1: sig_to_send = SIGUSR1; break;
            case 2: sig_to_send = SIGUSR2; break;
            case 3: sig_to_send = SIGTERM; break;
            default:
                printf("Invalid choice.\n");
                continue;
        }

        if (kill(target_pid, sig_to_send) == 0) {
            printf("[Sender PID: %d] Successfully sent signal %d to target PID %d\n",
                   getpid(), sig_to_send, target_pid);
        } else {
            perror("[Sender] kill() failed (Target process may not exist)");
            break;
        }

        if (choice == 3) {
            printf("[Sender] Target terminated. Exiting.\n");
            break;
        }
    }

    return 0;
}
