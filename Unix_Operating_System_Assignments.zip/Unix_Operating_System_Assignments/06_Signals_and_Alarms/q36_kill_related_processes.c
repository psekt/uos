/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 36: Write a program that uses kill() to send signals between
 *              related processes (created with fork()).
 *
 * Flow:
 *   1. Parent forks Child.
 *   2. Child sets up signal handlers.
 *   3. Parent sends multiple signals (SIGUSR1, SIGUSR2, SIGTERM) using kill().
 *   4. Child handles signals and parent waits for child termination.
 *
 * Compilation:
 *   gcc -Wall -O2 q36_kill_related_processes.c -o q36_kill_related_processes
 *
 * Execution:
 *   ./q36_kill_related_processes
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

void child_sigusr1_handler(int sig) {
    printf("  [Child PID: %d] Caught SIGUSR1 from parent!\n", getpid());
}

void child_sigusr2_handler(int sig) {
    printf("  [Child PID: %d] Caught SIGUSR2 from parent!\n", getpid());
}

void child_sigterm_handler(int sig) {
    printf("  [Child PID: %d] Caught SIGTERM from parent! Exiting...\n", getpid());
    exit(0);
}

int main() {
    printf("============================================================\n");
    printf(" Q36: kill() Signaling Between Related Processes (Parent-Child)\n");
    printf(" Parent PID: %d\n", getpid());
    printf("============================================================\n");

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {
        // Child Process
        signal(SIGUSR1, child_sigusr1_handler);
        signal(SIGUSR2, child_sigusr2_handler);
        signal(SIGTERM, child_sigterm_handler);

        printf("[Child PID: %d] Signal handlers installed. Waiting for parent's signals...\n", getpid());
        while (1) {
            pause();
        }
    } else {
        // Parent Process
        sleep(1); // Give child time to register handlers

        printf("\n[Parent] Sending SIGUSR1 to Child (PID %d)...\n", pid);
        kill(pid, SIGUSR1);
        sleep(1);

        printf("\n[Parent] Sending SIGUSR2 to Child (PID %d)...\n", pid);
        kill(pid, SIGUSR2);
        sleep(1);

        printf("\n[Parent] Sending SIGTERM to terminate Child (PID %d)...\n", pid);
        kill(pid, SIGTERM);

        int status;
        wait(&status);
        printf("\n[Parent] Child reaped. Inter-process signaling verified successfully!\n");
    }

    return 0;
}
