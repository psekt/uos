/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 38: Create an alarm clock program using alarm() and signal handlers.
 *
 * Compilation:
 *   gcc -Wall -O2 q38_alarm_clock.c -o q38_alarm_clock
 *
 * Execution:
 *   ./q38_alarm_clock [seconds_to_alarm] [alarm_message]
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <string.h>

char alarm_msg[128] = "WAKE UP! Alarm timer has expired!";
volatile sig_atomic_t alarm_fired = 0;

void sigalrm_handler(int sig) {
    alarm_fired = 1;
}

int main(int argc, char *argv[]) {
    int duration = (argc > 1) ? atoi(argv[1]) : 5;
    if (duration <= 0) duration = 5;

    if (argc > 2) {
        strncpy(alarm_msg, argv[2], sizeof(alarm_msg) - 1);
    }

    signal(SIGALRM, sigalrm_handler);

    printf("============================================================\n");
    printf(" Q38: Unix Alarm Clock Using alarm() and Signal Handlers    \n");
    printf(" Alarm set for: %d seconds\n", duration);
    printf(" Reminder Msg : %s\n", alarm_msg);
    printf("============================================================\n");

    time_t now = time(NULL);
    printf("Current system time: %s", ctime(&now));

    // Arm the alarm
    alarm(duration);

    // Countdown display
    for (int remaining = duration; remaining > 0 && !alarm_fired; remaining--) {
        printf("Time remaining: %d second(s)...\r", remaining);
        fflush(stdout);
        sleep(1);
    }

    if (alarm_fired) {
        printf("\n\n\a============================================================\n");
        printf(" >>>>> ALARM RINGING! <<<<<\n");
        printf(" MESSAGE: %s\n", alarm_msg);
        time_t alarm_time = time(NULL);
        printf(" Triggered at: %s", ctime(&alarm_time));
        printf("============================================================\n");
    }

    return 0;
}
