/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 37: Implement a program that uses alarm() and signal handling to
 *              require user input within a specified time limit.
 *
 * Compilation:
 *   gcc -Wall -O2 q37_alarm_user_input_timeout.c -o q37_alarm_user_input_timeout
 *
 * Execution:
 *   ./q37_alarm_user_input_timeout
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>

#define TIMEOUT_SECONDS 5

void alarm_handler(int sig) {
    printf("\n\n************************************************************\n");
    printf(" TIME OUT! You failed to provide input within %d seconds!\n", TIMEOUT_SECONDS);
    printf(" Terminating program due to inactivity.\n");
    printf("************************************************************\n");
    exit(EXIT_FAILURE);
}

int main() {
    char user_response[128];

    // Register SIGALRM signal handler
    signal(SIGALRM, alarm_handler);

    printf("============================================================\n");
    printf(" Q37: User Input with Strict Timeout Using alarm()          \n");
    printf(" TIME LIMIT: %d SECONDS                                     \n", TIMEOUT_SECONDS);
    printf("============================================================\n");

    // Set alarm for 5 seconds
    alarm(TIMEOUT_SECONDS);

    printf("Quick! Please enter your name: ");
    fflush(stdout);

    if (fgets(user_response, sizeof(user_response), stdin) != NULL) {
        // Cancel the alarm if user responded in time!
        alarm(0);

        user_response[strcspn(user_response, "\r\n")] = '\0';
        printf("\nSUCCESS: Input received in time!\n");
        printf("Hello, %s! You beat the %d-second clock!\n", user_response, TIMEOUT_SECONDS);
    }

    return 0;
}
