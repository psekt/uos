/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 66: Write a program to demonstrate IPC via message queues
 *              (msgget, msgsnd, msgrcv) for chatting between two or three users.
 *
 * User selection: Pass 1, 2, or 3 as argument to act as User 1, User 2, or User 3.
 *
 * Compilation:
 *   gcc -Wall -O2 q66_msgqueue_three_user_chat.c -o q66_msgqueue_three_user_chat
 *
 * Execution:
 *   Terminal 1: ./q66_msgqueue_three_user_chat 1
 *   Terminal 2: ./q66_msgqueue_three_user_chat 2
 *   Terminal 3: ./q66_msgqueue_three_user_chat 3
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define CHAT3_KEY 0x6666
#define MAX_TEXT 256

struct user_msg {
    long target_user; // mtype: 1 = for User 1, 2 = for User 2, 3 = for User 3
    int from_user;
    char text[MAX_TEXT];
};

int main(int argc, char *argv[]) {
    int user_id = (argc > 1) ? atoi(argv[1]) : 1;
    if (user_id < 1 || user_id > 3) {
        printf("Usage: %s [1 | 2 | 3]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int msgid = msgget(CHAT3_KEY, IPC_CREAT | 0666);
    if (msgid == -1) {
        perror("msgget failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q66: 3-User Message Queue Chat - Running as USER %d        \n", user_id);
    printf(" Commands:\n");
    printf("   send <target_user_id (1-3)> <message>\n");
    printf("   recv (checks for messages for User %d)\n", user_id);
    printf("   exit (quit)\n");
    printf("============================================================\n");

    char cmd[64];
    while (1) {
        printf("User-%d > ", user_id);
        if (scanf("%s", cmd) != 1) break;

        if (strcmp(cmd, "send") == 0) {
            int target;
            char message[MAX_TEXT];
            scanf("%d", &target);
            getchar(); // consume space
            if (fgets(message, sizeof(message), stdin) != NULL) {
                message[strcspn(message, "\r\n")] = '\0';
                struct user_msg s_msg;
                s_msg.target_user = target;
                s_msg.from_user = user_id;
                strncpy(s_msg.text, message, MAX_TEXT);
                msgsnd(msgid, &s_msg, sizeof(s_msg) - sizeof(long), 0);
                printf("[Sent to User %d]: %s\n", target, message);
            }
        } else if (strcmp(cmd, "recv") == 0) {
            struct user_msg r_msg;
            // IPC_NOWAIT allows checking without blocking if queue is empty
            ssize_t res = msgrcv(msgid, &r_msg, sizeof(r_msg) - sizeof(long), user_id, IPC_NOWAIT);
            if (res > 0) {
                printf(">> [Incoming from User %d]: %s\n", r_msg.from_user, r_msg.text);
            } else {
                printf("[No new messages for User %d]\n", user_id);
            }
        } else if (strcmp(cmd, "exit") == 0) {
            break;
        } else {
            printf("Invalid command. Use: send <target> <msg>, recv, or exit.\n");
        }
    }

    return 0;
}
