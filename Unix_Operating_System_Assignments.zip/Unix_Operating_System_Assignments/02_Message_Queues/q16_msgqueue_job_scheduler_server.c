/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 16: Job scheduling system: Write a program where a client submits
 *              jobs (e.g., factorial, Fibonacci, prime check) via message queues,
 *              and a server process executes and returns results.
 *              [SERVER PROCESS]
 *
 * Compilation:
 *   gcc -Wall -O2 q16_msgqueue_job_scheduler_server.c -o q16_msgqueue_job_scheduler_server
 *
 * Execution:
 *   Terminal 1: ./q16_msgqueue_job_scheduler_server
 *   Terminal 2: ./q16_msgqueue_job_scheduler_client
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define JOB_QUEUE_KEY 0x5151

// Job types:
// 1 = Factorial
// 2 = Fibonacci (N-th term)
// 3 = Prime Check (1=prime, 0=not prime)
// 4 = Shutdown server

struct job_request {
    long mtype;       // 1 for requests to server
    long client_pid;  // Client PID to respond to
    int job_type;
    long input_arg;
};

struct job_response {
    long mtype;       // Set to client_pid
    long result;
    char details[128];
};

long compute_factorial(long n) {
    if (n <= 1) return 1;
    long f = 1;
    for (long i = 2; i <= n; i++) f *= i;
    return f;
}

long compute_fibonacci(long n) {
    if (n <= 0) return 0;
    if (n == 1) return 1;
    long a = 0, b = 1, c = 0;
    for (long i = 2; i <= n; i++) {
        c = a + b;
        a = b;
        b = c;
    }
    return c;
}

int is_prime(long n) {
    if (n <= 1) return 0;
    for (long i = 2; i * i <= n; i++) {
        if (n % i == 0) return 0;
    }
    return 1;
}

int main() {
    int msgid = msgget(JOB_QUEUE_KEY, IPC_CREAT | 0666);
    if (msgid == -1) {
        perror("msgget failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q16: Job Scheduling System - Server Process                \n");
    printf(" Listening for client job requests (Factorial, Fibonacci, Prime)\n");
    printf("============================================================\n");

    struct job_request req;
    struct job_response res;

    while (1) {
        if (msgrcv(msgid, &req, sizeof(req) - sizeof(long), 1, 0) == -1) {
            perror("msgrcv error");
            break;
        }

        if (req.job_type == 4) {
            printf("[Server] Shutdown request received. Exiting.\n");
            break;
        }

        printf("[Server] Processing job from Client PID: %ld | Type: %d | Arg: %ld\n",
               req.client_pid, req.job_type, req.input_arg);

        res.mtype = req.client_pid;

        switch (req.job_type) {
            case 1: // Factorial
                res.result = compute_factorial(req.input_arg);
                snprintf(res.details, sizeof(res.details), "Factorial(%ld) = %ld", req.input_arg, res.result);
                break;
            case 2: // Fibonacci
                res.result = compute_fibonacci(req.input_arg);
                snprintf(res.details, sizeof(res.details), "Fibonacci(%ld-th) = %ld", req.input_arg, res.result);
                break;
            case 3: // Prime Check
                res.result = is_prime(req.input_arg);
                snprintf(res.details, sizeof(res.details), "%ld is %s",
                         req.input_arg, res.result ? "a PRIME number" : "NOT a prime number");
                break;
            default:
                res.result = -1;
                snprintf(res.details, sizeof(res.details), "Unknown job type");
        }

        msgsnd(msgid, &res, sizeof(res) - sizeof(long), 0);
        printf("[Server] Sent response to Client PID %ld: %s\n", req.client_pid, res.details);
    }

    msgctl(msgid, IPC_RMID, NULL);
    return 0;
}
