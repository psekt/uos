/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 17: Priority-based messaging: Implement a system where multiple
 *              clients send messages with different priorities, and the server
 *              displays them in priority order.
 *              [CLIENT PROCESS]
 *
 * Compilation:
 *   gcc -Wall -O2 q17_msgqueue_priority_client.c -o q17_msgqueue_priority_client
 *
 * Execution:
 *   Terminal 1: ./q17_msgqueue_priority_server
 *   Terminal 2: ./q17_msgqueue_priority_client
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define PRIO_KEY 0x7171
#define MAX_TEXT 256

struct prio_msg {
    long mtype;
    char text[MAX_TEXT];
};

void send_message(int msgid, long priority, const char *text) {
    struct prio_msg msg;
    msg.mtype = priority;
    strncpy(msg.text, text, sizeof(msg.text));
    msgsnd(msgid, &msg, strlen(msg.text) + 1, 0);
    printf("  [Client PID %d] Sent (Priority %ld): %s\n", getpid(), priority, text);
}

int main() {
    int msgid = msgget(PRIO_KEY, 0666);
    if (msgid == -1) {
        printf("Error: Priority queue not found. Start server first!\n");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q17: Priority-Based Messaging Client                       \n");
    printf(" Sending mixed priority messages to demonstrate priority dispatch\n");
    printf("============================================================\n");

    // Send messages in random priority order to prove server sorts by priority
    send_message(msgid, 4, "Low priority log: Routine health check passed.");
    send_message(msgid, 2, "High priority warning: Memory threshold at 85%.");
    send_message(msgid, 3, "Normal priority notice: User Alice logged in.");
    send_message(msgid, 1, "CRITICAL ALERT: Database connection failure!");
    send_message(msgid, 4, "Low priority log: Cache cleaned.");
    send_message(msgid, 1, "CRITICAL ALERT: Power backup activated!");

    // Signal server shutdown
    send_message(msgid, 1, "QUIT");

    printf("\nAll messages sent. Notice on the server that Critical (1) is printed first!\n");
    return 0;
}
