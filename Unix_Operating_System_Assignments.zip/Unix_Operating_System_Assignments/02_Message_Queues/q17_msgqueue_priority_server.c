/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 17: Priority-based messaging: Implement a system where multiple
 *              clients send messages with different priorities, and the server
 *              displays them in priority order.
 *              [SERVER PROCESS]
 *
 * Concept: System V IPC msg type priority retrieval:
 *          msgrcv with negative msgtyp flag receives messages with the lowest
 *          type value <= |msgtyp| (i.e. highest priority first: Type 1 > Type 2 > Type 3)
 *
 * Compilation:
 *   gcc -Wall -O2 q17_msgqueue_priority_server.c -o q17_msgqueue_priority_server
 *
 * Execution:
 *   Terminal 1: ./q17_msgqueue_priority_server
 *   Terminal 2: ./q17_msgqueue_priority_client
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define PRIO_KEY 0x7171
#define MAX_TEXT 256

struct prio_msg {
    long mtype; // 1 = Critical, 2 = High, 3 = Normal, 4 = Low
    char text[MAX_TEXT];
};

const char* priority_label(long p) {
    switch (p) {
        case 1: return "CRITICAL (Prio 1)";
        case 2: return "HIGH     (Prio 2)";
        case 3: return "NORMAL   (Prio 3)";
        case 4: return "LOW      (Prio 4)";
        default: return "OTHER";
    }
}

int main() {
    int msgid = msgget(PRIO_KEY, IPC_CREAT | 0666);
    if (msgid == -1) {
        perror("msgget failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q17: Priority-Based Messaging Server                       \n");
    printf(" Processing messages in priority order (1=Highest to 4=Lowest)\n");
    printf("============================================================\n");

    struct prio_msg msg;
    int received_count = 0;

    // msgrcv with type parameter = -4 means:
    // "Read message whose type is less than or equal to 4,
    //  selecting the SMALLEST type first!" -> Priority 1, then 2, then 3, then 4!
    while (1) {
        // -4 enables priority queue ordering in System V
        ssize_t n = msgrcv(msgid, &msg, sizeof(msg.text), -4, 0);
        if (n == -1) {
            perror("msgrcv failed");
            break;
        }

        received_count++;
        printf("[Priority Dispather #%d] [%s] Message: %s\n",
               received_count, priority_label(msg.mtype), msg.text);

        // Check for exit condition
        if (msg.mtype == 1 && msg.text[0] == 'Q') {
            printf("[Server] Quit signal received.\n");
            break;
        }
    }

    msgctl(msgid, IPC_RMID, NULL);
    return 0;
}
