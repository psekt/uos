/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 6: Write a program where one process sends a sequence of numbers using
 *             message queues, and another process computes and prints their sum.
 *             [SENDER PROCESS]
 *
 * Compilation:
 *   gcc -Wall -O2 q06_msgqueue_sum_sender.c -o q06_msgqueue_sum_sender
 *
 * Execution:
 *   Terminal 1: ./q06_msgqueue_sum_receiver
 *   Terminal 2: ./q06_msgqueue_sum_sender
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define SUM_KEY 0x4567

struct num_msg {
    long mtype;
    int number;
    int is_last; // 1 indicates end of sequence
};

int main() {
    int msgid = msgget(SUM_KEY, IPC_CREAT | 0666);
    if (msgid == -1) {
        perror("msgget failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q06: Message Queue Sequence Sum - Sender Process          \n");
    printf("============================================================\n");

    int n;
    printf("Enter count of numbers to send: ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        n = 5;
        printf("Using default count: %d\n", n);
    }

    struct num_msg msg;
    msg.mtype = 1;

    for (int i = 1; i <= n; i++) {
        int val;
        printf("Enter number %d: ", i);
        if (scanf("%d", &val) != 1) {
            val = i * 10;
        }
        msg.number = val;
        msg.is_last = (i == n) ? 1 : 0;

        if (msgsnd(msgid, &msg, sizeof(msg) - sizeof(long), 0) == -1) {
            perror("msgsnd error");
            break;
        }
        printf("[Sender] Sent number: %d (last: %d)\n", msg.number, msg.is_last);
    }

    printf("[Sender] All numbers sent successfully.\n");
    return 0;
}
