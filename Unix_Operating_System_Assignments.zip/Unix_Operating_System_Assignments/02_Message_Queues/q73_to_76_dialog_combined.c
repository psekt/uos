/*
 * Assignment: Unix Operating System - External Practical Exam
 * Questions 73-76: Write two programs that exchange messages to form the dialog:
 *   74. Process 1 sends "Hi?"
 *   75. Process 2 receives and replies "Hello"
 *   76. Process 1 receives the reply and then sends "I am fine"
 *   [Combined Fork Simulation]
 *
 * Compilation:
 *   gcc -Wall -O2 q73_to_76_dialog_combined.c -o q73_to_76_dialog_combined
 *
 * Execution:
 *   ./q73_to_76_dialog_combined
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h>

#define COMBINED_DIALOG_KEY 0x9988

struct dialog_msg {
    long mtype;
    char text[64];
};

int main() {
    int msgid = msgget(COMBINED_DIALOG_KEY, IPC_CREAT | 0666);
    if (msgid == -1) {
        perror("msgget failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q73-76: Dialog Exchange Combined Demo                      \n");
    printf("============================================================\n");

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork error");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Process 1 (Parent)
        struct dialog_msg msg;

        // Q74: Send "Hi?"
        msg.mtype = 1;
        strcpy(msg.text, "Hi?");
        printf(">> [Process 1 (Q74) Sends]: %s\n", msg.text);
        msgsnd(msgid, &msg, strlen(msg.text) + 1, 0);

        // Q75: Receive "Hello"
        msgrcv(msgid, &msg, sizeof(msg.text), 2, 0);
        printf("<< [Process 1 (Q75) Receives]: %s\n", msg.text);

        // Q76: Send "I am fine"
        msg.mtype = 1;
        strcpy(msg.text, "I am fine");
        printf(">> [Process 1 (Q76) Sends]: %s\n", msg.text);
        msgsnd(msgid, &msg, strlen(msg.text) + 1, 0);

        wait(NULL);
        msgctl(msgid, IPC_RMID, NULL);
        printf("Conversation ended cleanly.\n");
    } else {
        // Process 2 (Child)
        struct dialog_msg msg;

        // Q74: Receive "Hi?"
        msgrcv(msgid, &msg, sizeof(msg.text), 1, 0);
        printf("<< [Process 2 (Q74) Receives]: %s\n", msg.text);

        // Q75: Send "Hello"
        msg.mtype = 2;
        strcpy(msg.text, "Hello");
        printf(">> [Process 2 (Q75) Replies]: %s\n", msg.text);
        msgsnd(msgid, &msg, strlen(msg.text) + 1, 0);

        // Q76: Receive "I am fine"
        msgrcv(msgid, &msg, sizeof(msg.text), 1, 0);
        printf("<< [Process 2 (Q76) Receives]: %s\n", msg.text);

        exit(EXIT_SUCCESS);
    }

    return 0;
}
