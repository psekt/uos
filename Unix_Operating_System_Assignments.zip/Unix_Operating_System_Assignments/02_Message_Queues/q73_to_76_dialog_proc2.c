/*
 * Assignment: Unix Operating System - External Practical Exam
 * Questions 73-76: Write two programs that exchange messages to form the dialog:
 *   74. Process 1 sends "Hi?"
 *   75. Process 2 receives and replies "Hello"
 *   76. Process 1 receives the reply and then sends "I am fine"
 *   Use System V message queues (msgget, msgsnd, msgrcv).
 *   [PROGRAM 2: PROCESS 2]
 *
 * Compilation:
 *   gcc -Wall -O2 q73_to_76_dialog_proc2.c -o q73_to_76_dialog_proc2
 *
 * Execution:
 *   Terminal 1: ./q73_to_76_dialog_proc1
 *   Terminal 2: ./q73_to_76_dialog_proc2
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define DIALOG_KEY 0x7376

struct dialog_msg {
    long mtype;
    char text[64];
};

int main() {
    int msgid = msgget(DIALOG_KEY, IPC_CREAT | 0666);
    if (msgid == -1) {
        perror("msgget failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q73-76: Dialog Exchange - Process 2                        \n");
    printf(" Waiting for Process 1 greeting...                          \n");
    printf("============================================================\n");

    struct dialog_msg msg;

    // Step 74: Process 2 receives "Hi?" (mtype = 1)
    if (msgrcv(msgid, &msg, sizeof(msg.text), 1, 0) == -1) {
        perror("msgrcv Step 74 failed");
        exit(EXIT_FAILURE);
    }
    printf("[Step 74] Process 2 Received: \"%s\"\n", msg.text);

    // Step 75: Process 2 replies "Hello" (mtype = 2)
    sleep(1);
    msg.mtype = 2;
    strcpy(msg.text, "Hello");
    printf("[Step 75] Process 2 Replying: \"%s\"\n", msg.text);
    if (msgsnd(msgid, &msg, strlen(msg.text) + 1, 0) == -1) {
        perror("msgsnd Step 75 failed");
        exit(EXIT_FAILURE);
    }

    // Step 76: Process 2 receives "I am fine" (mtype = 1)
    if (msgrcv(msgid, &msg, sizeof(msg.text), 1, 0) == -1) {
        perror("msgrcv Step 76 failed");
        exit(EXIT_FAILURE);
    }
    printf("[Step 76] Process 2 Received: \"%s\"\n", msg.text);

    printf("Process 2 dialog completed! Cleaning up queue.\n");
    msgctl(msgid, IPC_RMID, NULL);
    return 0;
}
