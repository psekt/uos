/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 5: Implement a program for a chat application between two processes
 *             using message queues. [PROCESS 2]
 *
 * Compilation:
 *   gcc -Wall -O2 q05_msgqueue_chat_proc2.c -o q05_msgqueue_chat_proc2
 *
 * Execution:
 *   Terminal 1: ./q05_msgqueue_chat_proc1
 *   Terminal 2: ./q05_msgqueue_chat_proc2
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define CHAT_KEY 0x2468
#define MSG_SIZE 256

struct chat_msg {
    long mtype;
    char mtext[MSG_SIZE];
};

int main() {
    int msgid = msgget(CHAT_KEY, IPC_CREAT | 0666);
    if (msgid == -1) {
        perror("msgget failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q05: Message Queue Chat Application - Process 2           \n");
    printf(" Waiting for Process 1 to start conversation...             \n");
    printf("============================================================\n");

    struct chat_msg s_msg, r_msg;

    while (1) {
        if (msgrcv(msgid, &r_msg, sizeof(r_msg.mtext), 1, 0) == -1) {
            perror("msgrcv failed");
            break;
        }

        if (strcmp(r_msg.mtext, "exit") == 0) {
            printf("[Process 1] has left the chat.\n");
            break;
        }
        printf("Process 1: %s\n", r_msg.mtext);

        printf("Process 2 > ");
        if (fgets(s_msg.mtext, MSG_SIZE, stdin) == NULL) break;
        s_msg.mtext[strcspn(s_msg.mtext, "\r\n")] = '\0';

        s_msg.mtype = 2; // P2 to P1
        if (msgsnd(msgid, &s_msg, strlen(s_msg.mtext) + 1, 0) == -1) {
            perror("msgsnd failed");
            break;
        }

        if (strcmp(s_msg.mtext, "exit") == 0) {
            printf("[Process 2] Exiting chat.\n");
            break;
        }
    }

    msgctl(msgid, IPC_RMID, NULL);
    return 0;
}
