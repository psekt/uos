/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 5: Implement a program for a chat application between two processes
 *             using message queues. [Combined Interactive Demo]
 *
 * Compilation:
 *   gcc -Wall -O2 q05_msgqueue_chat_combined.c -o q05_msgqueue_chat_combined
 *
 * Execution:
 *   ./q05_msgqueue_chat_combined
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h>

#define CHAT_KEY 0x3344
#define MSG_SIZE 256

struct chat_msg {
    long mtype;
    char mtext[MSG_SIZE];
};

int main() {
    int msgid = msgget(CHAT_KEY, IPC_CREAT | 0666);
    if (msgid == -1) {
        perror("msgget failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q05: Message Queue Two-Process Automated Dialog Demo      \n");
    printf("============================================================\n");

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Process 1 (Parent)
        struct chat_msg msg;
        const char *conv[] = {
            "Hello Process 2, how is the exam preparation going?",
            "Can we review Unix IPC mechanisms today?",
            "exit"
        };

        for (int i = 0; i < 3; i++) {
            msg.mtype = 1;
            strncpy(msg.mtext, conv[i], MSG_SIZE);
            printf("[Process 1 Sent]: %s\n", msg.mtext);
            msgsnd(msgid, &msg, strlen(msg.mtext) + 1, 0);

            if (strcmp(msg.mtext, "exit") == 0) break;

            msgrcv(msgid, &msg, MSG_SIZE, 2, 0);
            printf("[Process 1 Received]: %s\n", msg.mtext);
            sleep(1);
        }

        wait(NULL);
        msgctl(msgid, IPC_RMID, NULL);
        printf("[Process 1] Chat closed.\n");
    } else {
        // Process 2 (Child)
        struct chat_msg msg;
        const char *replies[] = {
            "Hi Process 1! It is going great, studying System V IPC now.",
            "Yes! Message Queues and Shared Memory are very important topics."
        };
        int reply_idx = 0;

        while (1) {
            msgrcv(msgid, &msg, MSG_SIZE, 1, 0);
            if (strcmp(msg.mtext, "exit") == 0) {
                printf("[Process 2]: Received exit command. Bye!\n");
                break;
            }
            printf("  [Process 2 Received]: %s\n", msg.mtext);

            msg.mtype = 2;
            strncpy(msg.mtext, replies[reply_idx++], MSG_SIZE);
            printf("  [Process 2 Sent]: %s\n", msg.mtext);
            msgsnd(msgid, &msg, strlen(msg.mtext) + 1, 0);
        }
        exit(EXIT_SUCCESS);
    }

    return 0;
}
