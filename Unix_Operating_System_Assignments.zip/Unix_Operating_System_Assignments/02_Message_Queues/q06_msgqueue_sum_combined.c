/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 6: Write a program where one process sends a sequence of numbers using
 *             message queues, and another process computes and prints their sum.
 *             [Combined Fork Demo]
 *
 * Compilation:
 *   gcc -Wall -O2 q06_msgqueue_sum_combined.c -o q06_msgqueue_sum_combined
 *
 * Execution:
 *   ./q06_msgqueue_sum_combined
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h>

#define SUM_KEY 0x7788

struct num_msg {
    long mtype;
    int val;
    int eof;
};

int main() {
    int msgid = msgget(SUM_KEY, IPC_CREAT | 0666);
    if (msgid == -1) {
        perror("msgget failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q06: Message Queue Sequence Sum Combined Fork Demo        \n");
    printf("============================================================\n");

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork error");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent: Sender
        int numbers[] = {12, 25, 40, 55, 68, 100};
        int len = sizeof(numbers) / sizeof(numbers[0]);

        struct num_msg msg;
        msg.mtype = 1;

        printf("[Parent Sender] Sending %d numbers to message queue:\n", len);
        for (int i = 0; i < len; i++) {
            msg.val = numbers[i];
            msg.eof = (i == len - 1) ? 1 : 0;
            printf("  Sending: %d\n", numbers[i]);
            msgsnd(msgid, &msg, sizeof(msg) - sizeof(long), 0);
        }

        wait(NULL);
        msgctl(msgid, IPC_RMID, NULL);
        printf("[Parent Sender] Queue removed. Demo finished.\n");
    } else {
        // Child: Receiver & Sum Computer
        struct num_msg msg;
        long sum = 0;
        int count = 0;

        printf("[Child Receiver] Computing sum of incoming numbers...\n");
        while (1) {
            msgrcv(msgid, &msg, sizeof(msg) - sizeof(long), 1, 0);
            sum += msg.val;
            count++;
            if (msg.eof) break;
        }

        printf("[Child Receiver] Successfully processed %d numbers.\n", count);
        printf(">> FINAL COMPUTED SUM = %ld <<\n", sum);
        exit(EXIT_SUCCESS);
    }

    return 0;
}
