/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 4: Write a program using System V message queues to send and receive
 *             messages between two processes.
 *
 * Concept: System V IPC Message Queues: msgget(), msgsnd(), msgrcv(), msgctl()
 *
 * Compilation:
 *   gcc -Wall -O2 q04_msgqueue_send_receive.c -o q04_msgqueue_send_receive
 *
 * Execution:
 *   ./q04_msgqueue_send_receive
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h>

#define MSG_KEY 0x1234
#define BUFFER_SIZE 256

struct msg_buffer {
    long msg_type;
    char msg_text[BUFFER_SIZE];
};

int main() {
    int msgid;
    pid_t pid;

    // Create message queue with read-write permissions
    msgid = msgget(MSG_KEY, IPC_CREAT | 0666);
    if (msgid == -1) {
        perror("msgget failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q04: System V Message Queue Send & Receive Demo           \n");
    printf(" Message Queue ID: %d\n", msgid);
    printf("============================================================\n");

    pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent: Sender
        struct msg_buffer send_msg;
        send_msg.msg_type = 1;
        snprintf(send_msg.msg_text, sizeof(send_msg.msg_text),
                 "Greetings from Parent (PID: %d) through System V Message Queue!", getpid());

        printf("[Parent PID: %d] Sending message: \"%s\"\n", getpid(), send_msg.msg_text);

        if (msgsnd(msgid, &send_msg, strlen(send_msg.msg_text) + 1, 0) == -1) {
            perror("[Parent] msgsnd failed");
            exit(EXIT_FAILURE);
        }
        printf("[Parent] Message placed onto queue successfully.\n");

        wait(NULL); // Wait for child to receive

        // Remove message queue
        if (msgctl(msgid, IPC_RMID, NULL) == -1) {
            perror("msgctl IPC_RMID failed");
        } else {
            printf("[Parent] Message queue cleaned up.\n");
        }
    } else {
        // Child: Receiver
        struct msg_buffer recv_msg;
        printf("[Child PID: %d] Waiting to receive message of type 1...\n", getpid());

        // msgrcv blocks until a message with type 1 is available
        if (msgrcv(msgid, &recv_msg, sizeof(recv_msg.msg_text), 1, 0) == -1) {
            perror("[Child] msgrcv failed");
            exit(EXIT_FAILURE);
        }

        printf("[Child PID: %d] Successfully received message:\n", getpid());
        printf("  >> Type: %ld\n", recv_msg.msg_type);
        printf("  >> Text: %s\n", recv_msg.msg_text);

        exit(EXIT_SUCCESS);
    }

    return 0;
}
