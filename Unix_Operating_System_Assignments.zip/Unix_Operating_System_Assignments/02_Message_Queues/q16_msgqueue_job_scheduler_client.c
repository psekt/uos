/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 16: Job scheduling system: Write a program where a client submits
 *              jobs (e.g., factorial, Fibonacci, prime check) via message queues,
 *              and a server process executes and returns results.
 *              [CLIENT PROCESS]
 *
 * Compilation:
 *   gcc -Wall -O2 q16_msgqueue_job_scheduler_client.c -o q16_msgqueue_job_scheduler_client
 *
 * Execution:
 *   Terminal 1: ./q16_msgqueue_job_scheduler_server
 *   Terminal 2: ./q16_msgqueue_job_scheduler_client
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define JOB_QUEUE_KEY 0x5151

struct job_request {
    long mtype;       // 1 for requests to server
    long client_pid;  // Client PID to receive answer
    int job_type;     // 1=Factorial, 2=Fibonacci, 3=Prime
    long input_arg;
};

struct job_response {
    long mtype;       // client_pid
    long result;
    char details[128];
};

int main() {
    int msgid = msgget(JOB_QUEUE_KEY, 0666);
    if (msgid == -1) {
        printf("Error: Cannot connect to job scheduler queue. Ensure server is running!\n");
        exit(EXIT_FAILURE);
    }

    long my_pid = (long)getpid();
    printf("============================================================\n");
    printf(" Q16: Job Scheduling Client (PID: %ld)                      \n", my_pid);
    printf(" 1. Factorial\n 2. Fibonacci\n 3. Prime Check\n 4. Shutdown Server\n");
    printf("============================================================\n");

    int choice;
    long arg = 0;
    printf("Enter choice (1-4): ");
    if (scanf("%d", &choice) != 1) choice = 1;

    if (choice >= 1 && choice <= 3) {
        printf("Enter input argument: ");
        if (scanf("%ld", &arg) != 1) arg = 5;
    }

    struct job_request req;
    req.mtype = 1;
    req.client_pid = my_pid;
    req.job_type = choice;
    req.input_arg = arg;

    msgsnd(msgid, &req, sizeof(req) - sizeof(long), 0);
    printf("[Client] Submitted job request (Type: %d, Arg: %ld). Waiting for result...\n", choice, arg);

    if (choice == 4) {
        printf("[Client] Server shutdown request sent.\n");
        return 0;
    }

    struct job_response res;
    msgrcv(msgid, &res, sizeof(res) - sizeof(long), my_pid, 0);

    printf("============================================================\n");
    printf(" SERVER EXECUTION RESULT:\n");
    printf(" Details: %s\n", res.details);
    printf(" Value  : %ld\n", res.result);
    printf("============================================================\n");

    return 0;
}
