/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 6: Write a program where one process sends a sequence of numbers using
 *             message queues, and another process computes and prints their sum.
 *             [RECEIVER PROCESS]
 *
 * Compilation:
 *   gcc -Wall -O2 q06_msgqueue_sum_receiver.c -o q06_msgqueue_sum_receiver
 *
 * Execution:
 *   Terminal 1: ./q06_msgqueue_sum_receiver
 *   Terminal 2: ./q06_msgqueue_sum_sender
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define SUM_KEY 0x4567

struct num_msg {
    long mtype;
    int number;
    int is_last;
};

int main() {
    int msgid = msgget(SUM_KEY, IPC_CREAT | 0666);
    if (msgid == -1) {
        perror("msgget failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q06: Message Queue Sequence Sum - Receiver Process        \n");
    printf(" Waiting for sequence of numbers...                         \n");
    printf("============================================================\n");

    struct num_msg msg;
    long long total_sum = 0;
    int count = 0;

    while (1) {
        if (msgrcv(msgid, &msg, sizeof(msg) - sizeof(long), 1, 0) == -1) {
            perror("msgrcv failed");
            break;
        }

        count++;
        total_sum += msg.number;
        printf("[Receiver] Received item #%d: value = %d\n", count, msg.number);

        if (msg.is_last) {
            printf("[Receiver] End-of-sequence signal received.\n");
            break;
        }
    }

    printf("------------------------------------------------------------\n");
    printf(" SUMMARY:\n");
    printf(" Total numbers received: %d\n", count);
    printf(" Total Computed Sum    : %lld\n", total_sum);
    printf("------------------------------------------------------------\n");

    msgctl(msgid, IPC_RMID, NULL);
    return 0;
}
