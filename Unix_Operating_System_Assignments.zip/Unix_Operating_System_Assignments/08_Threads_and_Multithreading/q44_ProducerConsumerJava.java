/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 44: Implement the producer-consumer problem using multithreading in Java.
 *
 * Synchronization mechanism:
 *   Classic monitor with wait() and notifyAll() inside synchronized methods.
 *
 * Compilation:
 *   javac q44_ProducerConsumerJava.java
 *
 * Execution:
 *   java q44_ProducerConsumerJava
 */

import java.util.LinkedList;
import java.util.Queue;

public class q44_ProducerConsumerJava {
    private static final int BUFFER_CAPACITY = 5;
    private static final int TOTAL_ITEMS_TO_PRODUCE = 12;

    public static void main(String[] args) {
        System.out.println("============================================================");
        System.out.println(" Q44: Producer-Consumer Problem using Multithreading in Java ");
        System.out.println(" Buffer Capacity: " + BUFFER_CAPACITY + " | Total Items: " + TOTAL_ITEMS_TO_PRODUCE);
        System.out.println("============================================================");

        BoundedBuffer<Integer> buffer = new BoundedBuffer<>(BUFFER_CAPACITY);

        Thread producer = new Thread(() -> {
            try {
                for (int i = 1; i <= TOTAL_ITEMS_TO_PRODUCE; i++) {
                    int item = i * 10;
                    buffer.produce(item);
                    Thread.sleep(120);
                }
                System.out.println("[Producer] Finished producing all items.");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }, "Producer-Thread");

        Thread consumer = new Thread(() -> {
            try {
                for (int i = 1; i <= TOTAL_ITEMS_TO_PRODUCE; i++) {
                    int item = buffer.consume();
                    Thread.sleep(180);
                }
                System.out.println("[Consumer] Finished consuming all items.");
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }, "Consumer-Thread");

        producer.start();
        consumer.start();

        try {
            producer.join();
            consumer.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        System.out.println("\nProducer-Consumer multithreaded simulation completed successfully!");
    }

    // Thread-safe generic bounded buffer using wait() and notifyAll()
    static class BoundedBuffer<T> {
        private final Queue<T> queue = new LinkedList<>();
        private final int capacity;

        public BoundedBuffer(int capacity) {
            this.capacity = capacity;
        }

        public synchronized void produce(T item) throws InterruptedException {
            while (queue.size() == capacity) {
                System.out.println("  [BUFFER FULL] Producer waiting for space...");
                wait();
            }

            queue.add(item);
            System.out.printf("[PRODUCER] Produced item: %-4s | Buffer size: %d/%d%n",
                    item, queue.size(), capacity);

            notifyAll(); // Wake up consumers
        }

        public synchronized T consume() throws InterruptedException {
            while (queue.isEmpty()) {
                System.out.println("  [BUFFER EMPTY] Consumer waiting for items...");
                wait();
            }

            T item = queue.poll();
            System.out.printf("  [CONSUMER] Consumed item: %-4s | Buffer size: %d/%d%n",
                    item, queue.size(), capacity);

            notifyAll(); // Wake up producers
            return item;
        }
    }
}
