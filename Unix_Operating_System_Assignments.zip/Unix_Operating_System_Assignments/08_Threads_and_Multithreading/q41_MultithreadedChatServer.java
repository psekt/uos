/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 41: Develop a multithreaded chat application in Java or C.
 *              [MULTITHREADED CHAT SERVER - JAVA]
 *
 * Compilation:
 *   javac q41_MultithreadedChatServer.java
 *
 * Execution:
 *   Terminal 1: java q41_MultithreadedChatServer [port: default 5000]
 *   Terminal 2: java q41_MultithreadedChatClient [host: localhost] [port: 5000]
 *   Terminal 3: java q41_MultithreadedChatClient [host: localhost] [port: 5000]
 */

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class q41_MultithreadedChatServer {
    private static final int DEFAULT_PORT = 5000;
    private static Set<ClientHandler> clientHandlers = ConcurrentHashMap.newKeySet();

    public static void main(String[] args) {
        int port = (args.length > 0) ? Integer.parseInt(args[0]) : DEFAULT_PORT;

        System.out.println("============================================================");
        System.out.println(" Q41: Multithreaded Chat Application - Server               ");
        System.out.println(" Server listening on port: " + port);
        System.out.println("============================================================");

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            while (true) {
                Socket socket = serverSocket.accept();
                ClientHandler clientHandler = new ClientHandler(socket);
                clientHandlers.add(clientHandler);
                new Thread(clientHandler).start();
            }
        } catch (IOException e) {
            System.err.println("Server exception: " + e.getMessage());
        }
    }

    // Broadcast message to all active clients
    public static void broadcast(String message, ClientHandler excludeClient) {
        for (ClientHandler client : clientHandlers) {
            if (client != excludeClient) {
                client.sendMessage(message);
            }
        }
    }

    // Remove client handler upon disconnect
    public static void removeClient(ClientHandler clientHandler) {
        clientHandlers.remove(clientHandler);
    }

    private static class ClientHandler implements Runnable {
        private Socket socket;
        private PrintWriter out;
        private BufferedReader in;
        private String clientName;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

                out.println("Welcome to the Multithreaded Chat Server!");
                out.println("Enter your username: ");
                clientName = in.readLine();
                if (clientName == null || clientName.trim().isEmpty()) {
                    clientName = "User_" + socket.getPort();
                }

                System.out.println("[+] " + clientName + " connected from " + socket.getRemoteSocketAddress());
                broadcast(">>> " + clientName + " joined the chat! <<<", this);

                String message;
                while ((message = in.readLine()) != null) {
                    if (message.equalsIgnoreCase("/quit") || message.equalsIgnoreCase("exit")) {
                        break;
                    }
                    String formatted = "[" + clientName + "]: " + message;
                    System.out.println(formatted);
                    broadcast(formatted, this);
                }
            } catch (IOException e) {
                System.out.println("[-] Connection reset by " + clientName);
            } finally {
                try {
                    socket.close();
                } catch (IOException ignored) {}
                removeClient(this);
                System.out.println("[-] " + clientName + " disconnected.");
                broadcast("<<< " + clientName + " left the chat. >>>", this);
            }
        }

        public void sendMessage(String msg) {
            if (out != null) {
                out.println(msg);
            }
        }
    }
}
