/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 42: Create a program that spawns three threads: one prints even
 *              numbers, another prints odd numbers, and the third prints
 *              prime numbers.
 *
 * Compilation:
 *   gcc -Wall -O2 q42_three_threads_even_odd_prime.c -o q42_three_threads_even_odd_prime -lpthread
 *
 * Execution:
 *   ./q42_three_threads_even_odd_prime [limit: default 20]
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

int is_prime(int n) {
    if (n <= 1) return 0;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) return 0;
    }
    return 1;
}

void* print_even_thread(void* arg) {
    int limit = *(int*)arg;
    printf("[Thread 1: Even Numbers up to %d]:\n  ", limit);
    for (int i = 2; i <= limit; i += 2) {
        printf("%d ", i);
    }
    printf("\n");
    pthread_exit(NULL);
}

void* print_odd_thread(void* arg) {
    int limit = *(int*)arg;
    printf("[Thread 2: Odd Numbers up to %d]:\n  ", limit);
    for (int i = 1; i <= limit; i += 2) {
        printf("%d ", i);
    }
    printf("\n");
    pthread_exit(NULL);
}

void* print_prime_thread(void* arg) {
    int limit = *(int*)arg;
    printf("[Thread 3: Prime Numbers up to %d]:\n  ", limit);
    for (int i = 2; i <= limit; i++) {
        if (is_prime(i)) {
            printf("%d ", i);
        }
    }
    printf("\n");
    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    int limit = (argc > 1) ? atoi(argv[1]) : 20;
    if (limit <= 0) limit = 20;

    pthread_t tid_even, tid_odd, tid_prime;

    printf("============================================================\n");
    printf(" Q42: Three Threads: Even Numbers, Odd Numbers, Prime Numbers\n");
    printf(" Number Limit: %d\n", limit);
    printf("============================================================\n");

    pthread_create(&tid_even, NULL, print_even_thread, &limit);
    pthread_join(tid_even, NULL);

    pthread_create(&tid_odd, NULL, print_odd_thread, &limit);
    pthread_join(tid_odd, NULL);

    pthread_create(&tid_prime, NULL, print_prime_thread, &limit);
    pthread_join(tid_prime, NULL);

    printf("\nAll three threads executed and joined successfully!\n");
    return 0;
}
