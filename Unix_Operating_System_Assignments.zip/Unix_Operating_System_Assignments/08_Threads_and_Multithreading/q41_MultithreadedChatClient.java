/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 41: Develop a multithreaded chat application in Java or C.
 *              [MULTITHREADED CHAT CLIENT - JAVA]
 *
 * Compilation:
 *   javac q41_MultithreadedChatClient.java
 *
 * Execution:
 *   java q41_MultithreadedChatClient [host: default localhost] [port: default 5000]
 */

import java.io.*;
import java.net.*;

public class q41_MultithreadedChatClient {
    public static void main(String[] args) {
        String host = (args.length > 0) ? args[0] : "localhost";
        int port = (args.length > 1) ? Integer.parseInt(args[1]) : 5000;

        System.out.println("============================================================");
        System.out.println(" Q41: Multithreaded Chat Application - Client               ");
        System.out.println(" Connecting to " + host + ":" + port + "...");
        System.out.println("============================================================");

        try {
            Socket socket = new Socket(host, port);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader console = new BufferedReader(new InputStreamReader(System.in));

            // Background thread to listen for incoming messages from server
            Thread listenerThread = new Thread(() -> {
                try {
                    String serverMsg;
                    while ((serverMsg = in.readLine()) != null) {
                        System.out.println(serverMsg);
                    }
                } catch (IOException e) {
                    System.out.println("[Client] Disconnected from server.");
                }
            });
            listenerThread.setDaemon(true);
            listenerThread.start();

            // Main thread sends user input to server
            String userInput;
            while ((userInput = console.readLine()) != null) {
                out.println(userInput);
                if (userInput.equalsIgnoreCase("/quit") || userInput.equalsIgnoreCase("exit")) {
                    break;
                }
            }

            socket.close();
        } catch (IOException e) {
            System.err.println("Client Error: Could not connect to server at " + host + ":" + port);
            System.err.println("Ensure q41_MultithreadedChatServer is running first!");
        }
    }
}
