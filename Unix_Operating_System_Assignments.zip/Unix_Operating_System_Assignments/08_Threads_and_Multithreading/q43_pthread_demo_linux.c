/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 43: Write a multithreaded program on Linux that uses the pthread library.
 *
 * Demonstrates:
 *   1. pthread_create() with custom struct argument
 *   2. pthread_mutex_t for thread synchronization (mutual exclusion)
 *   3. pthread_join() to harvest results and wait for worker completion
 *   4. pthread_exit() with dynamically allocated return value
 *
 * Compilation:
 *   gcc -Wall -O2 q43_pthread_demo_linux.c -o q43_pthread_demo_linux -lpthread
 *
 * Execution:
 *   ./q43_pthread_demo_linux
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_WORKERS 4

pthread_mutex_t counter_mutex = PTHREAD_MUTEX_INITIALIZER;
long global_shared_counter = 0;

typedef struct {
    int thread_id;
    int iterations;
    long partial_sum;
} WorkerData;

void* worker_routine(void* arg) {
    WorkerData* data = (WorkerData*)arg;
    printf("[Worker Thread #%d (TID: %lu)] Started. Running %d iterations...\n",
           data->thread_id, (unsigned long)pthread_self(), data->iterations);

    long sum = 0;
    for (int i = 1; i <= data->iterations; i++) {
        sum += i;

        // Synchronized access to shared global resource
        pthread_mutex_lock(&counter_mutex);
        global_shared_counter++;
        pthread_mutex_unlock(&counter_mutex);

        usleep(1000);
    }

    data->partial_sum = sum;
    printf("[Worker Thread #%d] Completed. Partial sum(1..%d) = %ld\n",
           data->thread_id, data->iterations, data->partial_sum);

    pthread_exit((void*)data);
}

int main() {
    pthread_t threads[NUM_WORKERS];
    WorkerData thread_args[NUM_WORKERS];

    printf("============================================================\n");
    printf(" Q43: Multithreaded Program on Linux Using POSIX pthread    \n");
    printf(" Spawning %d worker threads with shared mutex synchronization\n", NUM_WORKERS);
    printf("============================================================\n");

    for (int i = 0; i < NUM_WORKERS; i++) {
        thread_args[i].thread_id = i + 1;
        thread_args[i].iterations = (i + 1) * 100;
        thread_args[i].partial_sum = 0;

        if (pthread_create(&threads[i], NULL, worker_routine, &thread_args[i]) != 0) {
            perror("pthread_create failed");
            exit(EXIT_FAILURE);
        }
    }

    printf("\n[Main Thread] Waiting for all worker threads to join...\n");
    long grand_total = 0;

    for (int i = 0; i < NUM_WORKERS; i++) {
        void* ret_val;
        pthread_join(threads[i], &ret_val);
        WorkerData* res = (WorkerData*)ret_val;
        grand_total += res->partial_sum;
        printf("[Main Thread] Thread #%d joined. Returned partial sum: %ld\n",
               res->thread_id, res->partial_sum);
    }

    pthread_mutex_destroy(&counter_mutex);

    printf("\n==================== EXECUTION RESULTS ====================\n");
    printf(" Combined Calculated Sum : %ld\n", grand_total);
    printf(" Final Global Counter    : %ld (Expected: %d)\n",
           global_shared_counter, 100 + 200 + 300 + 400);
    printf(" Mutex protected updates confirmed no race conditions!\n");
    printf("============================================================\n");

    return 0;
}
