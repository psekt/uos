/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 13: Write a TCP client-server program where the client sends
 *              a message and the server replies with the reversed string.
 *              [TCP CLIENT - JAVA]
 *
 * Compilation:
 *   javac q13_TCPClientStringReverse.java
 *
 * Execution:
 *   java q13_TCPClientStringReverse [host: default localhost] [port: default 6001]
 */

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class q13_TCPClientStringReverse {
    public static void main(String[] args) {
        String host = (args.length > 0) ? args[0] : "localhost";
        int port = (args.length > 1) ? Integer.parseInt(args[1]) : 6001;

        System.out.println("============================================================");
        System.out.println(" Q13: TCP String Reversal Client (Java)                     ");
        System.out.println(" Connecting to " + host + ":" + port + "...");
        System.out.println("============================================================");

        try (Socket socket = new Socket(host, port);
             BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter a string to reverse: ");
            String input = scanner.nextLine();
            if (input.trim().isEmpty()) {
                input = "Unix Operating System 2026";
                System.out.println("Using default input: " + input);
            }

            System.out.println("[Client] Sending message: \"" + input + "\"");
            writer.println(input);

            String reply = reader.readLine();
            System.out.println("==================== SERVER RESPONSE ====================");
            System.out.println("Original String : " + input);
            System.out.println("Reversed String : " + reply);
            System.out.println("=========================================================");

        } catch (IOException e) {
            System.err.println("Client Error: " + e.getMessage());
            System.err.println("Make sure q13_TCPServerStringReverse is running!");
        }
    }
}
