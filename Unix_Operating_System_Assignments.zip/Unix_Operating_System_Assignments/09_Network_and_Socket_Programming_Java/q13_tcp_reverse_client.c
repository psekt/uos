/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 13: Write a TCP client-server program in C where the client sends
 *              a message and the server replies with the reversed string.
 *              [COMPANION C IMPLEMENTATION - CLIENT]
 *
 * Compilation:
 *   gcc -Wall -O2 q13_tcp_reverse_client.c -o q13_tcp_reverse_client
 *
 * Execution:
 *   ./q13_tcp_reverse_client
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#ifdef _WIN32
#include <winsock2.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#endif

#define PORT 6002
#define BUFFER_SIZE 512

int main() {
#ifdef _WIN32
    WSADATA wsa;
    WSAStartup(MAKEWORD(2, 2), &wsa);
#endif

    int sock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in serv_addr;
    char buffer[BUFFER_SIZE];

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Connection Failed");
        exit(EXIT_FAILURE);
    }

    const char *msg = "Operating Systems Unix 2026\n";
    printf("[C Client] Sending message: %s", msg);
    send(sock, msg, strlen(msg), 0);

    ssize_t n = recv(sock, buffer, sizeof(buffer) - 1, 0);
    if (n > 0) {
        buffer[n] = '\0';
        printf("[C Client] Server Reply: %s\n", buffer);
    }

#ifdef _WIN32
    closesocket(sock);
    WSACleanup();
#else
    close(sock);
#endif
    return 0;
}
