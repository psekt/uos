/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 15: Echo client to test both Iterative and Concurrent Echo Servers.
 *
 * Compilation:
 *   javac q15_TCPEchoClient.java
 *
 * Execution:
 *   java q15_TCPEchoClient [host: localhost] [port: 8001 or 8002]
 */

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class q15_TCPEchoClient {
    public static void main(String[] args) {
        String host = (args.length > 0) ? args[0] : "localhost";
        int port = (args.length > 1) ? Integer.parseInt(args[1]) : 8001;

        System.out.println("============================================================");
        System.out.println(" Q15: TCP Echo Client (Java)                                ");
        System.out.println(" Connected to: " + host + ":" + port);
        System.out.println(" Type any message to echo. Type 'quit' to exit.             ");
        System.out.println("============================================================");

        try (Socket socket = new Socket(host, port);
             BufferedReader serverIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter serverOut = new PrintWriter(socket.getOutputStream(), true);
             Scanner console = new Scanner(System.in)) {

            while (true) {
                System.out.print("Client > ");
                String input = console.nextLine();
                serverOut.println(input);

                if (input.equalsIgnoreCase("quit") || input.equalsIgnoreCase("exit")) {
                    break;
                }

                String echoResponse = serverIn.readLine();
                System.out.println("Server Response: " + echoResponse);
            }
        } catch (IOException e) {
            System.err.println("Client Error: " + e.getMessage());
        }
    }
}
