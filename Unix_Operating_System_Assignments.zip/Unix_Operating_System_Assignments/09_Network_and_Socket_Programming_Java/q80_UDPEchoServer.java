/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 80: Implement an echo server over UDP using iterative and/or
 *              concurrent logic. [JAVA]
 *
 * Compilation:
 *   javac q80_UDPEchoServer.java
 *
 * Execution:
 *   java q80_UDPEchoServer [port: default 8080]
 */

import java.io.*;
import java.net.*;

public class q80_UDPEchoServer {
    private static final int PORT = 8080;

    public static void main(String[] args) {
        int port = (args.length > 0) ? Integer.parseInt(args[0]) : PORT;

        System.out.println("============================================================");
        System.out.println(" Q80: UDP Echo Server (Java)                                ");
        System.out.println(" Listening on UDP port: " + port);
        System.out.println("============================================================");

        try (DatagramSocket socket = new DatagramSocket(port)) {
            byte[] buf = new byte[1024];

            while (true) {
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                socket.receive(packet);

                String msg = new String(packet.getData(), 0, packet.getLength());
                System.out.println("[UDP Server] Echoing back message: " + msg);

                String echoMsg = "UDP-ECHO: " + msg;
                byte[] echoBytes = echoMsg.getBytes();
                DatagramPacket echoPacket = new DatagramPacket(echoBytes, echoBytes.length, packet.getAddress(), packet.getPort());
                socket.send(echoPacket);
            }
        } catch (IOException e) {
            System.err.println("UDP Echo Server error: " + e.getMessage());
        }
    }
}
