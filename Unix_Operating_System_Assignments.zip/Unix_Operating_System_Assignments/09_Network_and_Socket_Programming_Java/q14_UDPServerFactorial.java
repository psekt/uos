/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 14: Implement a UDP client-server program where the client sends
 *              numbers and the server responds with their factorial.
 *              [UDP SERVER - JAVA]
 *
 * Compilation:
 *   javac q14_UDPServerFactorial.java
 *
 * Execution:
 *   Terminal 1: java q14_UDPServerFactorial [port: default 7001]
 *   Terminal 2: java q14_UDPClientFactorial [host: localhost] [port: 7001]
 */

import java.io.*;
import java.net.*;
import java.math.BigInteger;

public class q14_UDPServerFactorial {
    private static final int DEFAULT_PORT = 7001;

    public static BigInteger factorial(int n) {
        if (n < 0) return BigInteger.ZERO;
        BigInteger result = BigInteger.ONE;
        for (int i = 2; i <= n; i++) {
            result = result.multiply(BigInteger.valueOf(i));
        }
        return result;
    }

    public static void main(String[] args) {
        int port = (args.length > 0) ? Integer.parseInt(args[0]) : DEFAULT_PORT;

        System.out.println("============================================================");
        System.out.println(" Q14: UDP Factorial Computation Server (Java)               ");
        System.out.println(" Listening for datagram packets on UDP port: " + port);
        System.out.println("============================================================");

        try (DatagramSocket socket = new DatagramSocket(port)) {
            byte[] receiveBuffer = new byte[1024];

            while (true) {
                DatagramPacket receivePacket = new DatagramPacket(receiveBuffer, receiveBuffer.length);
                socket.receive(receivePacket);

                String receivedStr = new String(receivePacket.getData(), 0, receivePacket.getLength()).trim();
                System.out.println("\n[UDP Server] Received packet from: " + receivePacket.getAddress() + ":" + receivePacket.getPort());
                System.out.println("[UDP Server] Requested number: " + receivedStr);

                String responseStr;
                try {
                    int number = Integer.parseInt(receivedStr);
                    if (number < 0) {
                        responseStr = "Error: Factorial of negative number is undefined.";
                    } else if (number > 100) {
                        responseStr = "Error: Number too large (limit <= 100).";
                    } else {
                        BigInteger fact = factorial(number);
                        responseStr = "Factorial(" + number + ") = " + fact.toString();
                    }
                } catch (NumberFormatException e) {
                    responseStr = "Error: Invalid integer input.";
                }

                byte[] sendBuffer = responseStr.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(
                        sendBuffer, sendBuffer.length, receivePacket.getAddress(), receivePacket.getPort()
                );
                socket.send(sendPacket);
                System.out.println("[UDP Server] Replied: " + responseStr);
            }
        } catch (IOException e) {
            System.err.println("UDP Server Error: " + e.getMessage());
        }
    }
}
