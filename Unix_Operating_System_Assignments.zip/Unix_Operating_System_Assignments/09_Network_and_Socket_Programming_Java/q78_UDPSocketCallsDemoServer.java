/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 78: Implement a UDP program demonstrating socket system calls
 *              in C or Python. [JAVA IMPLEMENTATION]
 *
 * Demonstrates:
 *   1. socket() creation (new DatagramSocket)
 *   2. bind() to local port
 *   3. recvfrom() (socket.receive)
 *   4. sendto() (socket.send)
 *   5. close()
 *
 * Compilation:
 *   javac q78_UDPSocketCallsDemoServer.java
 *
 * Execution:
 *   Terminal 1: java q78_UDPSocketCallsDemoServer
 *   Terminal 2: java q78_UDPSocketCallsDemoClient
 */

import java.io.*;
import java.net.*;

public class q78_UDPSocketCallsDemoServer {
    private static final int PORT = 7878;

    public static void main(String[] args) {
        System.out.println("============================================================");
        System.out.println(" Q78: UDP Socket System Calls Demonstration - Server        ");
        System.out.println("============================================================");

        try {
            // 1 & 2. socket() and bind()
            System.out.println("[SysCall 1 & 2: socket() + bind()] Creating DatagramSocket on port " + PORT);
            DatagramSocket socket = new DatagramSocket(PORT);

            // 3. recvfrom()
            byte[] inBuffer = new byte[1024];
            DatagramPacket packet = new DatagramPacket(inBuffer, inBuffer.length);
            System.out.println("[SysCall 3: recvfrom()] Waiting for datagram packet...");
            socket.receive(packet);

            String text = new String(packet.getData(), 0, packet.getLength());
            System.out.println(">>> Datagram received from " + packet.getAddress() + ":" + packet.getPort());
            System.out.println("    Payload: \"" + text + "\"");

            // 4. sendto()
            String reply = "UDP SERVER CONFIRMATION: Packet received successfully!";
            byte[] outBuffer = reply.getBytes();
            DatagramPacket replyPacket = new DatagramPacket(outBuffer, outBuffer.length, packet.getAddress(), packet.getPort());
            System.out.println("[SysCall 4: sendto()] Sending response datagram...");
            socket.send(replyPacket);

            // 5. close()
            System.out.println("[SysCall 5: close()] Closing UDP socket.");
            socket.close();
            System.out.println("UDP lifecycle demonstrated cleanly!");

        } catch (IOException e) {
            System.err.println("UDP Error: " + e.getMessage());
        }
    }
}
