/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 79: Implement an echo server over TCP using iterative and/or
 *              concurrent logic. [JAVA]
 *
 * Compilation:
 *   javac q79_TCPEchoServer.java
 *
 * Execution:
 *   java q79_TCPEchoServer [port: default 7979]
 */

import java.io.*;
import java.net.*;

public class q79_TCPEchoServer {
    private static final int PORT = 7979;

    public static void main(String[] args) {
        int port = (args.length > 0) ? Integer.parseInt(args[0]) : PORT;

        System.out.println("============================================================");
        System.out.println(" Q79: TCP Echo Server (Concurrent Multithreaded Logic)      ");
        System.out.println(" Listening on port: " + port);
        System.out.println("============================================================");

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            while (true) {
                Socket socket = serverSocket.accept();
                new Thread(() -> {
                    try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                         PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

                        String line;
                        while ((line = in.readLine()) != null) {
                            if (line.equalsIgnoreCase("quit") || line.equalsIgnoreCase("exit")) break;
                            out.println("ECHO-79: " + line);
                        }
                    } catch (IOException ignored) {}
                }).start();
            }
        } catch (IOException e) {
            System.err.println("Server Error: " + e.getMessage());
        }
    }
}
