/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 25: UDP File Transfer Client with ACKs
 *
 * Compilation:
 *   javac q25_UDPClientFileTransfer.java
 *
 * Execution:
 *   java q25_UDPClientFileTransfer [file_to_request] [output_filename]
 */

import java.io.*;
import java.net.*;

public class q25_UDPClientFileTransfer {
    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 2525;

    public static void main(String[] args) {
        String filenameToRequest = (args.length > 0) ? args[0] : "q25_sample_input.txt";
        String outputFilename = (args.length > 1) ? args[1] : "q25_received_output.txt";

        System.out.println("============================================================");
        System.out.println(" Q25: UDP File Transfer Client (Java)                       ");
        System.out.println(" Requesting: " + filenameToRequest + " -> Saving to: " + outputFilename);
        System.out.println("============================================================");

        try (DatagramSocket socket = new DatagramSocket()) {
            socket.setSoTimeout(5000);
            InetAddress serverAddr = InetAddress.getByName(SERVER_HOST);

            // Step 1: Send file request
            byte[] reqData = filenameToRequest.getBytes();
            DatagramPacket reqPacket = new DatagramPacket(reqData, reqData.length, serverAddr, SERVER_PORT);
            socket.send(reqPacket);
            System.out.println("[Client] Request sent. Receiving file chunks...");

            // Step 2: Receive chunks and send ACK for each
            try (FileOutputStream fos = new FileOutputStream(outputFilename)) {
                byte[] inBuf = new byte[2048];
                int totalBytesReceived = 0;

                while (true) {
                    DatagramPacket packet = new DatagramPacket(inBuf, inBuf.length);
                    socket.receive(packet);

                    DataInputStream dis = new DataInputStream(new ByteArrayInputStream(packet.getData()));
                    int seqNo = dis.readInt();
                    int length = dis.readInt();
                    boolean isEOF = dis.readBoolean();

                    if (isEOF) {
                        System.out.println("\n[Client] EOF received. File transfer successfully completed!");
                        break;
                    }

                    byte[] chunk = new byte[length];
                    dis.readFully(chunk);
                    fos.write(chunk);
                    totalBytesReceived += length;

                    System.out.printf("[Client] Received Chunk #%d (%d bytes). Sending ACK...\n", seqNo, length);

                    // Send ACK
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    DataOutputStream dos = new DataOutputStream(baos);
                    dos.writeInt(seqNo);
                    byte[] ackData = baos.toByteArray();
                    DatagramPacket ackPacket = new DatagramPacket(ackData, ackData.length, packet.getAddress(), packet.getPort());
                    socket.send(ackPacket);
                }

                System.out.println("Total Bytes Received: " + totalBytesReceived);
                System.out.println("Saved to: " + outputFilename);
            }
        } catch (IOException e) {
            System.err.println("Client Error: " + e.getMessage());
        }
    }
}
