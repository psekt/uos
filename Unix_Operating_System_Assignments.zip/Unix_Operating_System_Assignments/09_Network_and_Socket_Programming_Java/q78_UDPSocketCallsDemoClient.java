/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 78: UDP Socket Calls Demo - Client
 *
 * Compilation:
 *   javac q78_UDPSocketCallsDemoClient.java
 *
 * Execution:
 *   java q78_UDPSocketCallsDemoClient
 */

import java.io.*;
import java.net.*;

public class q78_UDPSocketCallsDemoClient {
    public static void main(String[] args) {
        System.out.println("============================================================");
        System.out.println(" Q78: UDP Socket System Calls Demonstration - Client        ");
        System.out.println("============================================================");

        try {
            // socket()
            DatagramSocket socket = new DatagramSocket();
            InetAddress server = InetAddress.getByName("localhost");

            // sendto()
            String message = "Hello UDP Datagram Socket System Call!";
            byte[] out = message.getBytes();
            DatagramPacket sendPkt = new DatagramPacket(out, out.length, server, 7878);
            System.out.println("[SysCall: sendto()] Sending: \"" + message + "\"");
            socket.send(sendPkt);

            // recvfrom()
            byte[] in = new byte[1024];
            DatagramPacket recvPkt = new DatagramPacket(in, in.length);
            System.out.println("[SysCall: recvfrom()] Awaiting server response...");
            socket.receive(recvPkt);

            String reply = new String(recvPkt.getData(), 0, recvPkt.getLength());
            System.out.println("Server Response: " + reply);

            // close()
            socket.close();
            System.out.println("[SysCall: close()] Client closed.");

        } catch (IOException e) {
            System.err.println("Client Error: " + e.getMessage());
        }
    }
}
