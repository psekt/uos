/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 15: Write a program to implement an Echo Server using TCP sockets
 *              (both iterative and concurrent versions).
 *              [PART 1: ITERATIVE TCP ECHO SERVER - JAVA]
 *
 * Concept:
 *   An iterative server serves one client to completion before accepting
 *   the next connection.
 *
 * Compilation:
 *   javac q15_TCPEchoServerIterative.java
 *
 * Execution:
 *   Terminal 1: java q15_TCPEchoServerIterative [port: default 8001]
 *   Terminal 2: java q15_TCPEchoClient [host: localhost] [port: 8001]
 */

import java.io.*;
import java.net.*;

public class q15_TCPEchoServerIterative {
    private static final int DEFAULT_PORT = 8001;

    public static void main(String[] args) {
        int port = (args.length > 0) ? Integer.parseInt(args[0]) : DEFAULT_PORT;

        System.out.println("============================================================");
        System.out.println(" Q15: Iterative TCP Echo Server (Java)                      ");
        System.out.println(" Listening on port: " + port + " (Single-threaded iterative mode)");
        System.out.println("============================================================");

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            while (true) {
                System.out.println("\n[Iterative Server] Waiting for client to connect...");
                try (Socket clientSocket = serverSocket.accept();
                     BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                     PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {

                    System.out.println("[Iterative Server] Serving client: " + clientSocket.getRemoteSocketAddress());
                    String line;
                    while ((line = in.readLine()) != null) {
                        if (line.equalsIgnoreCase("quit") || line.equalsIgnoreCase("exit")) {
                            break;
                        }
                        System.out.println("  [Received]: \"" + line + "\" -> Echoing back");
                        out.println("ECHO: " + line);
                    }
                    System.out.println("[Iterative Server] Client finished. Ready for next client.");
                }
            }
        } catch (IOException e) {
            System.err.println("Server Error: " + e.getMessage());
        }
    }
}
