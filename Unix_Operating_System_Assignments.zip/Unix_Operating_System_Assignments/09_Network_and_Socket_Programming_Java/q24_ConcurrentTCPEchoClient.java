/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 24: Concurrent TCP Echo Client
 *
 * Compilation:
 *   javac q24_ConcurrentTCPEchoClient.java
 *
 * Execution:
 *   java q24_ConcurrentTCPEchoClient [host: localhost] [port: 2424]
 */

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class q24_ConcurrentTCPEchoClient {
    public static void main(String[] args) {
        String host = (args.length > 0) ? args[0] : "localhost";
        int port = (args.length > 1) ? Integer.parseInt(args[1]) : 2424;

        System.out.println("Connecting to Concurrent Echo Server at " + host + ":" + port + "...");

        try (Socket socket = new Socket(host, port);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             Scanner scanner = new Scanner(System.in)) {

            System.out.println("Server Welcome: " + in.readLine());

            while (true) {
                System.out.print("Client > ");
                String text = scanner.nextLine();
                out.println(text);
                if (text.equalsIgnoreCase("quit") || text.equalsIgnoreCase("exit")) break;

                String reply = in.readLine();
                System.out.println(reply);
            }
        } catch (IOException e) {
            System.err.println("Client Error: " + e.getMessage());
        }
    }
}
