/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 77: TCP Socket Calls Demo - Client
 *
 * Compilation:
 *   javac q77_TCPSocketCallsDemoClient.java
 *
 * Execution:
 *   java q77_TCPSocketCallsDemoClient
 */

import java.io.*;
import java.net.*;

public class q77_TCPSocketCallsDemoClient {
    public static void main(String[] args) {
        System.out.println("============================================================");
        System.out.println(" Q77: TCP Socket System Calls Demonstration - Client        ");
        System.out.println("============================================================");

        try {
            // socket() + connect()
            System.out.println("[SysCall: socket() + connect()] Connecting to localhost:7777...");
            Socket socket = new Socket("localhost", 7777);
            System.out.println("Connected successfully!");

            // write()
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            String payload = "Hello TCP Socket System Calls!";
            System.out.println("[SysCall: write()] Sending: " + payload);
            out.println(payload);

            // read()
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String response = in.readLine();
            System.out.println("[SysCall: read()] Received: " + response);

            // close()
            System.out.println("[SysCall: close()] Closing client socket.");
            socket.close();

        } catch (IOException e) {
            System.err.println("Client Error: " + e.getMessage());
        }
    }
}
