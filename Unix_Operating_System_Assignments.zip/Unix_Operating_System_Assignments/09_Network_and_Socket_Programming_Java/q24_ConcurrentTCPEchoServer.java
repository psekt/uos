/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 24: Concurrent TCP echo server: Implement an echo server using
 *              TCP sockets that handles multiple clients concurrently using
 *              fork() or threads. [JAVA MULTITHREADED IMPLEMENTATION]
 *
 * Compilation:
 *   javac q24_ConcurrentTCPEchoServer.java
 *
 * Execution:
 *   Terminal 1: java q24_ConcurrentTCPEchoServer [port: default 2424]
 *   Terminal 2: java q24_ConcurrentTCPEchoClient [host: localhost] [port: 2424]
 *   Terminal 3: java q24_ConcurrentTCPEchoClient [host: localhost] [port: 2424]
 */

import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class q24_ConcurrentTCPEchoServer {
    private static final int DEFAULT_PORT = 2424;
    private static final ExecutorService threadPool = Executors.newCachedThreadPool();

    public static void main(String[] args) {
        int port = (args.length > 0) ? Integer.parseInt(args[0]) : DEFAULT_PORT;

        System.out.println("============================================================");
        System.out.println(" Q24: Concurrent TCP Echo Server Using Java Threads         ");
        System.out.println(" Server listening on port: " + port);
        System.out.println("============================================================");

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("[+] New Client Connected: " + clientSocket.getRemoteSocketAddress());
                threadPool.submit(() -> handleClient(clientSocket));
            }
        } catch (IOException e) {
            System.err.println("Server Error: " + e.getMessage());
        } finally {
            threadPool.shutdown();
        }
    }

    private static void handleClient(Socket socket) {
        String clientInfo = socket.getRemoteSocketAddress().toString();
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

            out.println("Connected to Concurrent TCP Echo Server. Type messages below:");

            String line;
            while ((line = in.readLine()) != null) {
                if (line.equalsIgnoreCase("quit") || line.equalsIgnoreCase("exit")) break;
                System.out.println("[" + Thread.currentThread().getName() + " | " + clientInfo + "] Echoing: " + line);
                out.println("[ECHO from Server]: " + line);
            }
        } catch (IOException e) {
            System.out.println("Client session ended: " + clientInfo);
        } finally {
            try { socket.close(); } catch (IOException ignored) {}
            System.out.println("[-] Client connection closed: " + clientInfo);
        }
    }
}
