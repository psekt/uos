/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 26: Distributed computation server: Create a TCP server that accepts
 *              computation requests (factorial, matrix multiplication, string reversal)
 *              from multiple clients and returns results.
 *              [DISTRIBUTED COMPUTATION SERVER - JAVA]
 *
 * Compilation:
 *   javac q26_TCPDistributedComputeServer.java
 *
 * Execution:
 *   Terminal 1: java q26_TCPDistributedComputeServer [port: default 2626]
 *   Terminal 2: java q26_TCPDistributedComputeClient [host: localhost] [port: 2626]
 */

import java.io.*;
import java.net.*;
import java.math.BigInteger;

public class q26_TCPDistributedComputeServer {
    private static final int PORT = 2626;

    public static void main(String[] args) {
        int port = (args.length > 0) ? Integer.parseInt(args[0]) : PORT;

        System.out.println("============================================================");
        System.out.println(" Q26: Distributed Computation TCP Server (Java)             ");
        System.out.println(" Supported Tasks: Factorial, Matrix Multiplication, String Reversal");
        System.out.println(" Server listening on port: " + port);
        System.out.println("============================================================");

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            while (true) {
                Socket socket = serverSocket.accept();
                new Thread(() -> handleComputation(socket)).start();
            }
        } catch (IOException e) {
            System.err.println("Server Error: " + e.getMessage());
        }
    }

    private static void handleClientRequest(BufferedReader in, PrintWriter out) throws IOException {
        String command = in.readLine();
        if (command == null) return;

        System.out.println("[Compute Engine] Processing: " + command);
        String[] parts = command.split("\\|");
        String task = parts[0].trim().toUpperCase();

        switch (task) {
            case "FACTORIAL": {
                int n = Integer.parseInt(parts[1].trim());
                BigInteger fact = BigInteger.ONE;
                for (int i = 2; i <= n; i++) fact = fact.multiply(BigInteger.valueOf(i));
                out.println("RESULT|Factorial(" + n + ") = " + fact.toString());
                break;
            }
            case "REVERSE": {
                String str = parts[1];
                String rev = new StringBuilder(str).reverse().toString();
                out.println("RESULT|Reversed: " + rev);
                break;
            }
            case "MATRIX_MUL": {
                // Multiplies two 2x2 matrices passed as a,b,c,d e,f,g,h
                // A = [a,b; c,d], B = [e,f; g,h]
                String[] nums = parts[1].trim().split(" ");
                int a = Integer.parseInt(nums[0]), b = Integer.parseInt(nums[1]);
                int c = Integer.parseInt(nums[2]), d = Integer.parseInt(nums[3]);
                int e = Integer.parseInt(nums[4]), f = Integer.parseInt(nums[5]);
                int g = Integer.parseInt(nums[6]), h = Integer.parseInt(nums[7]);

                int r11 = a * e + b * g;
                int r12 = a * f + b * h;
                int r21 = c * e + d * g;
                int r22 = c * f + d * h;

                out.println("RESULT|Matrix Product: [[" + r11 + ", " + r12 + "], [" + r21 + ", " + r22 + "]]");
                break;
            }
            default:
                out.println("ERROR|Unknown task requested.");
        }
    }

    private static void handleComputation(Socket socket) {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {
            handleClientRequest(in, out);
        } catch (Exception e) {
            System.err.println("Task Error: " + e.getMessage());
        } finally {
            try { socket.close(); } catch (IOException ignored) {}
        }
    }
}
