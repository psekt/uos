/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 14: UDP Factorial Client in C
 *
 * Compilation:
 *   gcc -Wall -O2 q14_udp_factorial_client.c -o q14_udp_factorial_client
 *
 * Execution:
 *   ./q14_udp_factorial_client
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#ifdef _WIN32
#include <winsock2.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#endif

#define PORT 7002

int main() {
#ifdef _WIN32
    WSADATA wsa; WSAStartup(MAKEWORD(2, 2), &wsa);
#endif
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in servaddr;
    socklen_t len = sizeof(servaddr);
    char buffer[256];

    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    const char *number_str = "6";
    printf("[UDP C Client] Sending number: %s\n", number_str);
    sendto(sockfd, number_str, strlen(number_str), 0, (const struct sockaddr *)&servaddr, len);

    ssize_t n = recvfrom(sockfd, buffer, sizeof(buffer) - 1, 0, NULL, NULL);
    if (n > 0) {
        buffer[n] = '\0';
        printf("[UDP C Client] Received Result: %s\n", buffer);
    }

#ifdef _WIN32
    closesocket(sockfd); WSACleanup();
#else
    close(sockfd);
#endif
    return 0;
}
