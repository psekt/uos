/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 25: UDP file transfer: Implement a client-server application where
 *              the client requests a file and the server sends it via UDP in
 *              chunks, with acknowledgments.
 *              [UDP FILE TRANSFER SERVER - JAVA]
 *
 * Compilation:
 *   javac q25_UDPServerFileTransfer.java
 *
 * Execution:
 *   Terminal 1: java q25_UDPServerFileTransfer [port: default 2525]
 *   Terminal 2: java q25_UDPClientFileTransfer [file_to_request]
 */

import java.io.*;
import java.net.*;
import java.util.Arrays;

public class q25_UDPServerFileTransfer {
    private static final int PORT = 2525;
    private static final int CHUNK_SIZE = 512;

    public static void main(String[] args) {
        System.out.println("============================================================");
        System.out.println(" Q25: UDP File Transfer Server with ACKs (Java)             ");
        System.out.println(" Listening on UDP port: " + PORT);
        System.out.println("============================================================");

        
        try (DatagramSocket socket = new DatagramSocket(PORT)) {
            socket.setSoTimeout(3000); // 3 seconds timeout for ACK receipt
            byte[] buffer = new byte[1024];

            while (true) {
                System.out.println("\n[Server] Waiting for file request...");
                DatagramPacket reqPacket = new DatagramPacket(buffer, buffer.length);
                try {
                    socket.setSoTimeout(0); // infinite wait for new client request
                    socket.receive(reqPacket);
                } catch (IOException e) {
                    continue;
                }

                String requestedFilename = new String(reqPacket.getData(), 0, reqPacket.getLength()).trim();
                InetAddress clientAddr = reqPacket.getAddress();
                int clientPort = reqPacket.getPort();
                System.out.println("[Server] Client (" + clientAddr + ":" + clientPort + ") requested file: '" + requestedFilename + "'");

                File file = new File(requestedFilename);
                if (!file.exists()) {
                    // Create dummy demo file if missing
                    try (PrintWriter pw = new PrintWriter(file)) {
                        for (int i = 1; i <= 20; i++) {
                            pw.println("Q25 UDP File Transfer Packet Demo Chunk Line #" + i);
                        }
                    }
                    System.out.println("[Server] Generated sample file: " + requestedFilename);
                }

                // Send file chunks with Stop-and-Wait ACK protocol
                socket.setSoTimeout(3000);
                try (FileInputStream fis = new FileInputStream(file)) {
                    byte[] fileData = new byte[CHUNK_SIZE];
                    int bytesRead;
                    int seqNo = 0;

                    while ((bytesRead = fis.read(fileData)) != -1) {
                        seqNo++;
                        boolean ackReceived = false;
                        int retries = 0;

                        while (!ackReceived && retries < 5) {
                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            DataOutputStream dos = new DataOutputStream(baos);
                            dos.writeInt(seqNo);
                            dos.writeInt(bytesRead); // length
                            dos.writeBoolean(false); // isEOF
                            dos.write(fileData, 0, bytesRead);

                            byte[] packetBytes = baos.toByteArray();
                            DatagramPacket dataPacket = new DatagramPacket(packetBytes, packetBytes.length, clientAddr, clientPort);
                            socket.send(dataPacket);
                            System.out.printf("[Server] Sent Chunk #%d (%d bytes). Waiting for ACK...\n", seqNo, bytesRead);

                            // Wait for ACK
                            try {
                                byte[] ackBuf = new byte[128];
                                DatagramPacket ackPacket = new DatagramPacket(ackBuf, ackBuf.length);
                                socket.receive(ackPacket);

                                DataInputStream dis = new DataInputStream(new ByteArrayInputStream(ackPacket.getData()));
                                int ackSeq = dis.readInt();
                                if (ackSeq == seqNo) {
                                    System.out.println("  [Server] Received ACK #" + ackSeq);
                                    ackReceived = true;
                                }
                            } catch (SocketTimeoutException te) {
                                retries++;
                                System.out.println("  [Timeout] Resending Chunk #" + seqNo + " (Attempt " + retries + ")");
                            }
                        }
                    }

                    // Send EOF Packet
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    DataOutputStream dos = new DataOutputStream(baos);
                    dos.writeInt(++seqNo);
                    dos.writeInt(0);
                    dos.writeBoolean(true); // isEOF
                    byte[] eofBytes = baos.toByteArray();
                    socket.send(new DatagramPacket(eofBytes, eofBytes.length, clientAddr, clientPort));
                    System.out.println("[Server] File transmission complete (EOF packet sent)!");
                }
            }
        } catch (IOException e) {
            System.err.println("Server Error: " + e.getMessage());
        }
    }
}
