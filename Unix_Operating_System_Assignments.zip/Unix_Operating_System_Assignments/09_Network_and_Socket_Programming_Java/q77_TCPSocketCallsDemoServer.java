/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 77: Implement a TCP program demonstrating socket system calls
 *              in C or Python. [JAVA IMPLEMENTATION]
 *
 * Demonstrates:
 *   1. socket() creation (new ServerSocket)
 *   2. bind() to local port
 *   3. listen() for incoming requests
 *   4. accept() client connection
 *   5. read() / write() data streaming
 *   6. close() socket cleanup
 *
 * Compilation:
 *   javac q77_TCPSocketCallsDemoServer.java
 *
 * Execution:
 *   Terminal 1: java q77_TCPSocketCallsDemoServer
 *   Terminal 2: java q77_TCPSocketCallsDemoClient
 */

import java.io.*;
import java.net.*;

public class q77_TCPSocketCallsDemoServer {
    private static final int PORT = 7777;

    public static void main(String[] args) {
        System.out.println("============================================================");
        System.out.println(" Q77: TCP Socket System Calls Demonstration - Server        ");
        System.out.println("============================================================");

        try {
            // 1 & 2. socket() and bind()
            System.out.println("[SysCall 1 & 2: socket() + bind()] Creating ServerSocket bound to port " + PORT);
            ServerSocket serverSocket = new ServerSocket(PORT);

            // 3. listen()
            System.out.println("[SysCall 3: listen()] Server socket is now listening for connections...");

            // 4. accept()
            System.out.println("[SysCall 4: accept()] Waiting (blocking) for client connection...");
            Socket clientSocket = serverSocket.accept();
            System.out.println(">>> Connection accepted from: " + clientSocket.getRemoteSocketAddress());

            // 5. read() & write()
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            String message = in.readLine();
            System.out.println("[SysCall 5: read()] Received: \"" + message + "\"");

            String reply = "ACKNOWLEDGED by TCP Server: (" + message.toUpperCase() + ")";
            out.println(reply);
            System.out.println("[SysCall 5: write()] Sent response: \"" + reply + "\"");

            // 6. close()
            System.out.println("[SysCall 6: close()] Closing sockets...");
            clientSocket.close();
            serverSocket.close();
            System.out.println("TCP Socket lifecycle completed successfully!");

        } catch (IOException e) {
            System.err.println("Socket error: " + e.getMessage());
        }
    }
}
