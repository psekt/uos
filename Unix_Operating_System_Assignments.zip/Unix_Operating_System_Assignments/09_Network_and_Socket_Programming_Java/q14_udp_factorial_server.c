/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 14: UDP Factorial Server in C
 *
 * Compilation:
 *   gcc -Wall -O2 q14_udp_factorial_server.c -o q14_udp_factorial_server
 *
 * Execution:
 *   ./q14_udp_factorial_server
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#ifdef _WIN32
#include <winsock2.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <sys/socket.h>
#include <netinet/in.h>
#endif

#define PORT 7002

long long factorial(int n) {
    if (n <= 1) return 1;
    long long f = 1;
    for (int i = 2; i <= n; i++) f *= i;
    return f;
}

int main() {
#ifdef _WIN32
    WSADATA wsa; WSAStartup(MAKEWORD(2, 2), &wsa);
#endif
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in servaddr, cliaddr;
    socklen_t len = sizeof(cliaddr);
    char buffer[256];

    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(PORT);

    bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr));

    printf("Q14: UDP Factorial Server (C) running on port %d...\n", PORT);
    ssize_t n = recvfrom(sockfd, buffer, sizeof(buffer) - 1, 0, (struct sockaddr *)&cliaddr, &len);
    if (n > 0) {
        buffer[n] = '\0';
        int num = atoi(buffer);
        long long res = factorial(num);
        char reply[128];
        snprintf(reply, sizeof(reply), "Factorial(%d) = %lld", num, res);
        printf("[UDP C Server] Computed: %s\n", reply);
        sendto(sockfd, reply, strlen(reply), 0, (const struct sockaddr *)&cliaddr, len);
    }

#ifdef _WIN32
    closesocket(sockfd); WSACleanup();
#else
    close(sockfd);
#endif
    return 0;
}
