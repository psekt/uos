/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 15: Write a program to implement an Echo Server using TCP sockets
 *              (both iterative and concurrent versions).
 *              [PART 2: CONCURRENT TCP ECHO SERVER - JAVA]
 *
 * Concept:
 *   Spawns a new worker thread for each incoming client, allowing multiple
 *   clients to be served concurrently simultaneously.
 *
 * Compilation:
 *   javac q15_TCPEchoServerConcurrent.java
 *
 * Execution:
 *   Terminal 1: java q15_TCPEchoServerConcurrent [port: default 8002]
 *   Terminal 2: java q15_TCPEchoClient [host: localhost] [port: 8002]
 */

import java.io.*;
import java.net.*;

public class q15_TCPEchoServerConcurrent {
    private static final int DEFAULT_PORT = 8002;

    public static void main(String[] args) {
        int port = (args.length > 0) ? Integer.parseInt(args[0]) : DEFAULT_PORT;

        System.out.println("============================================================");
        System.out.println(" Q15: Concurrent TCP Echo Server (Java Multithreaded)       ");
        System.out.println(" Listening on port: " + port);
        System.out.println("============================================================");

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("[Concurrent Server] Spawning thread for client: " + clientSocket.getRemoteSocketAddress());
                new Thread(new ClientHandler(clientSocket)).start();
            }
        } catch (IOException e) {
            System.err.println("Concurrent Server Error: " + e.getMessage());
        }
    }

    private static class ClientHandler implements Runnable {
        private final Socket socket;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                 PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {

                String line;
                while ((line = in.readLine()) != null) {
                    if (line.equalsIgnoreCase("quit") || line.equalsIgnoreCase("exit")) break;
                    System.out.println("  [Thread " + Thread.currentThread().getName() + "]: Echoing \"" + line + "\"");
                    out.println("CONCURRENT_ECHO: " + line);
                }
            } catch (IOException e) {
                System.out.println("[-] Client disconnected: " + socket.getRemoteSocketAddress());
            } finally {
                try { socket.close(); } catch (IOException ignored) {}
            }
        }
    }
}
