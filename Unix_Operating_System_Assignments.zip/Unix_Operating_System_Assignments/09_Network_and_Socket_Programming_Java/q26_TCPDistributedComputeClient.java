/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 26: Distributed Computation Client
 *
 * Compilation:
 *   javac q26_TCPDistributedComputeClient.java
 *
 * Execution:
 *   java q26_TCPDistributedComputeClient
 */

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class q26_TCPDistributedComputeClient {
    public static void main(String[] args) {
        String host = "localhost";
        int port = 2626;

        System.out.println("============================================================");
        System.out.println(" Q26: Distributed Computation Client                        ");
        System.out.println(" 1. Factorial\n 2. String Reversal\n 3. 2x2 Matrix Multiplication");
        System.out.println("============================================================");

        Scanner sc = new Scanner(System.in);
        System.out.print("Select computation (1-3): ");
        int choice = sc.nextInt();
        sc.nextLine(); // consume newline

        String payload = "";
        switch (choice) {
            case 1:
                System.out.print("Enter integer for factorial: ");
                int n = sc.nextInt();
                payload = "FACTORIAL|" + n;
                break;
            case 2:
                System.out.print("Enter string to reverse: ");
                String s = sc.nextLine();
                payload = "REVERSE|" + s;
                break;
            case 3:
                System.out.println("Enter 8 integers for two 2x2 matrices (a b c d e f g h):");
                String mat = sc.nextLine();
                payload = "MATRIX_MUL|" + mat;
                break;
            default:
                payload = "FACTORIAL|8";
        }

        try (Socket socket = new Socket(host, port);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            System.out.println("[Client] Submitting computation: " + payload);
            out.println(payload);

            String reply = in.readLine();
            System.out.println("\n>>> COMPUTATION RESULT FROM SERVER <<<");
            System.out.println(reply);

        } catch (IOException e) {
            System.err.println("Computation failed: " + e.getMessage());
        }
    }
}
