/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 27: Multi-user TCP Group Chat Client
 *
 * Compilation:
 *   javac q27_TCPGroupChatClient.java
 *
 * Execution:
 *   java q27_TCPGroupChatClient [host: localhost] [port: 2727]
 */

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class q27_TCPGroupChatClient {
    public static void main(String[] args) {
        String host = (args.length > 0) ? args[0] : "localhost";
        int port = (args.length > 1) ? Integer.parseInt(args[1]) : 2727;

        try {
            Socket socket = new Socket(host, port);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            Scanner scanner = new Scanner(System.in);

            // Listening thread
            new Thread(() -> {
                try {
                    String msg;
                    while ((msg = in.readLine()) != null) {
                        System.out.println(msg);
                    }
                } catch (IOException e) {
                    System.out.println("[Disconnected from chat]");
                }
            }).start();

            // Sender loop
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                out.println(line);
                if (line.equalsIgnoreCase("/exit")) break;
            }

            socket.close();
        } catch (IOException e) {
            System.err.println("Chat client failed: " + e.getMessage());
        }
    }
}
