/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 27: Multi-user chat server: Implement a group chat system using
 *              TCP sockets where multiple clients can join, send messages,
 *              and receive broadcasts from the server.
 *              [MULTI-USER GROUP CHAT SERVER - JAVA]
 *
 * Compilation:
 *   javac q27_TCPGroupChatServer.java
 *
 * Execution:
 *   Terminal 1: java q27_TCPGroupChatServer [port: default 2727]
 *   Terminal 2: java q27_TCPGroupChatClient [name: Alice]
 *   Terminal 3: java q27_TCPGroupChatClient [name: Bob]
 */

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class q27_TCPGroupChatServer {
    private static final int PORT = 2727;
    private static final Set<ClientThread> activeClients = ConcurrentHashMap.newKeySet();

    public static void main(String[] args) {
        int port = (args.length > 0) ? Integer.parseInt(args[0]) : PORT;

        System.out.println("============================================================");
        System.out.println(" Q27: Multi-User TCP Group Chat Server (Java)               ");
        System.out.println(" Listening on port: " + port);
        System.out.println("============================================================");

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            while (true) {
                Socket clientSocket = serverSocket.accept();
                ClientThread client = new ClientThread(clientSocket);
                activeClients.add(client);
                new Thread(client).start();
            }
        } catch (IOException e) {
            System.err.println("Chat server error: " + e.getMessage());
        }
    }

    public static void broadcast(String message, ClientThread sender) {
        for (ClientThread client : activeClients) {
            if (client != sender) {
                client.sendMessage(message);
            }
        }
    }

    private static class ClientThread implements Runnable {
        private final Socket socket;
        private PrintWriter out;
        private String username;

        public ClientThread(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
                out = new PrintWriter(socket.getOutputStream(), true);

                out.println("Welcome to the Group Chat Room! Please enter your name:");
                username = in.readLine();
                if (username == null || username.trim().isEmpty()) {
                    username = "Guest_" + socket.getPort();
                }

                System.out.println("[+] " + username + " entered the chat room.");
                broadcast(">>> " + username + " joined the chat room! <<<", this);

                String msg;
                while ((msg = in.readLine()) != null) {
                    if (msg.equalsIgnoreCase("/exit") || msg.equalsIgnoreCase("quit")) break;
                    String broadcastMsg = "[" + username + "]: " + msg;
                    System.out.println(broadcastMsg);
                    broadcast(broadcastMsg, this);
                }
            } catch (IOException ignored) {
            } finally {
                activeClients.remove(this);
                System.out.println("[-] " + username + " left.");
                broadcast("<<< " + username + " has left the chat. >>>", this);
                try { socket.close(); } catch (IOException ignored) {}
            }
        }

        public void sendMessage(String msg) {
            if (out != null) out.println(msg);
        }
    }
}
