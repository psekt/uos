/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 13: Write a TCP client-server program where the client sends
 *              a message and the server replies with the reversed string.
 *              [TCP SERVER - JAVA]
 *
 * Compilation:
 *   javac q13_TCPServerStringReverse.java
 *
 * Execution:
 *   Terminal 1: java q13_TCPServerStringReverse [port: default 6001]
 *   Terminal 2: java q13_TCPClientStringReverse [host: localhost] [port: 6001]
 */

import java.io.*;
import java.net.*;

public class q13_TCPServerStringReverse {
    private static final int DEFAULT_PORT = 6001;

    public static void main(String[] args) {
        int port = (args.length > 0) ? Integer.parseInt(args[0]) : DEFAULT_PORT;

        System.out.println("============================================================");
        System.out.println(" Q13: TCP String Reversal Server (Java)                     ");
        System.out.println(" Listening on port: " + port);
        System.out.println("============================================================");

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            while (true) {
                System.out.println("\n[Server] Waiting for client connection...");
                try (Socket clientSocket = serverSocket.accept();
                     BufferedReader reader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                     PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(), true)) {

                    System.out.println("[Server] Accepted connection from: " + clientSocket.getRemoteSocketAddress());

                    String clientMessage = reader.readLine();
                    if (clientMessage != null) {
                        System.out.println("[Server] Received from client: \"" + clientMessage + "\"");

                        // Reverse the string
                        String reversed = new StringBuilder(clientMessage).reverse().toString();
                        System.out.println("[Server] Reversing string -> \"" + reversed + "\"");

                        // Send reversed string back to client
                        writer.println(reversed);
                        System.out.println("[Server] Reply sent back to client.");
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Server exception: " + e.getMessage());
        }
    }
}
