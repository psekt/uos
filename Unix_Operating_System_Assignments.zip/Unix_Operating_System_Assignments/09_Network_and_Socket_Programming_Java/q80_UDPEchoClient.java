/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 80: UDP Echo Client
 *
 * Compilation:
 *   javac q80_UDPEchoClient.java
 *
 * Execution:
 *   java q80_UDPEchoClient
 */

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class q80_UDPEchoClient {
    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket();
             Scanner scanner = new Scanner(System.in)) {

            InetAddress server = InetAddress.getByName("localhost");
            int port = 8080;

            System.out.println("Enter text to send to UDP Echo Server (type 'quit' to exit):");
            while (true) {
                System.out.print("> ");
                String text = scanner.nextLine();
                byte[] out = text.getBytes();
                socket.send(new DatagramPacket(out, out.length, server, port));

                if (text.equalsIgnoreCase("quit")) break;

                byte[] in = new byte[1024];
                DatagramPacket inPkt = new DatagramPacket(in, in.length);
                socket.receive(inPkt);
                System.out.println(new String(inPkt.getData(), 0, inPkt.getLength()));
            }
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
