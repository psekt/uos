/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 14: Implement a UDP client-server program where the client sends
 *              numbers and the server responds with their factorial.
 *              [UDP CLIENT - JAVA]
 *
 * Compilation:
 *   javac q14_UDPClientFactorial.java
 *
 * Execution:
 *   java q14_UDPClientFactorial [host: default localhost] [port: default 7001]
 */

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class q14_UDPClientFactorial {
    public static void main(String[] args) {
        String host = (args.length > 0) ? args[0] : "localhost";
        int port = (args.length > 1) ? Integer.parseInt(args[1]) : 7001;

        System.out.println("============================================================");
        System.out.println(" Q14: UDP Factorial Client (Java)                           ");
        System.out.println(" Target Server: " + host + ":" + port);
        System.out.println("============================================================");

        try (DatagramSocket socket = new DatagramSocket();
             Scanner scanner = new Scanner(System.in)) {

            socket.setSoTimeout(5000); // 5 seconds timeout
            InetAddress serverAddress = InetAddress.getByName(host);

            System.out.print("Enter an integer number to compute factorial (e.g., 7): ");
            String numberStr = scanner.nextLine().trim();
            if (numberStr.isEmpty()) numberStr = "7";

            byte[] sendData = numberStr.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, port);
            socket.send(sendPacket);
            System.out.println("[Client] Datagram packet sent for number: " + numberStr);

            byte[] receiveData = new byte[2048];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            socket.receive(receivePacket);

            String response = new String(receivePacket.getData(), 0, receivePacket.getLength());
            System.out.println("\n==================== UDP SERVER REPLY ====================");
            System.out.println(response);
            System.out.println("==========================================================");

        } catch (SocketTimeoutException e) {
            System.err.println("Timeout: No response received from UDP server within 5 seconds.");
        } catch (IOException e) {
            System.err.println("Client Error: " + e.getMessage());
        }
    }
}
