/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 13: Write a TCP client-server program in C where the client sends
 *              a message and the server replies with the reversed string.
 *              [COMPANION C IMPLEMENTATION - SERVER]
 *
 * Compilation:
 *   gcc -Wall -O2 q13_tcp_reverse_server.c -o q13_tcp_reverse_server
 *
 * Execution:
 *   Terminal 1: ./q13_tcp_reverse_server
 *   Terminal 2: ./q13_tcp_reverse_client
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#ifdef _WIN32
#include <winsock2.h>
#pragma comment(lib, "ws2_32.lib")
#else
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#endif

#define PORT 6002
#define BUFFER_SIZE 512

void reverse_str(char *str) {
    int len = strlen(str);
    for (int i = 0; i < len / 2; i++) {
        char temp = str[i];
        str[i] = str[len - 1 - i];
        str[len - 1 - i] = temp;
    }
}

int main() {
#ifdef _WIN32
    WSADATA wsa;
    WSAStartup(MAKEWORD(2, 2), &wsa);
#endif

    int server_fd, client_fd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);
    char buffer[BUFFER_SIZE];

    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    if (listen(server_fd, 3) < 0) {
        perror("listen failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q13: TCP String Reversal Server (C)                        \n");
    printf(" Listening on port: %d\n", PORT);
    printf("============================================================\n");

    client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &addr_len);
    if (client_fd < 0) {
        perror("accept failed");
        exit(EXIT_FAILURE);
    }

    ssize_t n = recv(client_fd, buffer, sizeof(buffer) - 1, 0);
    if (n > 0) {
        buffer[n] = '\0';
        buffer[strcspn(buffer, "\r\n")] = '\0';
        printf("[C Server] Received: \"%s\"\n", buffer);

        reverse_str(buffer);
        printf("[C Server] Reversed: \"%s\"\n", buffer);

        strcat(buffer, "\n");
        send(client_fd, buffer, strlen(buffer), 0);
    }

#ifdef _WIN32
    closesocket(client_fd);
    closesocket(server_fd);
    WSACleanup();
#else
    close(client_fd);
    close(server_fd);
#endif

    return 0;
}
