/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 79: TCP Echo Client
 *
 * Compilation:
 *   javac q79_TCPEchoClient.java
 *
 * Execution:
 *   java q79_TCPEchoClient
 */

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class q79_TCPEchoClient {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 7979);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             Scanner sc = new Scanner(System.in)) {

            System.out.println("Connected to TCP Echo Server 79. Type messages below:");
            while (true) {
                System.out.print("> ");
                String line = sc.nextLine();
                out.println(line);
                if (line.equalsIgnoreCase("quit")) break;
                System.out.println(in.readLine());
            }
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
