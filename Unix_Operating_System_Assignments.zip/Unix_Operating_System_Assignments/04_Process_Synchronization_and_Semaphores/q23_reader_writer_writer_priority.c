/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 23: Reader-Writer with priority: Implement the reader-writer problem
 *              using semaphores such that writers are given higher priority
 *              than readers.
 *
 * Writer-Priority Protocol:
 *   - Once a writer wants to write, no new readers can start reading.
 *   - Prevents writer starvation.
 *
 * Compilation:
 *   gcc -Wall -O2 q23_reader_writer_writer_priority.c -o q23_reader_writer_writer_priority
 *
 * Execution:
 *   ./q23_reader_writer_writer_priority
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/wait.h>

#define SHM_KEY 0x2323
#define SEM_KEY 0x2324

#define SEM_RMUTEX 0  // Protects readcount
#define SEM_WMUTEX 1  // Protects writecount
#define SEM_READTRY 2 // Prevents readers when writer is waiting
#define SEM_RESOURCE 3 // Exclusive access to shared resource

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

struct rw_state {
    int readcount;
    int writecount;
    int shared_data;
};

void sem_wait_op(int semid, int sem_num) {
    struct sembuf op = {sem_num, -1, 0};
    semop(semid, &op, 1);
}

void sem_signal_op(int semid, int sem_num) {
    struct sembuf op = {sem_num, 1, 0};
    semop(semid, &op, 1);
}

int main() {
    int shmid = shmget(SHM_KEY, sizeof(struct rw_state), IPC_CREAT | 0666);
    struct rw_state *st = (struct rw_state*)shmat(shmid, NULL, 0);
    st->readcount = 0;
    st->writecount = 0;
    st->shared_data = 500;

    int semid = semget(SEM_KEY, 4, IPC_CREAT | 0666);
    union semun arg;
    arg.val = 1;
    for (int i = 0; i < 4; i++) semctl(semid, i, SETVAL, arg);

    printf("============================================================\n");
    printf(" Q23: Reader-Writer with WRITER PRIORITY (Semaphores)       \n");
    printf(" Initial Value: %d\n", st->shared_data);
    printf("============================================================\n");

    // Spawn 2 Writers and 3 Readers
    // Writer 1
    if (fork() == 0) {
        for (int i = 0; i < 2; i++) {
            sem_wait_op(semid, SEM_WMUTEX);
            st->writecount++;
            if (st->writecount == 1) sem_wait_op(semid, SEM_READTRY); // Inhibit future readers!
            sem_signal_op(semid, SEM_WMUTEX);

            sem_wait_op(semid, SEM_RESOURCE); // Exclusive write
            st->shared_data += 50;
            printf("  [WRITER 1 (PRIORITY)] Writing new value: %d\n", st->shared_data);
            usleep(100000);
            sem_signal_op(semid, SEM_RESOURCE);

            sem_wait_op(semid, SEM_WMUTEX);
            st->writecount--;
            if (st->writecount == 0) sem_signal_op(semid, SEM_READTRY); // Release readers
            sem_signal_op(semid, SEM_WMUTEX);

            usleep(120000);
        }
        exit(0);
    }

    // Reader 1
    if (fork() == 0) {
        for (int i = 0; i < 3; i++) {
            sem_wait_op(semid, SEM_READTRY); // Wait if writer is queued
            sem_wait_op(semid, SEM_RMUTEX);
            st->readcount++;
            if (st->readcount == 1) sem_wait_op(semid, SEM_RESOURCE);
            sem_signal_op(semid, SEM_RMUTEX);
            sem_signal_op(semid, SEM_READTRY);

            printf("[Reader 1] Reading value = %d\n", st->shared_data);
            usleep(80000);

            sem_wait_op(semid, SEM_RMUTEX);
            st->readcount--;
            if (st->readcount == 0) sem_signal_op(semid, SEM_RESOURCE);
            sem_signal_op(semid, SEM_RMUTEX);

            usleep(100000);
        }
        exit(0);
    }

    // Reader 2
    if (fork() == 0) {
        for (int i = 0; i < 3; i++) {
            usleep(40000);
            sem_wait_op(semid, SEM_READTRY);
            sem_wait_op(semid, SEM_RMUTEX);
            st->readcount++;
            if (st->readcount == 1) sem_wait_op(semid, SEM_RESOURCE);
            sem_signal_op(semid, SEM_RMUTEX);
            sem_signal_op(semid, SEM_READTRY);

            printf("  [Reader 2] Reading value = %d\n", st->shared_data);
            usleep(80000);

            sem_wait_op(semid, SEM_RMUTEX);
            st->readcount--;
            if (st->readcount == 0) sem_signal_op(semid, SEM_RESOURCE);
            sem_signal_op(semid, SEM_RMUTEX);

            usleep(100000);
        }
        exit(0);
    }

    // Wait for all
    for (int i = 0; i < 3; i++) wait(NULL);

    shmdt(st);
    shmctl(shmid, IPC_RMID, NULL);
    semctl(semid, 0, IPC_RMID);

    printf("\nWriter priority demonstration finished.\n");
    return 0;
}
