/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 85: Create three separate programs:
 *              (1) initialize a semaphore and display its ID,
 *              (2) perform the P (wait) operation and print a message,
 *              (3) perform the V (signal) operation and print a message -
 *              all operating on the same semaphore.
 *              [PROGRAM 1: INITIALIZE SEMAPHORE]
 *
 * Compilation:
 *   gcc -Wall -O2 q85_1_sem_init.c -o q85_1_sem_init
 *   gcc -Wall -O2 q85_2_sem_wait_p.c -o q85_2_sem_wait_p
 *   gcc -Wall -O2 q85_3_sem_signal_v.c -o q85_3_sem_signal_v
 *
 * Execution:
 *   Step 1: ./q85_1_sem_init [optional_init_value: default 1]
 *   Step 2: ./q85_2_sem_wait_p
 *   Step 3: ./q85_3_sem_signal_v
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/sem.h>

#define SHARED_SEM_KEY 0x8585

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

int main(int argc, char *argv[]) {
    int init_val = (argc > 1) ? atoi(argv[1]) : 1;

    int semid = semget(SHARED_SEM_KEY, 1, IPC_CREAT | 0666);
    if (semid < 0) {
        perror("semget failed");
        exit(EXIT_FAILURE);
    }

    union semun arg;
    arg.val = init_val;
    if (semctl(semid, 0, SETVAL, arg) == -1) {
        perror("semctl SETVAL failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q85 [Part 1]: Initialize Semaphore                         \n");
    printf("============================================================\n");
    printf("Semaphore Key : 0x%X\n", SHARED_SEM_KEY);
    printf("Semaphore ID  : %d\n", semid);
    printf("Initial Value : %d\n", init_val);
    printf("Status        : Initialized and ready for P (wait) and V (signal) operations.\n");
    return 0;
}
