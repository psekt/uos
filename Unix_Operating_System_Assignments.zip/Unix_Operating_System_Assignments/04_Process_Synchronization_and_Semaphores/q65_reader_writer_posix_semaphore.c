/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 65: Implement the reader-writer problem using semaphores.
 *              [POSIX Semaphores - semaphore.h]
 *
 * Compilation:
 *   gcc -Wall -O2 q65_reader_writer_posix_semaphore.c -o q65_reader_writer_posix_semaphore -lpthread
 *
 * Execution:
 *   ./q65_reader_writer_posix_semaphore
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

sem_t mutex_count;
sem_t write_block;
int read_count = 0;
int shared_resource = 100;

void* reader_thread(void* arg) {
    long id = (long)arg;
    for (int i = 0; i < 2; i++) {
        sem_wait(&mutex_count);
        read_count++;
        if (read_count == 1) {
            sem_wait(&write_block);
        }
        sem_post(&mutex_count);

        printf("[Reader %ld] Reading shared_resource: %d (Active readers: %d)\n",
               id, shared_resource, read_count);
        usleep(80000);

        sem_wait(&mutex_count);
        read_count--;
        if (read_count == 0) {
            sem_post(&write_block);
        }
        sem_post(&mutex_count);

        usleep(100000);
    }
    pthread_exit(NULL);
}

void* writer_thread(void* arg) {
    long id = (long)arg;
    for (int i = 0; i < 2; i++) {
        sem_wait(&write_block);

        shared_resource += 50;
        printf("  >> [Writer %ld] Updated shared_resource to %d <<\n", id, shared_resource);
        usleep(120000);

        sem_post(&write_block);
        usleep(150000);
    }
    pthread_exit(NULL);
}

int main() {
    pthread_t r[3], w[2];

    sem_init(&mutex_count, 0, 1);
    sem_init(&write_block, 0, 1);

    printf("============================================================\n");
    printf(" Q65: Reader-Writer Problem Using POSIX Semaphores          \n");
    printf(" Initial Resource Value: %d\n", shared_resource);
    printf("============================================================\n");

    pthread_create(&r[0], NULL, reader_thread, (void*)1);
    pthread_create(&w[0], NULL, writer_thread, (void*)1);
    pthread_create(&r[1], NULL, reader_thread, (void*)2);
    pthread_create(&w[1], NULL, writer_thread, (void*)2);
    pthread_create(&r[2], NULL, reader_thread, (void*)3);

    for (int i = 0; i < 3; i++) pthread_join(r[i], NULL);
    for (int i = 0; i < 2; i++) pthread_join(w[i], NULL);

    sem_destroy(&mutex_count);
    sem_destroy(&write_block);

    printf("\nPOSIX Reader-Writer execution completed.\n");
    return 0;
}
