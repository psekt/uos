/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 10: Write a program using semaphores to synchronize two processes
 *              such that one process prints even numbers and the other prints
 *              odd numbers in order.
 *
 * Sequence: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ...
 *
 * Compilation:
 *   gcc -Wall -O2 q10_sem_even_odd_synchronization.c -o q10_sem_even_odd_synchronization
 *
 * Execution:
 *   ./q10_sem_even_odd_synchronization [limit]
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/wait.h>

#define SEM_KEY 0x1010
#define SEM_ODD 0
#define SEM_EVEN 1

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

void sem_wait_op(int semid, int sem_num) {
    struct sembuf sop = {sem_num, -1, 0};
    semop(semid, &sop, 1);
}

void sem_signal_op(int semid, int sem_num) {
    struct sembuf sop = {sem_num, 1, 0};
    semop(semid, &sop, 1);
}

int main(int argc, char *argv[]) {
    int limit = (argc > 1) ? atoi(argv[1]) : 10;
    if (limit <= 0) limit = 10;

    int semid = semget(SEM_KEY, 2, IPC_CREAT | 0666);
    if (semid < 0) {
        perror("semget failed");
        exit(EXIT_FAILURE);
    }

    // Initialize: SEM_ODD = 1 (Odd prints first), SEM_EVEN = 0 (Even waits)
    union semun arg;
    arg.val = 1;
    semctl(semid, SEM_ODD, SETVAL, arg);
    arg.val = 0;
    semctl(semid, SEM_EVEN, SETVAL, arg);

    printf("============================================================\n");
    printf(" Q10: Even/Odd Numbers Synchronization Using Semaphores     \n");
    printf(" Limit: %d\n", limit);
    printf("============================================================\n");

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork error");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent: Prints ODD numbers (1, 3, 5, ...)
        for (int i = 1; i <= limit; i += 2) {
            sem_wait_op(semid, SEM_ODD);
            printf("[Parent Process (PID %d)] ODD : %d\n", getpid(), i);
            fflush(stdout);
            sem_signal_op(semid, SEM_EVEN); // Wake even process
        }

        wait(NULL);
        semctl(semid, 0, IPC_RMID);
        printf("\nAll numbers printed in perfect alternating order!\n");
    } else {
        // Child: Prints EVEN numbers (2, 4, 6, ...)
        for (int i = 2; i <= limit; i += 2) {
            sem_wait_op(semid, SEM_EVEN);
            printf("  [Child Process  (PID %d)] EVEN: %d\n", getpid(), i);
            fflush(stdout);
            sem_signal_op(semid, SEM_ODD); // Wake odd process
        }
        exit(EXIT_SUCCESS);
    }

    return 0;
}
