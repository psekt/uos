/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 21: Dining philosophers problem: Implement the classical dining
 *              philosophers synchronization problem using semaphores.
 *
 * Solution to avoid deadlock: Asymmetric solution (odd philosophers pick left
 * fork first; even philosophers pick right fork first) or semaphore room capacity.
 *
 * Compilation:
 *   gcc -Wall -O2 q21_dining_philosophers_sem.c -o q21_dining_philosophers_sem
 *
 * Execution:
 *   ./q21_dining_philosophers_sem
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/wait.h>

#define NUM_PHILOSOPHERS 5
#define SEM_KEY 0x2121

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

void sem_wait_op(int semid, int sem_num) {
    struct sembuf op = {sem_num, -1, 0};
    semop(semid, &op, 1);
}

void sem_signal_op(int semid, int sem_num) {
    struct sembuf op = {sem_num, 1, 0};
    semop(semid, &op, 1);
}

void philosopher(int id, int semid) {
    int left_fork = id;
    int right_fork = (id + 1) % NUM_PHILOSOPHERS;

    for (int meal = 1; meal <= 2; meal++) {
        // Thinking
        printf("Philosopher %d is THINKING (round %d)...\n", id, meal);
        usleep(100000 + (id * 20000));

        // Deadlock avoidance: odd/even ordering
        if (id % 2 == 0) {
            sem_wait_op(semid, left_fork);
            sem_wait_op(semid, right_fork);
        } else {
            sem_wait_op(semid, right_fork);
            sem_wait_op(semid, left_fork);
        }

        // Eating
        printf("  >> Philosopher %d is EATING (forks %d & %d) <<\n", id, left_fork, right_fork);
        usleep(120000);

        // Put down forks
        sem_signal_op(semid, left_fork);
        sem_signal_op(semid, right_fork);
        printf("Philosopher %d FINISHED eating and put down forks.\n", id);
    }

    exit(0);
}

int main() {
    int semid = semget(SEM_KEY, NUM_PHILOSOPHERS, IPC_CREAT | 0666);
    if (semid < 0) {
        perror("semget error");
        exit(EXIT_FAILURE);
    }

    // Initialize each chopstick/fork semaphore to 1 (available)
    union semun arg;
    arg.val = 1;
    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
        semctl(semid, i, SETVAL, arg);
    }

    printf("============================================================\n");
    printf(" Q21: Dining Philosophers Problem Using Semaphores          \n");
    printf(" Number of Philosophers: %d | Deadlock Free (Asymmetric)    \n", NUM_PHILOSOPHERS);
    printf("============================================================\n");

    pid_t pids[NUM_PHILOSOPHERS];
    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
        pids[i] = fork();
        if (pids[i] == 0) {
            philosopher(i, semid);
        }
    }

    for (int i = 0; i < NUM_PHILOSOPHERS; i++) {
        waitpid(pids[i], NULL, 0);
    }

    semctl(semid, 0, IPC_RMID);
    printf("\nAll philosophers have eaten without any deadlock!\n");
    return 0;
}
