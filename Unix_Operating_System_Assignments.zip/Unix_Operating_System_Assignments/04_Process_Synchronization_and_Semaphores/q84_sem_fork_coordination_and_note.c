/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 84: Illustrate semaphore usage with fork() so two processes run
 *              simultaneously and coordinate via semaphores; include a short
 *              note on differences between sem.h and semaphore.h.
 *
 * Compilation:
 *   gcc -Wall -O2 q84_sem_fork_coordination_and_note.c -o q84_sem_fork_coordination_and_note
 *
 * Execution:
 *   ./q84_sem_fork_coordination_and_note
 *
 * =========================================================================
 * SHORT NOTE: Differences between <sys/sem.h> and <semaphore.h>
 * =========================================================================
 * 1. Standard / Origin:
 *    - <sys/sem.h>: System V IPC standard (traditional Unix, AT&T Bell Labs).
 *    - <semaphore.h>: POSIX standard (IEEE POSIX 1003.1b, modern Unix/Linux).
 *
 * 2. Structure:
 *    - <sys/sem.h> operates on SETS of semaphores (arrays of semaphores allocated
 *      together via semget).
 *    - <semaphore.h> operates on INDIVIDUAL semaphore objects (sem_t).
 *
 * 3. Operations:
 *    - <sys/sem.h>: Uses semget(), semctl(), and semop() with struct sembuf.
 *      Allows atomic multi-semaphore decrement/increment and undo operations (SEM_UNDO).
 *    - <semaphore.h>: Uses intuitive functions: sem_init(), sem_wait(), sem_post(),
 *      sem_trywait(), sem_destroy() (for unnamed) and sem_open(), sem_close(),
 *      sem_unlink() (for named).
 *
 * 4. Scope & Portability:
 *    - <sys/sem.h>: Kernel-persistent until explicitly removed or system reboot.
 *    - <semaphore.h>: Can be thread-shared or process-shared, cleaner, faster,
 *      and the current industry standard across POSIX operating systems.
 * =========================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/wait.h>

#define SEM_KEY 0x8484

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

void sem_wait_op(int semid) {
    struct sembuf op = {0, -1, 0};
    semop(semid, &op, 1);
}

void sem_signal_op(int semid) {
    struct sembuf op = {0, 1, 0};
    semop(semid, &op, 1);
}

int main() {
    int semid = semget(SEM_KEY, 1, IPC_CREAT | 0666);
    if (semid < 0) {
        perror("semget error");
        exit(EXIT_FAILURE);
    }

    // Initialize semaphore to 1 (mutex for shared terminal)
    union semun arg;
    arg.val = 1;
    semctl(semid, 0, SETVAL, arg);

    printf("============================================================\n");
    printf(" Q84: Semaphore Coordination Between Forked Processes       \n");
    printf(" Semaphore ID: %d | Mutex initialized to 1\n", semid);
    printf("============================================================\n");

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork error");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent Process
        for (int i = 1; i <= 3; i++) {
            sem_wait_op(semid);
            printf("[Parent Process PID: %d] Entered Critical Section (iteration %d)\n", getpid(), i);
            usleep(100000);
            printf("[Parent Process PID: %d] Leaving Critical Section\n", getpid());
            sem_signal_op(semid);
            usleep(80000);
        }

        wait(NULL);
        semctl(semid, 0, IPC_RMID);

        printf("\n------------------------------------------------------------\n");
        printf("NOTE: Read source file header comments for detailed comparison\n");
        printf("      between <sys/sem.h> (System V) and <semaphore.h> (POSIX).\n");
        printf("------------------------------------------------------------\n");
    } else {
        // Child Process
        for (int i = 1; i <= 3; i++) {
            sem_wait_op(semid);
            printf("  [Child Process  PID: %d] Entered Critical Section (iteration %d)\n", getpid(), i);
            usleep(120000);
            printf("  [Child Process  PID: %d] Leaving Critical Section\n", getpid());
            sem_signal_op(semid);
            usleep(60000);
        }
        exit(0);
    }

    return 0;
}
