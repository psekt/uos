/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 64: Implement the producer-consumer problem using semaphores
 *              (semaphore.h) in C or Java.
 *
 * Concept: POSIX Semaphores: sem_init(), sem_wait(), sem_post(), sem_destroy()
 *
 * Compilation:
 *   gcc -Wall -O2 q64_producer_consumer_posix_semaphore.c -o q64_producer_consumer_posix_semaphore -lpthread
 *
 * Execution:
 *   ./q64_producer_consumer_posix_semaphore
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define BUF_SIZE 5
#define PRODUCE_LIMIT 10

int buffer[BUF_SIZE];
int in_idx = 0;
int out_idx = 0;

sem_t mutex_sem;
sem_t empty_sem;
sem_t full_sem;

void* producer_func(void* arg) {
    for (int i = 1; i <= PRODUCE_LIMIT; i++) {
        int item = i * 11;

        sem_wait(&empty_sem);
        sem_wait(&mutex_sem);

        buffer[in_idx] = item;
        printf("[Producer Thread] Produced item %d at index %d\n", item, in_idx);
        in_idx = (in_idx + 1) % BUF_SIZE;

        sem_post(&mutex_sem);
        sem_post(&full_sem);

        usleep(100000);
    }
    pthread_exit(NULL);
}

void* consumer_func(void* arg) {
    for (int i = 1; i <= PRODUCE_LIMIT; i++) {
        sem_wait(&full_sem);
        sem_wait(&mutex_sem);

        int item = buffer[out_idx];
        printf("  [Consumer Thread] Consumed item %d from index %d\n", item, out_idx);
        out_idx = (out_idx + 1) % BUF_SIZE;

        sem_post(&mutex_sem);
        sem_post(&empty_sem);

        usleep(150000);
    }
    pthread_exit(NULL);
}

int main() {
    pthread_t prod_tid, cons_tid;

    sem_init(&mutex_sem, 0, 1);
    sem_init(&empty_sem, 0, BUF_SIZE);
    sem_init(&full_sem, 0, 0);

    printf("============================================================\n");
    printf(" Q64: POSIX Semaphores (semaphore.h) Producer-Consumer      \n");
    printf(" Buffer Size: %d | Total Items: %d\n", BUF_SIZE, PRODUCE_LIMIT);
    printf("============================================================\n");

    pthread_create(&prod_tid, NULL, producer_func, NULL);
    pthread_create(&cons_tid, NULL, consumer_func, NULL);

    pthread_join(prod_tid, NULL);
    pthread_join(cons_tid, NULL);

    sem_destroy(&mutex_sem);
    sem_destroy(&empty_sem);
    sem_destroy(&full_sem);

    printf("\nPOSIX Producer-Consumer demo finished successfully.\n");
    return 0;
}
