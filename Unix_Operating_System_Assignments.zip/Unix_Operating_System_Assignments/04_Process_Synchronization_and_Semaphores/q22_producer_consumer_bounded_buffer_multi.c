/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 22: Producer-Consumer with bounded buffer: Use shared memory and
 *              semaphores to implement multiple producers and multiple consumers.
 *
 * Compilation:
 *   gcc -Wall -O2 q22_producer_consumer_bounded_buffer_multi.c -o q22_producer_consumer_bounded_buffer_multi
 *
 * Execution:
 *   ./q22_producer_consumer_bounded_buffer_multi
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/wait.h>

#define BUFFER_SIZE 5
#define NUM_PRODUCERS 2
#define NUM_CONSUMERS 2
#define ITEMS_PER_PRODUCER 4

#define SHM_KEY 0x2222
#define SEM_KEY 0x2223

#define SEM_MUTEX 0
#define SEM_EMPTY 1
#define SEM_FULL  2

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

struct bounded_buffer {
    int in;
    int out;
    int slots[BUFFER_SIZE];
};

void sem_wait_op(int semid, int sem_num) {
    struct sembuf op = {sem_num, -1, 0};
    semop(semid, &op, 1);
}

void sem_signal_op(int semid, int sem_num) {
    struct sembuf op = {sem_num, 1, 0};
    semop(semid, &op, 1);
}

int main() {
    int shmid = shmget(SHM_KEY, sizeof(struct bounded_buffer), IPC_CREAT | 0666);
    struct bounded_buffer *buf = (struct bounded_buffer*)shmat(shmid, NULL, 0);
    buf->in = 0;
    buf->out = 0;

    int semid = semget(SEM_KEY, 3, IPC_CREAT | 0666);
    union semun arg;
    arg.val = 1; semctl(semid, SEM_MUTEX, SETVAL, arg);
    arg.val = BUFFER_SIZE; semctl(semid, SEM_EMPTY, SETVAL, arg);
    arg.val = 0; semctl(semid, SEM_FULL, SETVAL, arg);

    printf("============================================================\n");
    printf(" Q22: Multi-Producer Multi-Consumer Bounded Buffer          \n");
    printf(" Producers: %d | Consumers: %d | Buffer Size: %d\n",
           NUM_PRODUCERS, NUM_CONSUMERS, BUFFER_SIZE);
    printf("============================================================\n");

    // Spawn Producers
    for (int p = 0; p < NUM_PRODUCERS; p++) {
        if (fork() == 0) {
            for (int i = 1; i <= ITEMS_PER_PRODUCER; i++) {
                int item = (p + 1) * 1000 + i;

                sem_wait_op(semid, SEM_EMPTY);
                sem_wait_op(semid, SEM_MUTEX);

                buf->slots[buf->in] = item;
                printf("[PRODUCER %d] Put item %d into slot %d\n", p + 1, item, buf->in);
                buf->in = (buf->in + 1) % BUFFER_SIZE;

                sem_signal_op(semid, SEM_MUTEX);
                sem_signal_op(semid, SEM_FULL);
                usleep(80000);
            }
            exit(0);
        }
    }

    // Spawn Consumers
    int items_to_consume = (NUM_PRODUCERS * ITEMS_PER_PRODUCER) / NUM_CONSUMERS;
    for (int c = 0; c < NUM_CONSUMERS; c++) {
        if (fork() == 0) {
            for (int i = 1; i <= items_to_consume; i++) {
                sem_wait_op(semid, SEM_FULL);
                sem_wait_op(semid, SEM_MUTEX);

                int item = buf->slots[buf->out];
                printf("  [CONSUMER %d] Got item %d from slot %d\n", c + 1, item, buf->out);
                buf->out = (buf->out + 1) % BUFFER_SIZE;

                sem_signal_op(semid, SEM_MUTEX);
                sem_signal_op(semid, SEM_EMPTY);
                usleep(110000);
            }
            exit(0);
        }
    }

    // Wait for all child processes
    for (int i = 0; i < NUM_PRODUCERS + NUM_CONSUMERS; i++) {
        wait(NULL);
    }

    shmdt(buf);
    shmctl(shmid, IPC_RMID, NULL);
    semctl(semid, 0, IPC_RMID);

    printf("\nAll producers and consumers finished gracefully.\n");
    return 0;
}
