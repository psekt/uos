/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 12: Implement the Reader-Writer problem using semaphores to
 *              control access.
 *
 * Classical solution:
 *   - Multiple readers can read simultaneously.
 *   - Only one writer can write at a time (exclusive access).
 *   - When a writer is writing, no readers are allowed.
 *
 * Compilation:
 *   gcc -Wall -O2 q12_reader_writer_sem.c -o q12_reader_writer_sem
 *
 * Execution:
 *   ./q12_reader_writer_sem
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/wait.h>

#define SHM_KEY 0x1212
#define SEM_KEY 0x1213

#define MUTEX_SEM 0
#define WRT_SEM   1

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

struct rw_data {
    int readcount;
    int shared_data;
};

void sem_wait_op(int semid, int sem_num) {
    struct sembuf op = {sem_num, -1, 0};
    semop(semid, &op, 1);
}

void sem_signal_op(int semid, int sem_num) {
    struct sembuf op = {sem_num, 1, 0};
    semop(semid, &op, 1);
}

int main() {
    int shmid = shmget(SHM_KEY, sizeof(struct rw_data), IPC_CREAT | 0666);
    struct rw_data *rw = (struct rw_data*)shmat(shmid, NULL, 0);
    rw->readcount = 0;
    rw->shared_data = 10;

    int semid = semget(SEM_KEY, 2, IPC_CREAT | 0666);
    union semun arg;
    arg.val = 1;
    semctl(semid, MUTEX_SEM, SETVAL, arg);
    semctl(semid, WRT_SEM, SETVAL, arg);

    printf("============================================================\n");
    printf(" Q12: Reader-Writer Problem Using Semaphores                \n");
    printf(" Initial Shared Value: %d\n", rw->shared_data);
    printf("============================================================\n");

    // Spawn 2 Reader processes and 1 Writer process
    pid_t r1 = fork();
    if (r1 == 0) {
        // Reader 1
        for (int i = 0; i < 3; i++) {
            sem_wait_op(semid, MUTEX_SEM);
            rw->readcount++;
            if (rw->readcount == 1) sem_wait_op(semid, WRT_SEM); // First reader locks writer
            sem_signal_op(semid, MUTEX_SEM);

            printf("[Reader 1] Reading shared_data = %d (Active Readers: %d)\n",
                   rw->shared_data, rw->readcount);
            usleep(100000);

            sem_wait_op(semid, MUTEX_SEM);
            rw->readcount--;
            if (rw->readcount == 0) sem_signal_op(semid, WRT_SEM); // Last reader releases writer
            sem_signal_op(semid, MUTEX_SEM);

            usleep(80000);
        }
        exit(0);
    }

    pid_t w1 = fork();
    if (w1 == 0) {
        // Writer
        for (int i = 0; i < 3; i++) {
            usleep(50000);
            sem_wait_op(semid, WRT_SEM); // Exclusive lock
            rw->shared_data += 25;
            printf("  >>> [WRITER] Updated shared_data to %d <<<\n", rw->shared_data);
            usleep(120000);
            sem_signal_op(semid, WRT_SEM);
            usleep(100000);
        }
        exit(0);
    }

    pid_t r2 = fork();
    if (r2 == 0) {
        // Reader 2
        for (int i = 0; i < 3; i++) {
            usleep(30000);
            sem_wait_op(semid, MUTEX_SEM);
            rw->readcount++;
            if (rw->readcount == 1) sem_wait_op(semid, WRT_SEM);
            sem_signal_op(semid, MUTEX_SEM);

            printf("  [Reader 2] Reading shared_data = %d (Active Readers: %d)\n",
                   rw->shared_data, rw->readcount);
            usleep(90000);

            sem_wait_op(semid, MUTEX_SEM);
            rw->readcount--;
            if (rw->readcount == 0) sem_signal_op(semid, WRT_SEM);
            sem_signal_op(semid, MUTEX_SEM);

            usleep(90000);
        }
        exit(0);
    }

    waitpid(r1, NULL, 0);
    waitpid(w1, NULL, 0);
    waitpid(r2, NULL, 0);

    shmdt(rw);
    shmctl(shmid, IPC_RMID, NULL);
    semctl(semid, 0, IPC_RMID);

    printf("\nReader-Writer simulation completed cleanly.\n");
    return 0;
}
