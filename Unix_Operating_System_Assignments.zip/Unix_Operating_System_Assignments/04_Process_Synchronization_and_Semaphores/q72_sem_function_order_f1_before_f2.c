/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 72: Write a program using semaphores to ensure function f1() executes
 *              before f2() (example: prompt for username before prompting for password).
 *
 * Compilation:
 *   gcc -Wall -O2 q72_sem_function_order_f1_before_f2.c -o q72_sem_function_order_f1_before_f2 -lpthread
 *
 * Execution:
 *   ./q72_sem_function_order_f1_before_f2
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <string.h>

sem_t sem_order;
char username[64];
char password[64];

// Function f1: Prompt for username
void* f1_func(void* arg) {
    printf("[Thread 1: f1()] Executing f1()...\n");
    printf("Please enter your USERNAME: ");
    if (fgets(username, sizeof(username), stdin) == NULL) {
        strcpy(username, "admin_user\n");
    }
    username[strcspn(username, "\r\n")] = '\0';
    printf("[Thread 1: f1()] Username '%s' recorded. Signalling semaphore!\n", username);

    // Signal f2 to proceed
    sem_post(&sem_order);
    pthread_exit(NULL);
}

// Function f2: Prompt for password
void* f2_func(void* arg) {
    printf("[Thread 2: f2()] Waiting for f1() to complete first...\n");
    // Wait until f1 finishes
    sem_wait(&sem_order);

    printf("[Thread 2: f2()] Semaphore acquired! Now prompting for password.\n");
    printf("Please enter PASSWORD for [%s]: ", username);
    if (fgets(password, sizeof(password), stdin) == NULL) {
        strcpy(password, "secret123\n");
    }
    password[strcspn(password, "\r\n")] = '\0';

    printf("[Thread 2: f2()] Password recorded. Authentication flow completed.\n");
    pthread_exit(NULL);
}

int main() {
    pthread_t t1, t2;

    // Initialize semaphore with 0 so that whoever calls sem_wait first blocks
    sem_init(&sem_order, 0, 0);

    printf("============================================================\n");
    printf(" Q72: Guarantee Execution Order: f1() Before f2()           \n");
    printf(" (Example: Prompt for username before prompting for password)\n");
    printf("============================================================\n");

    // We can even create Thread 2 before Thread 1 to prove order is strictly enforced!
    pthread_create(&t2, NULL, f2_func, NULL);
    usleep(200000); // Give t2 time to start and block on semaphore
    pthread_create(&t1, NULL, f1_func, NULL);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    sem_destroy(&sem_order);

    printf("\nExecution sequence guaranteed: f1() executed before f2().\n");
    return 0;
}
