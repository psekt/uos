/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 19: Multi-process shared memory sort:
 *              a. Process 1 writes an array of numbers to shared memory.
 *              b. Process 2 sorts the numbers.
 *              c. Process 3 computes the median and mean.
 *              d. Process 4 displays the final results.
 *              Synchronize using semaphores.
 *
 * Compilation:
 *   gcc -Wall -O2 q19_shm_sem_four_proc_sort.c -o q19_shm_sem_four_proc_sort
 *
 * Execution:
 *   ./q19_shm_sem_four_proc_sort
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/wait.h>

#define MAX_SIZE 50
#define SHM_KEY 0x1919
#define SEM_KEY 0x1920

// 4 semaphores for synchronization:
// SEM 0: Process 1 -> Process 2
// SEM 1: Process 2 -> Process 3
// SEM 2: Process 3 -> Process 4

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

struct sort_stats {
    int count;
    int arr[MAX_SIZE];
    double mean;
    double median;
};

void sem_wait_op(int semid, int num) {
    struct sembuf op = {num, -1, 0};
    semop(semid, &op, 1);
}

void sem_signal_op(int semid, int num) {
    struct sembuf op = {num, 1, 0};
    semop(semid, &op, 1);
}

int main() {
    int shmid = shmget(SHM_KEY, sizeof(struct sort_stats), IPC_CREAT | 0666);
    struct sort_stats *shm = (struct sort_stats*)shmat(shmid, NULL, 0);

    int semid = semget(SEM_KEY, 3, IPC_CREAT | 0666);
    union semun arg;
    arg.val = 0;
    semctl(semid, 0, SETVAL, arg);
    semctl(semid, 1, SETVAL, arg);
    semctl(semid, 2, SETVAL, arg);

    printf("============================================================\n");
    printf(" Q19: 4-Process Shared Memory Sort, Median & Mean (Semaphores)\n");
    printf("============================================================\n");

    // Process 2: Sort
    pid_t p2 = fork();
    if (p2 == 0) {
        sem_wait_op(semid, 0); // Wait for P1
        printf("[Process 2 (PID %d)] Sorting numbers in shared memory...\n", getpid());
        for (int i = 0; i < shm->count - 1; i++) {
            for (int j = 0; j < shm->count - i - 1; j++) {
                if (shm->arr[j] > shm->arr[j + 1]) {
                    int tmp = shm->arr[j];
                    shm->arr[j] = shm->arr[j + 1];
                    shm->arr[j + 1] = tmp;
                }
            }
        }
        printf("[Process 2] Sort finished. Signalling Process 3.\n");
        sem_signal_op(semid, 1); // Signal P3
        exit(0);
    }

    // Process 3: Compute Median & Mean
    pid_t p3 = fork();
    if (p3 == 0) {
        sem_wait_op(semid, 1); // Wait for P2
        printf("[Process 3 (PID %d)] Computing Mean and Median...\n", getpid());
        double sum = 0;
        for (int i = 0; i < shm->count; i++) {
            sum += shm->arr[i];
        }
        shm->mean = sum / shm->count;

        int n = shm->count;
        if (n % 2 == 1) {
            shm->median = shm->arr[n / 2];
        } else {
            shm->median = (shm->arr[n / 2 - 1] + shm->arr[n / 2]) / 2.0;
        }

        printf("[Process 3] Mean & Median calculated. Signalling Process 4.\n");
        sem_signal_op(semid, 2); // Signal P4
        exit(0);
    }

    // Process 4: Display Results
    pid_t p4 = fork();
    if (p4 == 0) {
        sem_wait_op(semid, 2); // Wait for P3
        printf("\n============================================================\n");
        printf(" [Process 4 (PID %d)] FINAL DISPLAY OF RESULTS:\n", getpid());
        printf(" Sorted Array : ");
        for (int i = 0; i < shm->count; i++) printf("%d ", shm->arr[i]);
        printf("\n Mean         : %.4f\n", shm->mean);
        printf(" Median       : %.4f\n", shm->median);
        printf("============================================================\n");
        exit(0);
    }

    // Process 1 (Parent): Writes array of numbers
    int default_data[] = {45, 12, 89, 33, 7, 64, 21, 98, 5};
    int count = sizeof(default_data) / sizeof(default_data[0]);

    printf("[Process 1 (PID %d)] Enter count of numbers (or 0 for default 9 numbers): ", getpid());
    int user_n;
    if (scanf("%d", &user_n) == 1 && user_n > 0 && user_n <= MAX_SIZE) {
        shm->count = user_n;
        printf("Enter %d numbers:\n", user_n);
        for (int i = 0; i < user_n; i++) scanf("%d", &shm->arr[i]);
    } else {
        shm->count = count;
        for (int i = 0; i < count; i++) shm->arr[i] = default_data[i];
        printf("[Process 1] Using default dataset: ");
        for (int i = 0; i < count; i++) printf("%d ", default_data[i]);
        printf("\n");
    }

    printf("[Process 1] Array placed into shared memory. Signalling Process 2.\n");
    sem_signal_op(semid, 0); // Wake P2

    waitpid(p2, NULL, 0);
    waitpid(p3, NULL, 0);
    waitpid(p4, NULL, 0);

    shmdt(shm);
    shmctl(shmid, IPC_RMID, NULL);
    semctl(semid, 0, IPC_RMID);

    printf("[Process 1] All 4 processes synchronized and finished successfully.\n");
    return 0;
}
