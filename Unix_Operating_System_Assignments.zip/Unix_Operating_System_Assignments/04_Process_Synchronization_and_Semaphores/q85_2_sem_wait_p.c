/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 85: Create three separate programs:
 *              (1) initialize a semaphore and display its ID,
 *              (2) perform the P (wait) operation and print a message,
 *              (3) perform the V (signal) operation and print a message -
 *              all operating on the same semaphore.
 *              [PROGRAM 2: PERFORM P (WAIT) OPERATION]
 *
 * Compilation:
 *   gcc -Wall -O2 q85_2_sem_wait_p.c -o q85_2_sem_wait_p
 *
 * Execution:
 *   ./q85_2_sem_wait_p
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/sem.h>

#define SHARED_SEM_KEY 0x8585

int main() {
    int semid = semget(SHARED_SEM_KEY, 1, 0666);
    if (semid < 0) {
        printf("Error: Semaphore not found. Run './q85_1_sem_init' first!\n");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q85 [Part 2]: Perform P (Wait / Decrement) Operation       \n");
    printf(" Operating on Semaphore ID: %d\n", semid);
    printf("============================================================\n");

    printf("[Process PID: %d] Attempting P (wait) operation (decrement semaphore by 1)...\n", getpid());
    struct sembuf op = {0, -1, 0};
    if (semop(semid, &op, 1) == -1) {
        perror("semop P failed");
        exit(EXIT_FAILURE);
    }

    printf(">>> SUCCESS: P (wait) operation completed by Process %d! <<<\n", getpid());
    printf("Resource acquired. Semaphore decremented.\n");
    return 0;
}
