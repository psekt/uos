/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 11: Implement the Producer-Consumer problem using shared memory
 *              and semaphores.
 *
 * Semaphores:
 *   MUTEX (binary semaphore for critical section)
 *   EMPTY (counts free slots in bounded buffer)
 *   FULL  (counts filled items in bounded buffer)
 *
 * Compilation:
 *   gcc -Wall -O2 q11_producer_consumer_shm_sem.c -o q11_producer_consumer_shm_sem
 *
 * Execution:
 *   ./q11_producer_consumer_shm_sem
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/wait.h>

#define BUFFER_SIZE 5
#define TOTAL_ITEMS 10
#define SHM_KEY 0x1111
#define SEM_KEY 0x1112

#define SEM_MUTEX 0
#define SEM_EMPTY 1
#define SEM_FULL  2

union semun {
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};

struct shared_buffer {
    int in;
    int out;
    int items[BUFFER_SIZE];
};

void sem_wait_op(int semid, int sem_num) {
    struct sembuf op = {sem_num, -1, 0};
    semop(semid, &op, 1);
}

void sem_signal_op(int semid, int sem_num) {
    struct sembuf op = {sem_num, 1, 0};
    semop(semid, &op, 1);
}

int main() {
    // 1. Setup shared memory
    int shmid = shmget(SHM_KEY, sizeof(struct shared_buffer), IPC_CREAT | 0666);
    struct shared_buffer *buf = (struct shared_buffer*)shmat(shmid, NULL, 0);
    buf->in = 0;
    buf->out = 0;

    // 2. Setup semaphores: 3 semaphores
    int semid = semget(SEM_KEY, 3, IPC_CREAT | 0666);
    union semun arg;

    arg.val = 1; semctl(semid, SEM_MUTEX, SETVAL, arg);           // Mutex = 1
    arg.val = BUFFER_SIZE; semctl(semid, SEM_EMPTY, SETVAL, arg); // Empty = 5
    arg.val = 0; semctl(semid, SEM_FULL, SETVAL, arg);            // Full = 0

    printf("============================================================\n");
    printf(" Q11: Producer-Consumer Problem (Shared Memory + Semaphores) \n");
    printf(" Buffer Size: %d | Total Items: %d\n", BUFFER_SIZE, TOTAL_ITEMS);
    printf("============================================================\n");

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent: Producer
        for (int i = 1; i <= TOTAL_ITEMS; i++) {
            int item = i * 100;

            sem_wait_op(semid, SEM_EMPTY); // Wait for free slot
            sem_wait_op(semid, SEM_MUTEX); // Enter CS

            buf->items[buf->in] = item;
            printf("[PRODUCER] Produced item %d at slot %d\n", item, buf->in);
            buf->in = (buf->in + 1) % BUFFER_SIZE;

            sem_signal_op(semid, SEM_MUTEX); // Exit CS
            sem_signal_op(semid, SEM_FULL);  // Signal item available

            usleep(100000); // Simulate production time
        }

        wait(NULL);
        shmdt(buf);
        shmctl(shmid, IPC_RMID, NULL);
        semctl(semid, 0, IPC_RMID);
        printf("[PRODUCER] Finished and cleaned up IPC.\n");
    } else {
        // Child: Consumer
        for (int i = 1; i <= TOTAL_ITEMS; i++) {
            sem_wait_op(semid, SEM_FULL);  // Wait for item
            sem_wait_op(semid, SEM_MUTEX); // Enter CS

            int item = buf->items[buf->out];
            printf("  [CONSUMER] Consumed item %d from slot %d\n", item, buf->out);
            buf->out = (buf->out + 1) % BUFFER_SIZE;

            sem_signal_op(semid, SEM_MUTEX); // Exit CS
            sem_signal_op(semid, SEM_EMPTY); // Signal free slot

            usleep(150000); // Simulate consumption time
        }

        shmdt(buf);
        exit(EXIT_SUCCESS);
    }

    return 0;
}
