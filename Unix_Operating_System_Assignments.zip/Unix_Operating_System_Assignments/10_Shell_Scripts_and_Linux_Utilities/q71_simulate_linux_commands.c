/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 71: Implement programs that simulate common Linux commands
 *              such as cat, ls, cp, mv, head, etc.
 *
 * Compilation:
 *   gcc -Wall -O2 q71_simulate_linux_commands.c -o q71_simulate_linux_commands
 *
 * Execution:
 *   ./q71_simulate_linux_commands cat  [filename]
 *   ./q71_simulate_linux_commands head [filename] [lines: default 10]
 *   ./q71_simulate_linux_commands cp   [src] [dst]
 *   ./q71_simulate_linux_commands mv   [src] [dst]
 *   ./q71_simulate_linux_commands ls   [optional_dir_path]
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <fcntl.h>
#include <unistd.h>

void sim_cat(const char *filename) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("cat error");
        return;
    }
    char buf[512];
    while (fgets(buf, sizeof(buf), fp)) {
        fputs(buf, stdout);
    }
    fclose(fp);
}

void sim_head(const char *filename, int max_lines) {
    FILE *fp = fopen(filename, "r");
    if (!fp) {
        perror("head error");
        return;
    }
    char buf[512];
    int line_count = 0;
    while (line_count < max_lines && fgets(buf, sizeof(buf), fp)) {
        fputs(buf, stdout);
        line_count++;
    }
    fclose(fp);
}

void sim_cp(const char *src, const char *dst) {
    FILE *in = fopen(src, "rb");
    if (!in) {
        perror("cp source error");
        return;
    }
    FILE *out = fopen(dst, "wb");
    if (!out) {
        perror("cp destination error");
        fclose(in);
        return;
    }
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), in)) > 0) {
        fwrite(buf, 1, n, out);
    }
    fclose(in);
    fclose(out);
    printf("Successfully copied '%s' to '%s'\n", src, dst);
}

void sim_mv(const char *src, const char *dst) {
    if (rename(src, dst) == 0) {
        printf("Successfully moved '%s' to '%s'\n", src, dst);
    } else {
        // Fallback: copy then remove
        sim_cp(src, dst);
        unlink(src);
    }
}

void sim_ls(const char *dirpath) {
    DIR *d = opendir(dirpath);
    if (!d) {
        perror("ls error");
        return;
    }
    struct dirent *dir;
    printf("Contents of '%s':\n", dirpath);
    int col = 0;
    while ((dir = readdir(d)) != NULL) {
        printf("%-20s ", dir->d_name);
        col++;
        if (col % 4 == 0) printf("\n");
    }
    if (col % 4 != 0) printf("\n");
    closedir(d);
}

int main(int argc, char *argv[]) {
    printf("============================================================\n");
    printf(" Q71: Simulation of Linux Commands: cat, ls, cp, mv, head   \n");
    printf("============================================================\n");

    if (argc < 2) {
        printf("Usage:\n");
        printf("  %s cat  <file>\n", argv[0]);
        printf("  %s head <file> [lines]\n", argv[0]);
        printf("  %s cp   <source> <destination>\n", argv[0]);
        printf("  %s mv   <source> <destination>\n", argv[0]);
        printf("  %s ls   [directory]\n", argv[0]);
        printf("\nRunning interactive demonstration with 'ls .':\n");
        sim_ls(".");
        return 0;
    }

    const char *cmd = argv[1];

    if (strcmp(cmd, "cat") == 0 && argc >= 3) {
        sim_cat(argv[2]);
    } else if (strcmp(cmd, "head") == 0 && argc >= 3) {
        int lines = (argc >= 4) ? atoi(argv[3]) : 10;
        sim_head(argv[2], lines);
    } else if (strcmp(cmd, "cp") == 0 && argc >= 4) {
        sim_cp(argv[2], argv[3]);
    } else if (strcmp(cmd, "mv") == 0 && argc >= 4) {
        sim_mv(argv[2], argv[3]);
    } else if (strcmp(cmd, "ls") == 0) {
        const char *p = (argc >= 3) ? argv[2] : ".";
        sim_ls(p);
    } else {
        printf("Unknown command or missing parameters.\n");
    }

    return 0;
}
