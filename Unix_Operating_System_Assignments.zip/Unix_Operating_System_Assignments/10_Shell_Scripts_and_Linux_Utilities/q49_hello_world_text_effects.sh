#!/bin/bash
# ==============================================================================
# Assignment: Unix Operating System - External Practical Exam
# Question 49: Create a program (or script) that prints "Hello World" with
#              bold, blinking, and colored (red, blue, etc.) text effects.
#
# Usage:
#   chmod +x q49_hello_world_text_effects.sh
#   ./q49_hello_world_text_effects.sh
# ==============================================================================

# ANSI escape sequence definitions
RESET="\033[0m"
BOLD="\033[1m"
BLINK="\033[5m"
UNDERLINE="\033[4m"

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
BLUE="\033[34m"
MAGENTA="\033[35m"
CYAN="\033[36m"
WHITE="\033[37m"

echo "============================================================"
echo " Q49: Text Effects Demonstration (ANSI Escape Sequences)    "
echo "============================================================"

echo -e "1. Normal Text           : Hello World"
echo -e "2. ${BOLD}Bold Text             : Hello World${RESET}"
echo -e "3. ${BLINK}Blinking Text         : Hello World${RESET}"
echo -e "4. ${RED}Red Colored Text      : Hello World${RESET}"
echo -e "5. ${BLUE}Blue Colored Text     : Hello World${RESET}"
echo -e "6. ${GREEN}Green Colored Text    : Hello World${RESET}"
echo -e "7. ${MAGENTA}Magenta Text          : Hello World${RESET}"
echo -e "8. ${CYAN}Cyan Text             : Hello World${RESET}"
echo -e "9. ${BOLD}${RED}Bold + Red            : Hello World${RESET}"
echo -e "10. ${BOLD}${BLUE}Bold + Blue          : Hello World${RESET}"
echo -e "11. ${BOLD}${BLINK}${RED}Bold + Blink + Red   : Hello World${RESET}"
echo -e "12. ${BOLD}${BLINK}${CYAN}Bold + Blink + Cyan  : Hello World${RESET}"
echo "============================================================"
