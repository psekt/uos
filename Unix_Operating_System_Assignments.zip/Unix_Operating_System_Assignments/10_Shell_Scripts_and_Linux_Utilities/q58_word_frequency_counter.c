/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 58: Given a text file, write code to count word frequencies
 *              in the file (use file handling).
 *
 * Compilation:
 *   gcc -Wall -O2 q58_word_frequency_counter.c -o q58_word_frequency_counter
 *
 * Execution:
 *   ./q58_word_frequency_counter [text_file]
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_WORDS 1000
#define MAX_WORD_LEN 64

typedef struct {
    char word[MAX_WORD_LEN];
    int count;
} WordFreq;

void clean_word(char *dest, const char *src) {
    int j = 0;
    for (int i = 0; src[i] != '\0' && j < MAX_WORD_LEN - 1; i++) {
        if (isalnum((unsigned char)src[i])) {
            dest[j++] = tolower((unsigned char)src[i]);
        }
    }
    dest[j] = '\0';
}

int main(int argc, char *argv[]) {
    const char *filepath = (argc > 1) ? argv[1] : "sample_text.txt";

    // Auto-create sample text file if needed
    FILE *test = fopen(filepath, "r");
    if (!test) {
        FILE *gen = fopen(filepath, "w");
        if (gen) {
            fprintf(gen, "Unix operating system is powerful. Unix provides IPC mechanisms.\n"
                         "Pipes, shared memory, and message queues are part of Unix.\n"
                         "The Unix operating system handles processes and threads efficiently.\n");
            fclose(gen);
        }
    } else {
        fclose(test);
    }

    FILE *fp = fopen(filepath, "r");
    if (!fp) {
        perror("File open failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q58: Word Frequency Counter (File Handling in C)           \n");
    printf(" Analyzing file: %s\n", filepath);
    printf("============================================================\n");

    WordFreq table[MAX_WORDS];
    int total_unique_words = 0;
    int total_words_count = 0;
    char raw_word[MAX_WORD_LEN];
    char clean[MAX_WORD_LEN];

    while (fscanf(fp, "%63s", raw_word) == 1) {
        clean_word(clean, raw_word);
        if (strlen(clean) == 0) continue;

        total_words_count++;
        int found = 0;
        for (int i = 0; i < total_unique_words; i++) {
            if (strcmp(table[i].word, clean) == 0) {
                table[i].count++;
                found = 1;
                break;
            }
        }

        if (!found && total_unique_words < MAX_WORDS) {
            strcpy(table[total_unique_words].word, clean);
            table[total_unique_words].count = 1;
            total_unique_words++;
        }
    }
    fclose(fp);

    printf("Total Words Counted : %d\n", total_words_count);
    printf("Unique Words Found  : %d\n", total_unique_words);
    printf("------------------------------------------------------------\n");
    printf(" %-20s | %s\n", "WORD", "FREQUENCY");
    printf("------------------------------------------------------------\n");

    for (int i = 0; i < total_unique_words; i++) {
        printf(" %-20s | %d\n", table[i].word, table[i].count);
    }
    printf("============================================================\n");

    return 0;
}
