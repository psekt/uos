#!/bin/bash
# ==============================================================================
# Assignment: Unix Operating System - External Practical Exam
# Question 46: Implement a digital clock using a shell script.
#
# Usage:
#   chmod +x q46_digital_clock.sh
#   ./q46_digital_clock.sh
# (Press Ctrl+C to stop the clock)
# ==============================================================================

# ANSI Color codes
CYAN='\033[1;36m'
YELLOW='\033[1;33m'
GREEN='\033[1;32m'
RESET='\033[0m'

trap "echo -e '\n${RESET}Digital clock stopped.'; exit 0" SIGINT SIGTERM

while true; do
    clear
    echo -e "${CYAN}============================================================${RESET}"
    echo -e "${YELLOW}               LIVE UNIX DIGITAL CLOCK                      ${RESET}"
    echo -e "${CYAN}============================================================${RESET}"
    echo ""
    echo -e "         ${GREEN}DATE : $(date '+%A, %d %B %Y')${RESET}"
    echo -e "         ${YELLOW}TIME : $(date '+%I:%M:%S %p %Z')${RESET}"
    echo ""
    echo -e "${CYAN}============================================================${RESET}"
    echo " Press [Ctrl+C] to exit the clock."
    sleep 1
done
