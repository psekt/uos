/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 49: C Program implementation for printing "Hello World" with
 *              bold, blinking, and colored text effects using ANSI codes.
 *
 * Compilation:
 *   gcc -Wall -O2 q49_hello_world_ansi_effects.c -o q49_hello_world_ansi_effects
 *
 * Execution:
 *   ./q49_hello_world_ansi_effects
 */

#include <stdio.h>

#define ANSI_RESET        "\x1b[0m"
#define ANSI_BOLD         "\x1b[1m"
#define ANSI_BLINK        "\x1b[5m"

#define ANSI_COLOR_RED    "\x1b[31m"
#define ANSI_COLOR_GREEN  "\x1b[32m"
#define ANSI_COLOR_YELLOW "\x1b[33m"
#define ANSI_COLOR_BLUE   "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_CYAN   "\x1b[36m"

int main() {
    printf("============================================================\n");
    printf(" Q49: Hello World with ANSI Formatting and Text Effects (C) \n");
    printf("============================================================\n");

    printf("Normal              : Hello World\n");
    printf(ANSI_BOLD "Bold                : Hello World\n" ANSI_RESET);
    printf(ANSI_BLINK "Blinking            : Hello World\n" ANSI_RESET);
    printf(ANSI_COLOR_RED "Colored (Red)       : Hello World\n" ANSI_RESET);
    printf(ANSI_COLOR_BLUE "Colored (Blue)      : Hello World\n" ANSI_RESET);
    printf(ANSI_COLOR_GREEN "Colored (Green)     : Hello World\n" ANSI_RESET);
    printf(ANSI_BOLD ANSI_COLOR_RED "Bold + Red          : Hello World\n" ANSI_RESET);
    printf(ANSI_BOLD ANSI_COLOR_BLUE "Bold + Blue         : Hello World\n" ANSI_RESET);
    printf(ANSI_BOLD ANSI_BLINK ANSI_COLOR_CYAN "Bold + Blink + Cyan : Hello World\n" ANSI_RESET);
    printf("============================================================\n");

    return 0;
}
