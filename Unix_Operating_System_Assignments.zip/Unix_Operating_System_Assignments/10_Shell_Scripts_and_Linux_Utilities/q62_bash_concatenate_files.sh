#!/bin/bash
# ==============================================================================
# Assignment: Unix Operating System - External Practical Exam
# Question 62: Create a bash script that accepts two or more arguments
#              where each argument is a filename; if fewer than two arguments
#              are given print an error; if any file does not exist print
#              an error; otherwise concatenate the files.
#
# Usage:
#   chmod +x q62_bash_concatenate_files.sh
#   ./q62_bash_concatenate_files.sh file1 file2 [file3 ...]
# ==============================================================================

echo "============================================================"
echo " Q62: File Concatenation with Strict Validation             "
echo "============================================================"

# Check 1: Fewer than two arguments given
if [ "$#" -lt 2 ]; then
    echo "ERROR: Insufficient arguments! At least 2 filenames are required." >&2
    echo "Usage: $0 <file1> <file2> [file3 ...]" >&2
    exit 1
fi

# Check 2: Verify that every single file exists
for file in "$@"; do
    if [ ! -f "$file" ]; then
        echo "ERROR: File '$file' does not exist or is not a regular file!" >&2
        exit 2
    fi
done

echo "Validation passed! Concatenating $# files in order:"
echo "------------------------------------------------------------"

# Concatenate all files to stdout
cat "$@"

echo "------------------------------------------------------------"
echo "Files concatenated successfully!"
