#!/bin/bash
# ==============================================================================
# Assignment: Unix Operating System - External Practical Exam
# Question 52: Write a shell script to locate a given file on the system
#              using find or locate.
#
# Usage:
#   chmod +x q52_locate_file.sh
#   ./q52_locate_file.sh [filename] [search_root_directory]
# ==============================================================================

TARGET_FILE=${1}
SEARCH_ROOT=${2:-"."}

echo "============================================================"
echo " Q52: Locate File on System Using find / locate             "
echo "============================================================"

if [ -z "$TARGET_FILE" ]; then
    read -p "Enter filename to search for: " TARGET_FILE
fi

echo "Searching for '$TARGET_FILE' starting from '$SEARCH_ROOT'..."
echo "------------------------------------------------------------"

# Attempt locate first if installed
if command -v locate > /dev/null 2>&1; then
    echo "Method 1: Using 'locate' command database:"
    locate -b "$TARGET_FILE" 2>/dev/null
    echo ""
fi

# Use find command (standard on all POSIX/Unix systems)
echo "Method 2: Using 'find' filesystem search:"
find "$SEARCH_ROOT" -name "$TARGET_FILE" 2>/dev/null

echo "------------------------------------------------------------"
echo "Search completed."
