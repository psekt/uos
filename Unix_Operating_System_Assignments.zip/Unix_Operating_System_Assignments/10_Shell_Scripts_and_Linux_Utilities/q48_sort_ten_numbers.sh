#!/bin/bash
# ==============================================================================
# Assignment: Unix Operating System - External Practical Exam
# Question 48: Write a shell script to sort ten given numbers in ascending order.
#
# Usage:
#   chmod +x q48_sort_ten_numbers.sh
#   ./q48_sort_ten_numbers.sh
# ==============================================================================

echo "============================================================"
echo " Q48: Sort Ten Numbers in Ascending Order                   "
echo "============================================================"

declare -a arr

echo "Please enter 10 integer numbers:"
for ((i=0; i<10; i++)); do
    read -p "Number [$((i+1))]: " num
    # Fallback to random if user enters empty
    if [ -z "$num" ]; then
        num=$(( (10 - i) * 7 ))
        echo "Using default: $num"
    fi
    arr[$i]=$num
done

echo ""
echo "Original numbers array: ${arr[@]}"

# Bubble sort implementation in Bash
n=10
for ((i=0; i<n-1; i++)); do
    for ((j=0; j<n-i-1; j++)); do
        if [ ${arr[j]} -gt ${arr[$((j+1))]} ]; then
            temp=${arr[j]}
            arr[j]=${arr[$((j+1))]}
            arr[$((j+1))]=$temp
        fi
    done
done

echo "------------------------------------------------------------"
echo "SORTED IN ASCENDING ORDER: ${arr[@]}"
echo "------------------------------------------------------------"
