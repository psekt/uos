#!/bin/bash
# ==============================================================================
# Assignment: Unix Operating System - External Practical Exam
# Question 47: Write a shell script that checks whether the system is connected
#              to a network by using the ping command.
#
# Usage:
#   chmod +x q47_check_network_ping.sh
#   ./q47_check_network_ping.sh [optional_target_host]
# ==============================================================================

TARGET=${1:-"8.8.8.8"} # Default to Google Public DNS
HOSTNAME_TARGET="google.com"

echo "============================================================"
echo " Q47: Network Connectivity Checker via ping                 "
echo " Target IP/Host: $TARGET"
echo "============================================================"

echo "Pinging $TARGET (sending 3 ICMP echo requests)..."
ping -c 3 -W 3 "$TARGET" > /dev/null 2>&1

if [ $? -eq 0 ]; then
    echo "------------------------------------------------------------"
    echo " STATUS: CONNECTED"
    echo " The system is successfully connected to the network/internet!"
    echo " Host $TARGET responded to ping packets."
    echo "------------------------------------------------------------"
    exit 0
else
    echo "------------------------------------------------------------"
    echo " STATUS: DISCONNECTED / UNREACHABLE"
    echo " Unable to reach $TARGET. Check network adapter or cable."
    echo "------------------------------------------------------------"
    exit 1
fi
