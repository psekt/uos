#!/bin/bash
# ==============================================================================
# Assignment: Unix Operating System - External Practical Exam
# Question 51: Create a shell script that displays disk partitions, their
#              sizes, and disk usage/free space.
#
# Usage:
#   chmod +x q51_disk_partitions_usage.sh
#   ./q51_disk_partitions_usage.sh
# ==============================================================================

echo "============================================================"
echo " Q51: Disk Partitions, Sizes, and Free Space Report         "
echo " Generated on: $(date)"
echo "============================================================"

echo ""
echo ">>> 1. BLOCK DEVICES & PARTITION LAYOUT (lsblk) <<<"
if command -v lsblk > /dev/null 2>&1; then
    lsblk -o NAME,FSTYPE,SIZE,MOUNTPOINT,MODEL
else
    echo "lsblk not available on this system; displaying fdisk/df."
fi

echo ""
echo ">>> 2. FILESYSTEM DISK SPACE USAGE & FREE SPACE (df -h) <<<"
df -h --output=source,fstype,size,used,avail,pcent,target 2>/dev/null || df -h

echo ""
echo "============================================================"
