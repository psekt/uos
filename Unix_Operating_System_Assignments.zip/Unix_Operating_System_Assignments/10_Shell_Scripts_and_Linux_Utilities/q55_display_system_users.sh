#!/bin/bash
# ==============================================================================
# Assignment: Unix Operating System - External Practical Exam
# Question 55: Write a shell script that displays system users
#              (using finger or who).
#
# Usage:
#   chmod +x q55_display_system_users.sh
#   ./q55_display_system_users.sh
# ==============================================================================

echo "============================================================"
echo " Q55: Display Currently Logged-in System Users              "
echo "============================================================"

echo ""
echo ">>> METHOD 1: Using 'who' command <<<"
who -H 2>/dev/null || who

echo ""
echo ">>> METHOD 2: Using 'w' command (summary + activity) <<<"
w 2>/dev/null || echo "'w' command unavailable."

echo ""
echo ">>> METHOD 3: Using 'finger' command <<<"
if command -v finger > /dev/null 2>&1; then
    finger
else
    echo "'finger' command is not installed. Use 'sudo apt install finger' on Debian/Ubuntu."
fi

echo ""
echo ">>> METHOD 4: All local user accounts in /etc/passwd <<<"
if [ -f /etc/passwd ]; then
    echo "Total user accounts: $(wc -l < /etc/passwd)"
    echo "Sample users (first 10):"
    awk -F: '{ printf "User: %-15s UID: %-6s Shell: %s\n", $1, $3, $7 }' /etc/passwd | head -n 10
fi

echo "============================================================"
