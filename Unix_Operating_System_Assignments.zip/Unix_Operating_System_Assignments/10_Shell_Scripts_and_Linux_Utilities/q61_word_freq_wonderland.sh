#!/bin/bash
# ==============================================================================
# Assignment: Unix Operating System - External Practical Exam
# Question 61: Produce a word-frequency list for wonderland.txt
#              (hint: use grep, tr, sort, uniq, or similar tools).
#
# Usage:
#   chmod +x q61_word_freq_wonderland.sh
#   ./q61_word_freq_wonderland.sh [optional_file: default wonderland.txt]
# ==============================================================================

TARGET=${1:-"wonderland.txt"}

echo "============================================================"
echo " Q61: Word-Frequency List for $TARGET                       "
echo " Tools: tr, sort, uniq, awk                                 "
echo "============================================================"

# Auto-generate wonderland.txt if missing
if [ ! -f "$TARGET" ]; then
    echo "Generating sample '$TARGET'..."
    cat << 'EOF' > "$TARGET"
Alice was beginning to get very tired of sitting by her sister on the bank,
and of having nothing to do: once or twice she had peeped into the book
her sister was reading, but it had no pictures or conversations in it,
"and what is the use of a book," thought Alice "without pictures or conversation?"
So she was considering in her own mind as well as she could,
for the hot day made her feel very sleepy and stupid, whether the pleasure
of making a daisy-chain would be worth the trouble of getting up and picking the daisies,
when suddenly a White Rabbit with pink eyes ran close by her.
EOF
fi

echo "Top 15 Most Frequent Words in $TARGET:"
echo "------------------------------------------------------------"
printf "%-10s | %s\n" "COUNT" "WORD"
echo "------------------------------------------------------------"

# Pipeline explanation:
# 1. tr -cs '[:alpha:]' '[\n*]' -> Convert non-alphabetic characters into newlines
# 2. tr '[:upper:]' '[:lower:]' -> Convert all letters to lowercase
# 3. grep -v '^$'               -> Remove empty lines
# 4. sort                       -> Sort alphabetically so duplicates are contiguous
# 5. uniq -c                    -> Count frequency of each word
# 6. sort -nr                   -> Sort numerically in descending order
# 7. head -n 15                 -> Display top 15 words

tr -cs '[:alpha:]' '[\n*]' < "$TARGET" | \
tr '[:upper:]' '[:lower:]' | \
grep -v '^$' | \
sort | \
uniq -c | \
sort -nr | \
head -n 15 | \
while read -r count word; do
    printf "%-10s | %s\n" "$count" "$word"
done

echo "------------------------------------------------------------"
