#!/bin/bash
# ==============================================================================
# Assignment: Unix Operating System - External Practical Exam
# Question 60: Write a shell script that takes a filename and checks whether
#              it is executable; then modify it to remove execute permission
#              if the file is executable.
#
# Usage:
#   chmod +x q60_check_remove_execute_permission.sh
#   ./q60_check_remove_execute_permission.sh [filename]
# ==============================================================================

FILE=${1}

echo "============================================================"
echo " Q60: Check & Remove File Execute Permission                "
echo "============================================================"

if [ -z "$FILE" ]; then
    read -p "Enter filename to inspect: " FILE
fi

# Create a demo script if user targets demo
if [ ! -e "$FILE" ]; then
    echo "Creating test target file '$FILE' with +x permission..."
    touch "$FILE"
    chmod +x "$FILE"
fi

echo "Inspecting file: $FILE"
echo "Current permissions: $(ls -l "$FILE")"

if [ -x "$FILE" ]; then
    echo ""
    echo ">> File '$FILE' IS EXECUTABLE."
    echo "Removing execute permission using: chmod -x \"$FILE\"..."
    chmod -x "$FILE"
    echo ">> Update complete!"
    echo "New permissions    : $(ls -l "$FILE")"
else
    echo ""
    echo ">> File '$FILE' is NOT executable. No permissions changed."
fi

echo "============================================================"
