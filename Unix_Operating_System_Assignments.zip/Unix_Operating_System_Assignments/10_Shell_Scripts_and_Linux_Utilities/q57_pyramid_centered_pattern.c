/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 57: Write a program that prints a pyramid with the number of lines
 *              supplied by the user; center the pyramid as closely as possible.
 *              (Hint: nested loops)
 *
 * Compilation:
 *   gcc -Wall -O2 q57_pyramid_centered_pattern.c -o q57_pyramid_centered_pattern
 *
 * Execution:
 *   ./q57_pyramid_centered_pattern [number_of_lines: default 6]
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int rows;

    if (argc > 1) {
        rows = atoi(argv[1]);
    } else {
        printf("Enter number of lines for pyramid (e.g. 6): ");
        if (scanf("%d", &rows) != 1) rows = 6;
    }

    if (rows <= 0) rows = 6;

    printf("============================================================\n");
    printf(" Q57: Centered Pyramid Pattern with Nested Loops            \n");
    printf(" Rows: %d\n", rows);
    printf("============================================================\n\n");

    // Outer loop for rows
    for (int i = 1; i <= rows; i++) {
        // Inner loop 1: leading spaces for centering
        for (int space = 1; space <= rows - i; space++) {
            printf(" ");
        }

        // Inner loop 2: stars with space for pyramid look
        for (int star = 1; star <= (2 * i - 1); star++) {
            printf("*");
        }

        printf("\n");
    }

    printf("\n============================================================\n");
    return 0;
}
