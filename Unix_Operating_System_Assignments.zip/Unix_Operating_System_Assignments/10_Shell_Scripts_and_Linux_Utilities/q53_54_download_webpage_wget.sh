#!/bin/bash
# ==============================================================================
# Assignment: Unix Operating System - External Practical Exam
# Questions 53 & 54: Write a shell script that downloads a webpage from a
#                    given URL using wget. (54 marked duplicate in PDF)
#
# Usage:
#   chmod +x q53_54_download_webpage_wget.sh
#   ./q53_54_download_webpage_wget.sh [URL] [output_filename]
# ==============================================================================

URL=${1:-"https://example.com"}
OUTPUT_FILE=${2:-"downloaded_page.html"}

echo "============================================================"
echo " Q53 & Q54: Download Webpage via wget                       "
echo " Target URL : $URL"
echo " Output File: $OUTPUT_FILE"
echo "============================================================"

if ! command -v wget > /dev/null 2>&1; then
    echo "wget is not installed; attempting download with curl as alternative..."
    if command -v curl > /dev/null 2>&1; then
        curl -s -L "$URL" -o "$OUTPUT_FILE"
    else
        echo "Error: Neither wget nor curl is installed on this system."
        exit 1
    fi
else
    # Download with wget
    wget --no-check-certificate -q --show-progress "$URL" -O "$OUTPUT_FILE"
fi

if [ -f "$OUTPUT_FILE" ] && [ -s "$OUTPUT_FILE" ]; then
    echo ""
    echo ">> SUCCESS: Webpage downloaded successfully!"
    echo "File size: $(wc -c < "$OUTPUT_FILE") bytes"
    echo "First 5 lines of downloaded page:"
    head -n 5 "$OUTPUT_FILE"
else
    echo "Failed to download webpage from $URL."
fi
echo "============================================================"
