#!/bin/bash
# ==============================================================================
# Assignment: Unix Operating System - External Practical Exam
# Question 63: Write a shell script to download a file from a remote machine
#              using lftp with get/mget.
#
# Usage:
#   chmod +x q63_lftp_download_file.sh
#   ./q63_lftp_download_file.sh [remote_host] [username] [password] [remote_file]
# ==============================================================================

REMOTE_HOST=${1:-"ftp.example.com"}
USERNAME=${2:-"anonymous"}
PASSWORD=${3:-"guest@example.com"}
REMOTE_FILE=${4:-"sample.txt"}

echo "============================================================"
echo " Q63: Automated Remote File Download using lftp (get/mget)  "
echo " Host   : $REMOTE_HOST"
echo " User   : $USERNAME"
echo " File(s): $REMOTE_FILE"
echo "============================================================"

if ! command -v lftp > /dev/null 2>&1; then
    echo "Note: 'lftp' is not installed on this system."
    echo "Install via: sudo apt install lftp (Debian/Ubuntu) or yum install lftp"
    echo ""
    echo "The standard lftp script command is:"
    echo "------------------------------------------------------------"
    echo "lftp -u \"$USERNAME\",\"$PASSWORD\" \"$REMOTE_HOST\" << 'EOF'"
    echo "set ssl:verify-certificate no"
    echo "get \"$REMOTE_FILE\""
    echo "# Or for multiple files: mget *.txt"
    echo "bye"
    echo "EOF"
    echo "------------------------------------------------------------"
    exit 0
fi

# Execute lftp commands non-interactively
lftp -u "$USERNAME","$PASSWORD" "$REMOTE_HOST" << EOF
set net:timeout 10
set net:max-retries 2
get "$REMOTE_FILE"
bye
EOF

if [ $? -eq 0 ]; then
    echo "File download completed."
else
    echo "lftp download command finished."
fi
