/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 56: Companion C implementation: Recursive prime numbers generator.
 *
 * Compilation:
 *   gcc -Wall -O2 q56_recursive_primes.c -o q56_recursive_primes
 *
 * Execution:
 *   ./q56_recursive_primes [limit: default 50]
 */

#include <stdio.h>
#include <stdlib.h>

int is_prime_recursive(int n, int d) {
    if (n <= 1) return 0;
    if (d * d > n) return 1;
    if (n % d == 0) return 0;
    return is_prime_recursive(n, d + 1);
}

void print_primes_recursive(int curr, int limit) {
    if (curr > limit) return;
    if (is_prime_recursive(curr, 2)) {
        printf("%d ", curr);
    }
    print_primes_recursive(curr + 1, limit);
}

int main(int argc, char *argv[]) {
    int limit = (argc > 1) ? atoi(argv[1]) : 50;
    if (limit <= 1) limit = 50;

    printf("============================================================\n");
    printf(" Q56: Recursive Prime Numbers Generator (C)                 \n");
    printf(" Generating primes up to limit = %d:\n", limit);
    printf("============================================================\n");

    print_primes_recursive(2, limit);
    printf("\n============================================================\n");
    return 0;
}
