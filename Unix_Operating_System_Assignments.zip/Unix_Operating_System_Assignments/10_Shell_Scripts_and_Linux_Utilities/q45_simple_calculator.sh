#!/bin/bash
# ==============================================================================
# Assignment: Unix Operating System - External Practical Exam
# Question 45: Write a shell script that implements a simple calculator.
#
# Usage:
#   chmod +x q45_simple_calculator.sh
#   ./q45_simple_calculator.sh
# ==============================================================================

clear
echo "============================================================"
echo " Q45: Simple Shell Script Calculator                        "
echo "============================================================"

while true; do
    echo ""
    echo "1. Addition (+)"
    echo "2. Subtraction (-)"
    echo "3. Multiplication (*)"
    echo "4. Division (/)"
    echo "5. Modulo (%)"
    echo "6. Exit"
    read -p "Select an operation (1-6): " choice

    if [ "$choice" -eq 6 ] 2>/dev/null; then
        echo "Exiting calculator. Goodbye!"
        break
    fi

    if [ "$choice" -lt 1 ] 2>/dev/null || [ "$choice" -gt 6 ] 2>/dev/null; then
        echo "Invalid selection! Please enter a number between 1 and 6."
        continue
    fi

    read -p "Enter first number : " num1
    read -p "Enter second number: " num2

    case $choice in
        1)
            result=$(echo "$num1 + $num2" | bc -l)
            echo ">> Result: $num1 + $num2 = $result"
            ;;
        2)
            result=$(echo "$num1 - $num2" | bc -l)
            echo ">> Result: $num1 - $num2 = $result"
            ;;
        3)
            result=$(echo "$num1 * $num2" | bc -l)
            echo ">> Result: $num1 * $num2 = $result"
            ;;
        4)
            if [ "$(echo "$num2 == 0" | bc)" -eq 1 ]; then
                echo ">> Error: Division by zero is undefined!"
            else
                result=$(echo "scale=4; $num1 / $num2" | bc -l)
                echo ">> Result: $num1 / $num2 = $result"
            fi
            ;;
        5)
            if [ "$num2" -eq 0 ] 2>/dev/null; then
                echo ">> Error: Modulo by zero is undefined!"
            else
                result=$(( num1 % num2 ))
                echo ">> Result: $num1 % $num2 = $result"
            fi
            ;;
    esac
done
