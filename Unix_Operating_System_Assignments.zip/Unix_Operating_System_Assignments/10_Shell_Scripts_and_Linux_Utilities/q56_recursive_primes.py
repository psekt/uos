#!/usr/bin/env python3
"""
Assignment: Unix Operating System - External Practical Exam
Question 56: Implement a recursive Python function that generates prime numbers
             up to a given limit (limit passed as a parameter).

Usage:
    python q56_recursive_primes.py [limit: default 50]
"""

import sys

def is_prime_recursive(n: int, divisor: int = 2) -> bool:
    """Recursively checks if n is a prime number."""
    if n <= 1:
        return False
    if divisor * divisor > n:
        return True
    if n % divisor == 0:
        return False
    return is_prime_recursive(n, divisor + 1)

def generate_primes_recursive(current: int, limit: int, primes_list: list = None) -> list:
    """Recursively collects all prime numbers from current up to limit."""
    if primes_list is None:
        primes_list = []
    
    if current > limit:
        return primes_list
    
    if is_prime_recursive(current):
        primes_list.append(current)
    
    return generate_primes_recursive(current + 1, limit, primes_list)

def main():
    limit = int(sys.argv[1]) if len(sys.argv) > 1 else 50

    print("=" * 60)
    print(f" Q56: Recursive Prime Numbers Generator up to {limit}       ")
    print("=" * 60)

    primes = generate_primes_recursive(2, limit)
    print(f"Total primes found up to {limit}: {len(primes)}")
    print("Primes list:")
    print(primes)
    print("=" * 60)

if __name__ == "__main__":
    main()
