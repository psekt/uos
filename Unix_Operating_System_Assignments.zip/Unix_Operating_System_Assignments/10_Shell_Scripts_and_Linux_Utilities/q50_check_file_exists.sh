#!/bin/bash
# ==============================================================================
# Assignment: Unix Operating System - External Practical Exam
# Question 50: Write a shell script that checks whether a specified file
#              exists in a given folder or drive.
#
# Usage:
#   chmod +x q50_check_file_exists.sh
#   ./q50_check_file_exists.sh [directory_path] [filename]
# ==============================================================================

DIR_PATH=${1}
FILE_NAME=${2}

echo "============================================================"
echo " Q50: Check if File Exists in Specified Folder/Drive        "
echo "============================================================"

if [ -z "$DIR_PATH" ]; then
    read -p "Enter folder/directory path (e.g. /etc or .): " DIR_PATH
fi

if [ -z "$FILE_NAME" ]; then
    read -p "Enter filename to search for (e.g. passwd or sample.txt): " FILE_NAME
fi

FULL_PATH="${DIR_PATH%/}/$FILE_NAME"

echo ""
echo "Checking directory: $DIR_PATH"
echo "Target file       : $FILE_NAME"
echo "Full search path  : $FULL_PATH"
echo "------------------------------------------------------------"

if [ ! -d "$DIR_PATH" ]; then
    echo "ERROR: Directory '$DIR_PATH' does not exist!"
    exit 1
fi

if [ -f "$FULL_PATH" ]; then
    echo ">> FOUND: File '$FILE_NAME' EXISTS in '$DIR_PATH'!"
    echo "File details:"
    ls -lh "$FULL_PATH"
elif [ -e "$FULL_PATH" ]; then
    echo ">> FOUND: An entry named '$FILE_NAME' exists (e.g., directory/special file) in '$DIR_PATH'."
    ls -ld "$FULL_PATH"
else
    echo ">> NOT FOUND: File '$FILE_NAME' DOES NOT exist in '$DIR_PATH'."
fi
echo "------------------------------------------------------------"
