/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 29: Implement a program using vfork() where the child reads a
 *              login name and the parent reads the password.
 *
 * Concept:
 *   vfork() suspends the parent process until the child either calls _exit()
 *   or an exec function. Furthermore, the child borrows the parent's address
 *   space and memory, so variables modified by the child directly reflect
 *   in the parent!
 *
 * Compilation:
 *   gcc -Wall -O2 q29_vfork_login_password.c -o q29_vfork_login_password
 *
 * Execution:
 *   ./q29_vfork_login_password
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

char login_name[64] = "";
char password[64] = "";

int main() {
    printf("============================================================\n");
    printf(" Q29: vfork() Child Reads Login, Parent Reads Password      \n");
    printf("============================================================\n");

    printf("[Parent PID: %d] Calling vfork()...\n", getpid());

    pid_t pid = vfork();
    if (pid < 0) {
        perror("vfork failed");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {
        // Child Process: runs FIRST while parent is suspended
        printf("\n[Child Process PID: %d (borrowing parent memory)]\n", getpid());
        printf("Please enter LOGIN NAME: ");
        if (fgets(login_name, sizeof(login_name), stdin) == NULL) {
            strcpy(login_name, "student_admin\n");
        }
        login_name[strcspn(login_name, "\r\n")] = '\0';

        printf("[Child] Login name '%s' recorded in address space.\n", login_name);
        printf("[Child] Calling _exit() to resume parent process.\n\n");
        _exit(0); // MUST use _exit() in vfork child to avoid corrupting parent stdio buffers
    }

    // Parent Process: resumes AFTER child exits
    printf("[Parent Process PID: %d (Resumed)]\n", getpid());
    printf("Parent sees login name read by child: \"%s\"\n", login_name);
    printf("Now, parent prompts for PASSWORD: ");
    if (fgets(password, sizeof(password), stdin) == NULL) {
        strcpy(password, "unix_secret_pass\n");
    }
    password[strcspn(password, "\r\n")] = '\0';

    printf("\n==================== CREDENTIALS SUMMARY ====================\n");
    printf(" Login Name (read by child): %s\n", login_name);
    printf(" Password   (read by parent): %s\n", password);
    printf(" Authentication successful!\n");
    printf("============================================================\n");

    return 0;
}
