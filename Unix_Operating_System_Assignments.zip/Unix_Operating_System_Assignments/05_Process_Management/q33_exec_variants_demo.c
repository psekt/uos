/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 33: Write a program to illustrate different variants of the exec()
 *              family of system calls.
 *
 * Variants demonstrated:
 *   1. execl()   - List of arguments
 *   2. execlp()  - List of arguments, searches PATH
 *   3. execle()  - List of arguments with custom Environment variables
 *   4. execv()   - Vector (array) of arguments
 *   5. execvp()  - Vector of arguments, searches PATH
 *   6. execvpe() - Vector of arguments, custom Environment, searches PATH
 *
 * Compilation:
 *   gcc -Wall -O2 q33_exec_variants_demo.c -o q33_exec_variants_demo
 *
 * Execution:
 *   ./q33_exec_variants_demo
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

void test_variant(int choice) {
    char *env[] = {"COURSE=Unix_OS", "EXAM=Practical_2026", NULL};

    switch (choice) {
        case 1:
            printf("\n--- 1. Testing execl(\"/bin/echo\", \"echo\", \"[execl] Success\", NULL) ---\n");
            execl("/bin/echo", "echo", "[execl] Successfully executed!", NULL);
            // Fallback for systems without /bin/echo
            execlp("echo", "echo", "[execl] Successfully executed!", NULL);
            break;
        case 2:
            printf("\n--- 2. Testing execlp(\"echo\", \"echo\", \"[execlp] Success\", NULL) ---\n");
            execlp("echo", "echo", "[execlp] Successfully executed with PATH lookup!", NULL);
            break;
        case 3:
            printf("\n--- 3. Testing execle(\"/usr/bin/env\" or fallback with custom env) ---\n");
            execle("/bin/sh", "sh", "-c", "echo [execle] Custom Var: $COURSE", NULL, env);
            break;
        case 4: {
            printf("\n--- 4. Testing execv(\"/bin/echo\", args) ---\n");
            char *args[] = {"/bin/echo", "[execv] Successfully executed with argument vector!", NULL};
            execv(args[0], args);
            // Fallback
            execvp("echo", args);
            break;
        }
        case 5: {
            printf("\n--- 5. Testing execvp(\"echo\", args) ---\n");
            char *args[] = {"echo", "[execvp] Successfully executed with vector & PATH lookup!", NULL};
            execvp(args[0], args);
            break;
        }
        case 6: {
            printf("\n--- 6. Testing execvpe(\"sh\", args, env) ---\n");
            char *args[] = {"sh", "-c", "echo [execvpe] Course: $COURSE, Exam: $EXAM", NULL};
            #ifdef __GLIBC__
            execvpe(args[0], args, env);
            #else
            execvp(args[0], args);
            #endif
            break;
        }
    }
    perror("exec failed");
    exit(EXIT_FAILURE);
}

int main() {
    printf("============================================================\n");
    printf(" Q33: Illustration of exec() Family System Calls            \n");
    printf(" Demonstrating: execl, execlp, execle, execv, execvp, execvpe\n");
    printf("============================================================\n");

    for (int i = 1; i <= 6; i++) {
        pid_t pid = fork();
        if (pid == 0) {
            test_variant(i);
        } else {
            wait(NULL);
        }
    }

    printf("\nAll 6 variants of exec() family illustrated successfully!\n");
    return 0;
}
