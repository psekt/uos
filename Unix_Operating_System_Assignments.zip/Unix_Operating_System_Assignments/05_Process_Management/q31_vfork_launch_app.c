/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 31: Write a program that launches an application using the
 *              vfork() system call.
 *
 * Compilation:
 *   gcc -Wall -O2 q31_vfork_launch_app.c -o q31_vfork_launch_app
 *
 * Execution:
 *   ./q31_vfork_launch_app
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    printf("============================================================\n");
    printf(" Q31: Launch External Application Using vfork()             \n");
    printf("============================================================\n");

    printf("[Parent PID: %d] Invoking vfork()...\n", getpid());

    pid_t pid = vfork();
    if (pid < 0) {
        perror("vfork failed");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {
        // Child: Launches application via exec
        char *args[] = {"uname", "-a", NULL};
        printf("[Child PID: %d] Launching application '%s %s' via execvp...\n", getpid(), args[0], args[1]);

        execvp(args[0], args);

        // Fallback if uname is not available
        char *fallback[] = {"echo", "Application successfully launched via vfork!", NULL};
        execvp(fallback[0], fallback);

        _exit(127);
    }

    // Parent
    int status;
    wait(&status);
    printf("\n[Parent PID: %d] Application launch via vfork() completed.\n", getpid());
    printf("[Parent] Child exit code: %d\n", WEXITSTATUS(status));

    return 0;
}
