/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 28: Implement a program that uses the fork() system call to create
 *              five child processes and assigns a distinct operation to each child.
 *
 * Child Operations:
 *   Child 1: Factorial calculation (e.g., 5!)
 *   Child 2: Fibonacci sequence generation (first 8 numbers)
 *   Child 3: Prime number check (e.g., check 29)
 *   Child 4: Sum of first N natural numbers (e.g., N=20)
 *   Child 5: String reversal demonstration ("OPERATING SYSTEM")
 *
 * Compilation:
 *   gcc -Wall -O2 q28_fork_five_children.c -o q28_fork_five_children
 *
 * Execution:
 *   ./q28_fork_five_children
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

void task_child1() {
    printf("[Child 1 PID: %d, Parent: %d] TASK: Factorial Calculation\n", getpid(), getppid());
    int n = 6;
    long fact = 1;
    for (int i = 1; i <= n; i++) fact *= i;
    printf("  >> Result: Factorial of %d is %ld\n", n, fact);
    exit(0);
}

void task_child2() {
    printf("[Child 2 PID: %d, Parent: %d] TASK: Fibonacci Sequence\n", getpid(), getppid());
    int n = 8;
    int a = 0, b = 1;
    printf("  >> Result: First %d Fibonacci numbers: %d %d ", n, a, b);
    for (int i = 2; i < n; i++) {
        int c = a + b;
        printf("%d ", c);
        a = b;
        b = c;
    }
    printf("\n");
    exit(0);
}

void task_child3() {
    printf("[Child 3 PID: %d, Parent: %d] TASK: Prime Number Check\n", getpid(), getppid());
    int num = 29;
    int is_prime = 1;
    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) { is_prime = 0; break; }
    }
    printf("  >> Result: %d is %s\n", num, is_prime ? "PRIME" : "COMPOSITE");
    exit(0);
}

void task_child4() {
    printf("[Child 4 PID: %d, Parent: %d] TASK: Sum of First 20 Natural Numbers\n", getpid(), getppid());
    int n = 20;
    int sum = n * (n + 1) / 2;
    printf("  >> Result: Sum(1 to %d) = %d\n", n, sum);
    exit(0);
}

void task_child5() {
    printf("[Child 5 PID: %d, Parent: %d] TASK: String Reversal\n", getpid(), getppid());
    char str[] = "OPERATING SYSTEM";
    int len = strlen(str);
    char rev[32];
    for (int i = 0; i < len; i++) {
        rev[i] = str[len - 1 - i];
    }
    rev[len] = '\0';
    printf("  >> Result: Original=\"%s\" | Reversed=\"%s\"\n", str, rev);
    exit(0);
}

int main() {
    printf("============================================================\n");
    printf(" Q28: fork() Five Child Processes with Distinct Operations  \n");
    printf(" Main Parent PID: %d\n", getpid());
    printf("============================================================\n");

    void (*tasks[])() = {task_child1, task_child2, task_child3, task_child4, task_child5};

    for (int i = 0; i < 5; i++) {
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork failed");
            exit(EXIT_FAILURE);
        } else if (pid == 0) {
            tasks[i]();
        }
    }

    // Parent waits for all 5 children
    for (int i = 0; i < 5; i++) {
        int status;
        pid_t cpid = wait(&status);
        printf("[Main Parent] Child with PID %d has finished.\n", cpid);
    }

    printf("\nAll five child processes have successfully completed their distinct tasks!\n");
    return 0;
}
