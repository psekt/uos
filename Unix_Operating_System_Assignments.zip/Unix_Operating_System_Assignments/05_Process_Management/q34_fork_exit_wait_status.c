/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 34: Create a program that demonstrates exit() combined with wait()
 *              and fork() (showing how children terminate and how parents
 *              collect status).
 *
 * Status inspection macros demonstrated:
 *   WIFEXITED(status)   - True if child terminated normally
 *   WEXITSTATUS(status) - Returns the exit status code passed to exit()
 *   WIFSIGNALED(status) - True if child was terminated by an unhandled signal
 *   WTERMSIG(status)    - Returns the signal number that caused termination
 *
 * Compilation:
 *   gcc -Wall -O2 q34_fork_exit_wait_status.c -o q34_fork_exit_wait_status
 *
 * Execution:
 *   ./q34_fork_exit_wait_status
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    printf("============================================================\n");
    printf(" Q34: Demonstration of exit(), wait(), and Status Macros    \n");
    printf("============================================================\n");

    // Scenario 1: Child terminates normally with exit code 77
    pid_t c1 = fork();
    if (c1 == 0) {
        printf("[Child 1 PID: %d] Doing work and terminating with exit(77)...\n", getpid());
        exit(77);
    }

    // Scenario 2: Child terminates normally with exit code 0
    pid_t c2 = fork();
    if (c2 == 0) {
        printf("[Child 2 PID: %d] Doing work and terminating with exit(0)...\n", getpid());
        exit(0);
    }

    // Scenario 3: Child terminates with exit code 123
    pid_t c3 = fork();
    if (c3 == 0) {
        printf("[Child 3 PID: %d] Doing work and terminating with exit(123)...\n", getpid());
        exit(123);
    }

    // Parent collects status for each child
    for (int i = 0; i < 3; i++) {
        int status;
        pid_t dead_child = wait(&status);

        printf("\n[Parent] Harvested termination of Child PID: %d\n", dead_child);
        if (WIFEXITED(status)) {
            printf("  >> Status: NORMAL TERMINATION via exit()\n");
            printf("  >> Exit Code Collected: %d\n", WEXITSTATUS(status));
        } else if (WIFSIGNALED(status)) {
            printf("  >> Status: ABNORMAL TERMINATION via Signal: %d\n", WTERMSIG(status));
        }
    }

    printf("\nStatus collection using exit() and wait() completed successfully.\n");
    return 0;
}
