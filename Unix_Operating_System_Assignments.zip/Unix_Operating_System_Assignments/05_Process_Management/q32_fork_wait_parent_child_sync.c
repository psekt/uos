/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 32: Demonstrate the use of wait() with fork() by writing a program
 *              that shows parent-child synchronization.
 *
 * Concept:
 *   Parent process pauses execution until child process completes its task,
 *   demonstrating deterministic ordering and synchronization.
 *
 * Compilation:
 *   gcc -Wall -O2 q32_fork_wait_parent_child_sync.c -o q32_fork_wait_parent_child_sync
 *
 * Execution:
 *   ./q32_fork_wait_parent_child_sync
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    printf("============================================================\n");
    printf(" Q32: Parent-Child Synchronization Using wait() and fork()   \n");
    printf(" Parent PID: %d\n", getpid());
    printf("============================================================\n");

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {
        // Child Process
        printf("[Child PID: %d] Started doing intensive work...\n", getpid());
        for (int i = 1; i <= 3; i++) {
            printf("  [Child] Working step %d / 3...\n", i);
            sleep(1);
        }
        printf("[Child PID: %d] Task completed! Exiting with status 42.\n", getpid());
        exit(42);
    } else {
        // Parent Process
        printf("[Parent PID: %d] Child process %d created. Parent now calling wait()...\n", getpid(), pid);

        int status;
        pid_t terminated_child = wait(&status);

        printf("\n[Parent PID: %d] Child process %d has finished!\n", getpid(), terminated_child);
        if (WIFEXITED(status)) {
            printf("  >> Normal termination detected.\n");
            printf("  >> Child exit status code = %d\n", WEXITSTATUS(status));
        }

        printf("[Parent] Synchronization complete: Parent safely proceeds to finish.\n");
    }

    return 0;
}
