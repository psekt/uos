/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 30: Write a program that launches an application using the
 *              fork() system call.
 *
 * Compilation:
 *   gcc -Wall -O2 q30_fork_launch_app.c -o q30_fork_launch_app
 *
 * Execution:
 *   ./q30_fork_launch_app [command]
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
    printf("============================================================\n");
    printf(" Q30: Launch External Application Using fork() & execvp()   \n");
    printf("============================================================\n");

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork error");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {
        // Child: Execute external program
        printf("[Child PID: %d] Executing application...\n", getpid());

        if (argc > 1) {
            execvp(argv[1], &argv[1]);
        } else {
            // Default: launch 'date' or 'ls'
            char *args[] = {"date", NULL};
            printf("[Child] Launching default application: %s\n", args[0]);
            execvp(args[0], args);
        }

        // If execvp returns, an error occurred
        perror("[Child] execvp failed");
        exit(EXIT_FAILURE);
    } else {
        // Parent: Waits for child to finish
        int status;
        printf("[Parent PID: %d] Waiting for child process (PID: %d) to finish...\n\n", getpid(), pid);
        wait(&status);

        if (WIFEXITED(status)) {
            printf("\n[Parent] Child process terminated normally with exit code: %d\n", WEXITSTATUS(status));
        } else {
            printf("\n[Parent] Child process terminated abnormally.\n");
        }
    }

    return 0;
}
