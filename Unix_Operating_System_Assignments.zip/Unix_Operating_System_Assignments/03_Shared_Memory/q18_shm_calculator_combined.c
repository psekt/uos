/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 18: Shared memory calculator: One process writes two operands and an
 *              operator into shared memory. Another process reads the request,
 *              performs the calculation, and writes back the result.
 *              [Combined Automated Demo]
 *
 * Compilation:
 *   gcc -Wall -O2 q18_shm_calculator_combined.c -o q18_shm_calculator_combined
 *
 * Execution:
 *   ./q18_shm_calculator_combined
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define CALC_KEY 0x1899

struct calc_packet {
    int status; // 0=idle, 1=req, 2=res, 3=done
    double op1, op2;
    char op;
    double result;
};

int main() {
    int shmid = shmget(CALC_KEY, sizeof(struct calc_packet), IPC_CREAT | 0666);
    if (shmid < 0) {
        perror("shmget failed");
        exit(EXIT_FAILURE);
    }

    struct calc_packet *pkt = (struct calc_packet*)shmat(shmid, NULL, 0);
    pkt->status = 0;

    printf("============================================================\n");
    printf(" Q18: Shared Memory Calculator Combined Demo                \n");
    printf("============================================================\n");

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork error");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent: Server
        while (1) {
            while (pkt->status != 1 && pkt->status != 3) usleep(20000);
            if (pkt->status == 3) break;

            printf("[Server] Calculating %.2f %c %.2f\n", pkt->op1, pkt->op, pkt->op2);
            switch(pkt->op) {
                case '+': pkt->result = pkt->op1 + pkt->op2; break;
                case '-': pkt->result = pkt->op1 - pkt->op2; break;
                case '*': pkt->result = pkt->op1 * pkt->op2; break;
                case '/': pkt->result = (pkt->op2 != 0) ? pkt->op1 / pkt->op2 : 0; break;
            }
            pkt->status = 2; // Done
        }

        wait(NULL);
        shmdt(pkt);
        shmctl(shmid, IPC_RMID, NULL);
        printf("[Server] Completed and cleaned up.\n");
    } else {
        // Child: Client
        struct { double a, b; char op; } tests[] = {
            {25.0, 5.0, '+'},
            {100.0, 45.5, '-'},
            {12.5, 4.0, '*'},
            {220.0, 7.0, '/'}
        };

        for (int i = 0; i < 4; i++) {
            pkt->op1 = tests[i].a;
            pkt->op2 = tests[i].b;
            pkt->op = tests[i].op;
            pkt->status = 1;

            while (pkt->status != 2) usleep(20000);
            printf("  [Client] Result of %.2f %c %.2f = %.4f\n",
                   tests[i].a, tests[i].op, tests[i].b, pkt->result);
            usleep(100000);
        }

        pkt->status = 3; // Finished
        shmdt(pkt);
        exit(EXIT_SUCCESS);
    }

    return 0;
}
