/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 7: Write a program using shared memory (shmget, shmat, shmdt) where
 *             the first process writes a string and the second process reads it.
 *             [WRITER PROCESS]
 *
 * Compilation:
 *   gcc -Wall -O2 q07_shm_writer.c -o q07_shm_writer
 *
 * Execution:
 *   Terminal 1: ./q07_shm_writer
 *   Terminal 2: ./q07_shm_reader
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_KEY 0x1007
#define SHM_SIZE 1024

int main() {
    int shmid = shmget(SHM_KEY, SHM_SIZE, IPC_CREAT | 0666);
    if (shmid < 0) {
        perror("shmget failed");
        exit(EXIT_FAILURE);
    }

    // Attach to shared memory
    char *str = (char*)shmat(shmid, NULL, 0);
    if (str == (char*)-1) {
        perror("shmat failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q07: Shared Memory - Writer Process                        \n");
    printf(" Shared Memory ID: %d | Key: 0x%X\n", shmid, SHM_KEY);
    printf("============================================================\n");

    printf("Enter string to write into shared memory: ");
    if (fgets(str, SHM_SIZE, stdin) == NULL) {
        strcpy(str, "Hello from Shared Memory Writer!\n");
    }
    str[strcspn(str, "\r\n")] = '\0';

    printf("[Writer] Successfully wrote: \"%s\"\n", str);
    printf("[Writer] Detaching from shared memory.\n");
    printf("Run './q07_shm_reader' to read this string.\n");

    shmdt(str);
    return 0;
}
