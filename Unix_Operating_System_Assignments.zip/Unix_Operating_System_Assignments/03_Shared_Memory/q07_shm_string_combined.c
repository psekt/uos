/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 7: Write a program using shared memory (shmget, shmat, shmdt) where
 *             the first process writes a string and the second process reads it.
 *             [Combined Fork Demo]
 *
 * Compilation:
 *   gcc -Wall -O2 q07_shm_string_combined.c -o q07_shm_string_combined
 *
 * Execution:
 *   ./q07_shm_string_combined
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define SHM_KEY 0x1077
#define SHM_SIZE 512

struct shm_data {
    int written; // flag for synchronization
    char text[SHM_SIZE];
};

int main() {
    int shmid = shmget(SHM_KEY, sizeof(struct shm_data), IPC_CREAT | 0666);
    if (shmid < 0) {
        perror("shmget failed");
        exit(EXIT_FAILURE);
    }

    struct shm_data *data = (struct shm_data*)shmat(shmid, NULL, 0);
    data->written = 0;

    printf("============================================================\n");
    printf(" Q07: Shared Memory String Write & Read Combined Demo       \n");
    printf("============================================================\n");

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent: Writer
        sleep(1);
        const char *sample = "Unix Shared Memory IPC Demonstration (Parent to Child)";
        strcpy(data->text, sample);
        data->written = 1;
        printf("[Parent Writer] Wrote to shared memory: \"%s\"\n", data->text);

        wait(NULL);
        shmdt(data);
        shmctl(shmid, IPC_RMID, NULL);
        printf("[Parent Writer] Cleaned up shared memory.\n");
    } else {
        // Child: Reader
        printf("[Child Reader] Waiting for writer to write data...\n");
        while (data->written == 0) {
            usleep(100000); // Poll flag
        }

        printf("[Child Reader] Read from shared memory: \"%s\"\n", data->text);
        shmdt(data);
        exit(EXIT_SUCCESS);
    }

    return 0;
}
