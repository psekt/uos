/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 18: Shared memory calculator: One process writes two operands and an
 *              operator into shared memory. Another process reads the request,
 *              performs the calculation, and writes back the result.
 *              [CALCULATOR CLIENT]
 *
 * Compilation:
 *   gcc -Wall -O2 q18_shm_calculator_client.c -o q18_shm_calculator_client
 *
 * Execution:
 *   Terminal 1: ./q18_shm_calculator_server
 *   Terminal 2: ./q18_shm_calculator_client
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define CALC_KEY 0x1818

struct calc_packet {
    int status;
    double op1;
    double op2;
    char op;
    double result;
    int error_flag;
};

int main() {
    int shmid = shmget(CALC_KEY, sizeof(struct calc_packet), 0666);
    if (shmid < 0) {
        printf("Error: Calculator server is not running. Please start it first!\n");
        exit(EXIT_FAILURE);
    }

    struct calc_packet *pkt = (struct calc_packet*)shmat(shmid, NULL, 0);

    printf("============================================================\n");
    printf(" Q18: Shared Memory Calculator - Client Process             \n");
    printf(" Supported operators: +  -  *  /  (type 'q' as op to quit)  \n");
    printf("============================================================\n");

    while (1) {
        double a, b;
        char op;

        printf("\nEnter first operand: ");
        if (scanf("%lf", &a) != 1) break;

        printf("Enter operator (+, -, *, /) or 'q' to quit: ");
        scanf(" %c", &op);

        if (op == 'q' || op == 'Q') {
            pkt->status = -1; // Instruct server to shut down
            printf("Exiting client.\n");
            break;
        }

        printf("Enter second operand: ");
        if (scanf("%lf", &b) != 1) break;

        // Write request to shared memory
        pkt->op1 = a;
        pkt->op2 = b;
        pkt->op = op;
        pkt->status = 1; // Mark request ready for server

        printf("[Client] Request submitted (%.2f %c %.2f). Waiting for server...\n", a, op, b);

        // Wait for server to set status to 2
        while (pkt->status != 2) {
            usleep(50000);
        }

        // Display results
        if (pkt->error_flag == 1) {
            printf(">> ERROR: Division by Zero!\n");
        } else if (pkt->error_flag == 2) {
            printf(">> ERROR: Unsupported operator '%c'!\n", op);
        } else {
            printf(">> RESULT: %.2f %c %.2f = %.4f\n", a, op, b, pkt->result);
        }

        pkt->status = 0; // Reset status
    }

    shmdt(pkt);
    return 0;
}
