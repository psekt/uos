/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 9: Write a program where one process writes characters A-Z into
 *             shared memory, and another process writes the same data into a file.
 *
 * Compilation:
 *   gcc -Wall -O2 q09_shm_chars_to_file.c -o q09_shm_chars_to_file
 *
 * Execution:
 *   ./q09_shm_chars_to_file [output_filename]
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define SHM_KEY 0x1009
#define OUT_FILE "q09_output_az.txt"

struct alphabet_shm {
    int ready; // 0 = not ready, 1 = ready
    char chars[27];
};

int main(int argc, char *argv[]) {
    const char *target_file = (argc > 1) ? argv[1] : OUT_FILE;

    int shmid = shmget(SHM_KEY, sizeof(struct alphabet_shm), IPC_CREAT | 0666);
    if (shmid < 0) {
        perror("shmget failed");
        exit(EXIT_FAILURE);
    }

    struct alphabet_shm *data = (struct alphabet_shm*)shmat(shmid, NULL, 0);
    data->ready = 0;

    printf("============================================================\n");
    printf(" Q09: Shared Memory A-Z Writer to File                      \n");
    printf(" Output File Target: %s\n", target_file);
    printf("============================================================\n");

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Process 1 (Parent): Writes 'A' through 'Z'
        printf("[Process 1 (Writer PID: %d)] Populating characters 'A' through 'Z'...\n", getpid());
        for (int i = 0; i < 26; i++) {
            data->chars[i] = (char)('A' + i);
        }
        data->chars[26] = '\0';
        data->ready = 1;
        printf("[Process 1] Written string \"%s\" to shared memory.\n", data->chars);

        wait(NULL); // Wait for child to complete file write
        shmdt(data);
        shmctl(shmid, IPC_RMID, NULL);
        printf("[Process 1] Shared memory released. Workflow finished.\n");
    } else {
        // Process 2 (Child): Reads from shm and writes to file
        printf("[Process 2 (File Writer PID: %d)] Waiting for data in shared memory...\n", getpid());
        while (data->ready == 0) {
            usleep(50000);
        }

        FILE *fp = fopen(target_file, "w");
        if (!fp) {
            perror("[Process 2] fopen error");
            shmdt(data);
            exit(EXIT_FAILURE);
        }

        fprintf(fp, "%s\n", data->chars);
        fclose(fp);

        printf("[Process 2] Successfully read characters from shared memory and wrote to '%s':\n", target_file);
        printf("  >> Contents in file: \"%s\"\n", data->chars);

        shmdt(data);
        exit(EXIT_SUCCESS);
    }

    return 0;
}
