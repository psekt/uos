/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 8: Implement a shared memory program in which:
 *             a. Process 1 takes numbers as input from the user,
 *             b. Process 2 sorts the numbers,
 *             c. Process 3 displays the sorted list.
 *
 * Compilation:
 *   gcc -Wall -O2 q08_shm_three_proc_sort.c -o q08_shm_three_proc_sort
 *
 * Execution:
 *   ./q08_shm_three_proc_sort
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define MAX_NUMS 50
#define SHM_KEY 0x1008

struct shared_sort_data {
    int count;
    int numbers[MAX_NUMS];
    int stage; // 0 = empty, 1 = input done, 2 = sort done, 3 = display done
};

int main() {
    int shmid = shmget(SHM_KEY, sizeof(struct shared_sort_data), IPC_CREAT | 0666);
    if (shmid < 0) {
        perror("shmget failed");
        exit(EXIT_FAILURE);
    }

    struct shared_sort_data *shm = (struct shared_sort_data*)shmat(shmid, NULL, 0);
    shm->stage = 0;

    printf("============================================================\n");
    printf(" Q08: 3-Process Shared Memory Sorting                       \n");
    printf(" Process 1: User Input -> Process 2: Sort -> Process 3: Show\n");
    printf("============================================================\n");

    // Process 1: Parent takes input
    printf("[Process 1 (PID: %d)] Enter number of elements (e.g. 5): ", getpid());
    int n;
    if (scanf("%d", &n) != 1 || n <= 0 || n > MAX_NUMS) {
        n = 5;
        printf("Defaulting to %d elements.\n", n);
    }
    shm->count = n;

    printf("[Process 1] Enter %d integer numbers:\n", n);
    for (int i = 0; i < n; i++) {
        printf("  Element [%d]: ", i);
        if (scanf("%d", &shm->numbers[i]) != 1) {
            shm->numbers[i] = (n - i) * 7; // demo fallback
        }
    }
    printf("[Process 1] Input stored in shared memory. Signalling Process 2...\n");
    shm->stage = 1; // Input done

    // Fork Process 2 (Sorter)
    pid_t p2 = fork();
    if (p2 == 0) {
        // Child: Process 2
        struct shared_sort_data *s2 = (struct shared_sort_data*)shmat(shmid, NULL, 0);
        while (s2->stage != 1) usleep(50000);

        printf("\n[Process 2 (PID: %d)] Sorting %d numbers using Bubble Sort...\n", getpid(), s2->count);
        for (int i = 0; i < s2->count - 1; i++) {
            for (int j = 0; j < s2->count - i - 1; j++) {
                if (s2->numbers[j] > s2->numbers[j + 1]) {
                    int tmp = s2->numbers[j];
                    s2->numbers[j] = s2->numbers[j + 1];
                    s2->numbers[j + 1] = tmp;
                }
            }
        }
        printf("[Process 2] Sorting complete. Signalling Process 3...\n");
        s2->stage = 2; // Sort done
        shmdt(s2);
        exit(EXIT_SUCCESS);
    }

    // Fork Process 3 (Displayer)
    pid_t p3 = fork();
    if (p3 == 0) {
        // Child: Process 3
        struct shared_sort_data *s3 = (struct shared_sort_data*)shmat(shmid, NULL, 0);
        while (s3->stage != 2) usleep(50000);

        printf("\n[Process 3 (PID: %d)] Displaying Final Sorted Array:\n", getpid());
        printf("------------------------------------------------------------\n");
        printf("SORTED RESULT: ");
        for (int i = 0; i < s3->count; i++) {
            printf("%d ", s3->numbers[i]);
        }
        printf("\n------------------------------------------------------------\n");
        s3->stage = 3;
        shmdt(s3);
        exit(EXIT_SUCCESS);
    }

    // Wait for Process 2 and Process 3
    waitpid(p2, NULL, 0);
    waitpid(p3, NULL, 0);

    shmdt(shm);
    shmctl(shmid, IPC_RMID, NULL);
    printf("\n[Process 1] Shared memory cleaned up. All 3 processes completed.\n");
    return 0;
}
