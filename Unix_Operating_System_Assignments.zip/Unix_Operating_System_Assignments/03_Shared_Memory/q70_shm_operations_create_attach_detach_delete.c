/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 70: Create programs where different processes perform different
 *              shared-memory operations: create, delete, attach, detach
 *              (shmget, shmat, shmdt, shmctl).
 *
 * Concept: Complete demonstration of the 4 fundamental System V shared memory APIs.
 *
 * Compilation:
 *   gcc -Wall -O2 q70_shm_operations_create_attach_detach_delete.c -o q70_shm_operations_create_attach_detach_delete
 *
 * Execution:
 *   ./q70_shm_operations_create_attach_detach_delete
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define DEMO_SHM_KEY 0x7070
#define SEGMENT_SIZE 256

int main() {
    printf("============================================================\n");
    printf(" Q70: Demonstration of Shared Memory Operations:            \n");
    printf("      shmget (Create), shmat (Attach),                      \n");
    printf("      shmdt (Detach), shmctl (Delete)                       \n");
    printf("============================================================\n");

    // 1. OPERATION 1: shmget - CREATE
    printf("\n[Step 1: CREATE] Process %d calling shmget(IPC_CREAT | 0666)...\n", getpid());
    int shmid = shmget(DEMO_SHM_KEY, SEGMENT_SIZE, IPC_CREAT | 0666);
    if (shmid < 0) {
        perror("shmget failed");
        exit(EXIT_FAILURE);
    }
    printf("  >> Result: Segment created successfully. Shmid = %d\n", shmid);

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent Process: Attach, write, detach
        // 2. OPERATION 2: shmat - ATTACH
        printf("\n[Step 2: ATTACH (Parent PID %d)] Calling shmat()...\n", getpid());
        char *ptr = (char*)shmat(shmid, NULL, 0);
        if (ptr == (char*)-1) {
            perror("shmat failed");
            exit(EXIT_FAILURE);
        }
        printf("  >> Result: Segment attached at virtual memory address: %p\n", (void*)ptr);

        // Write data
        strcpy(ptr, "Shared Memory Operational Workflow Verification Test");
        printf("  >> Written message to memory: \"%s\"\n", ptr);

        // 3. OPERATION 3: shmdt - DETACH
        printf("\n[Step 3: DETACH (Parent PID %d)] Calling shmdt()...\n", getpid());
        if (shmdt(ptr) == -1) {
            perror("shmdt failed");
        } else {
            printf("  >> Result: Memory segment detached successfully from Parent.\n");
        }

        // Wait for child process to attach, read, and detach
        wait(NULL);

        // 4. OPERATION 4: shmctl - DELETE
        printf("\n[Step 4: DELETE (Parent PID %d)] Calling shmctl(IPC_RMID)...\n", getpid());
        if (shmctl(shmid, IPC_RMID, NULL) == -1) {
            perror("shmctl IPC_RMID failed");
        } else {
            printf("  >> Result: Shared memory segment %d removed from system.\n", shmid);
        }
        printf("\nAll 4 operations executed successfully!\n");
    } else {
        // Child Process: Attach, read, detach
        sleep(1);
        printf("\n[Child Process PID %d] Attaching to read shared segment...\n", getpid());
        char *c_ptr = (char*)shmat(shmid, NULL, 0);
        if (c_ptr == (char*)-1) {
            perror("[Child] shmat failed");
            exit(EXIT_FAILURE);
        }
        printf("  >> [Child] Attached at address: %p\n", (void*)c_ptr);
        printf("  >> [Child] Data read: \"%s\"\n", c_ptr);

        printf("  >> [Child] Detaching segment...\n");
        shmdt(c_ptr);
        printf("  >> [Child] Detached successfully. Exiting.\n");
        exit(EXIT_SUCCESS);
    }

    return 0;
}
