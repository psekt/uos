/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 20: Shared memory file transfer: Implement a program where one process
 *              reads data from a file and writes into shared memory in chunks,
 *              and another process reconstructs the file.
 *
 * Compilation:
 *   gcc -Wall -O2 q20_shm_file_transfer.c -o q20_shm_file_transfer
 *
 * Execution:
 *   ./q20_shm_file_transfer [src_file] [dest_file]
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define SHM_KEY 0x2020
#define CHUNK_SIZE 512

struct chunk_buffer {
    int status; // 0 = empty / ready for sender, 1 = data ready for receiver, -1 = EOF
    int bytes_count;
    char data[CHUNK_SIZE];
};

int main(int argc, char *argv[]) {
    const char *src_name = (argc > 1) ? argv[1] : "q20_sample_source.txt";
    const char *dst_name = (argc > 2) ? argv[2] : "q20_reconstructed_output.txt";

    // Create a demo file if source doesn't exist
    FILE *chk = fopen(src_name, "r");
    if (!chk) {
        FILE *tf = fopen(src_name, "w");
        if (tf) {
            for (int i = 1; i <= 25; i++) {
                fprintf(tf, "Chunk transfer test line #%d: Unix Operating System Shared Memory File IPC.\n", i);
            }
            fclose(tf);
            printf("[Setup] Generated sample file '%s'\n", src_name);
        }
    } else {
        fclose(chk);
    }

    int shmid = shmget(SHM_KEY, sizeof(struct chunk_buffer), IPC_CREAT | 0666);
    if (shmid < 0) {
        perror("shmget failed");
        exit(EXIT_FAILURE);
    }

    struct chunk_buffer *buf = (struct chunk_buffer*)shmat(shmid, NULL, 0);
    buf->status = 0;

    printf("============================================================\n");
    printf(" Q20: Shared Memory File Transfer in Chunks                 \n");
    printf(" Source: %s  ->  Destination: %s\n", src_name, dst_name);
    printf("============================================================\n");

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent: Sender (reads file and writes chunks to shared memory)
        FILE *src = fopen(src_name, "rb");
        if (!src) {
            perror("[Sender] Failed to open source file");
            buf->status = -1;
            wait(NULL);
            exit(EXIT_FAILURE);
        }

        size_t total_sent = 0;
        int chunk_idx = 0;

        while (!feof(src)) {
            while (buf->status != 0) usleep(5000); // Wait until receiver consumes previous chunk

            size_t n = fread(buf->data, 1, CHUNK_SIZE, src);
            if (n > 0) {
                chunk_idx++;
                buf->bytes_count = (int)n;
                buf->status = 1; // Mark data available
                total_sent += n;
                printf("[Sender] Transferred Chunk #%d (%zu bytes)\n", chunk_idx, n);
            }
        }

        // Wait until receiver consumes the last chunk
        while (buf->status != 0) usleep(5000);
        buf->status = -1; // Send EOF signal
        fclose(src);

        printf("[Sender] File read complete. Total bytes sent: %zu. Waiting for receiver...\n", total_sent);
        wait(NULL);

        shmdt(buf);
        shmctl(shmid, IPC_RMID, NULL);
        printf("[Sender] Shared memory removed. File transfer finished successfully.\n");
    } else {
        // Child: Receiver (reads chunks from shared memory and writes to destination file)
        FILE *dst = fopen(dst_name, "wb");
        if (!dst) {
            perror("[Receiver] Failed to open destination file");
            exit(EXIT_FAILURE);
        }

        size_t total_recv = 0;
        int chunk_idx = 0;

        while (1) {
            while (buf->status == 0) usleep(5000); // Wait for sender to place data

            if (buf->status == -1) {
                // EOF reached
                break;
            }

            if (buf->status == 1) {
                chunk_idx++;
                fwrite(buf->data, 1, buf->bytes_count, dst);
                total_recv += buf->bytes_count;
                printf("  [Receiver] Reconstructed Chunk #%d (%d bytes)\n", chunk_idx, buf->bytes_count);
                buf->status = 0; // Mark buffer as empty / consumed
            }
        }

        fclose(dst);
        shmdt(buf);
        printf("  [Receiver] Total received: %zu bytes written to '%s'.\n", total_recv, dst_name);
        exit(EXIT_SUCCESS);
    }

    return 0;
}
