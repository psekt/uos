/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 7: Write a program using shared memory (shmget, shmat, shmdt) where
 *             the first process writes a string and the second process reads it.
 *             [READER PROCESS]
 *
 * Compilation:
 *   gcc -Wall -O2 q07_shm_reader.c -o q07_shm_reader
 *
 * Execution:
 *   Terminal 1: ./q07_shm_writer
 *   Terminal 2: ./q07_shm_reader
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_KEY 0x1007
#define SHM_SIZE 1024

int main() {
    int shmid = shmget(SHM_KEY, SHM_SIZE, 0666);
    if (shmid < 0) {
        perror("shmget failed (Run writer first)");
        exit(EXIT_FAILURE);
    }

    char *str = (char*)shmat(shmid, NULL, 0);
    if (str == (char*)-1) {
        perror("shmat failed");
        exit(EXIT_FAILURE);
    }

    printf("============================================================\n");
    printf(" Q07: Shared Memory - Reader Process                        \n");
    printf("============================================================\n");

    printf("[Reader] Data read from shared memory:\n");
    printf(">> \"%s\" <<\n", str);

    // Detach
    shmdt(str);

    // Clean up shared memory segment
    shmctl(shmid, IPC_RMID, NULL);
    printf("[Reader] Shared memory segment detached and destroyed.\n");

    return 0;
}
