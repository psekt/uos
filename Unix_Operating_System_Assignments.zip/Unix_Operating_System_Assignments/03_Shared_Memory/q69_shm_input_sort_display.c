/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 69: Write a shared-memory IPC program where: Process 1 takes numbers
 *              from the user and writes to shared memory, Process 2 sorts the
 *              numbers and writes them back, and Process 3 displays the sorted data.
 *
 * Compilation:
 *   gcc -Wall -O2 q69_shm_input_sort_display.c -o q69_shm_input_sort_display
 *
 * Execution:
 *   ./q69_shm_input_sort_display
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define SHM_KEY 0x6969
#define CAPACITY 30

struct sort_ipc_data {
    int state; // 0 = empty, 1 = input ready, 2 = sort ready, 3 = displayed
    int count;
    int array[CAPACITY];
};

int main() {
    int shmid = shmget(SHM_KEY, sizeof(struct sort_ipc_data), IPC_CREAT | 0666);
    if (shmid < 0) {
        perror("shmget failed");
        exit(EXIT_FAILURE);
    }

    struct sort_ipc_data *data = (struct sort_ipc_data*)shmat(shmid, NULL, 0);
    data->state = 0;

    printf("============================================================\n");
    printf(" Q69: Shared Memory: P1 Input -> P2 Sort -> P3 Display      \n");
    printf("============================================================\n");

    // Process 1 (Parent): User Input
    int n;
    printf("[Process 1 (PID: %d)] How many numbers do you want to input? (1-%d): ", getpid(), CAPACITY);
    if (scanf("%d", &n) != 1 || n <= 0 || n > CAPACITY) {
        n = 6;
        printf("Defaulting to %d numbers.\n", n);
    }
    data->count = n;

    printf("[Process 1] Enter %d integer values:\n", n);
    for (int i = 0; i < n; i++) {
        printf("  Value [%d]: ", i + 1);
        if (scanf("%d", &data->array[i]) != 1) {
            data->array[i] = (n - i) * 11;
        }
    }
    data->state = 1; // Signal P2
    printf("[Process 1] Input phase finished. Signalling Process 2.\n");

    // Fork Process 2 (Sorter)
    pid_t p2 = fork();
    if (p2 == 0) {
        struct sort_ipc_data *d2 = (struct sort_ipc_data*)shmat(shmid, NULL, 0);
        while (d2->state != 1) usleep(20000);

        printf("\n[Process 2 (PID: %d)] Sorting numbers in shared memory...\n", getpid());
        // Insertion sort
        for (int i = 1; i < d2->count; i++) {
            int key = d2->array[i];
            int j = i - 1;
            while (j >= 0 && d2->array[j] > key) {
                d2->array[j + 1] = d2->array[j];
                j = j - 1;
            }
            d2->array[j + 1] = key;
        }

        d2->state = 2; // Signal P3
        printf("[Process 2] Sorting complete. Numbers written back to shared memory.\n");
        shmdt(d2);
        exit(EXIT_SUCCESS);
    }

    // Fork Process 3 (Displayer)
    pid_t p3 = fork();
    if (p3 == 0) {
        struct sort_ipc_data *d3 = (struct sort_ipc_data*)shmat(shmid, NULL, 0);
        while (d3->state != 2) usleep(20000);

        printf("\n[Process 3 (PID: %d)] Displaying Sorted Data:\n", getpid());
        printf("============================================================\n");
        printf(" SORTED LIST: ");
        for (int i = 0; i < d3->count; i++) {
            printf("%d ", d3->array[i]);
        }
        printf("\n============================================================\n");

        d3->state = 3;
        shmdt(d3);
        exit(EXIT_SUCCESS);
    }

    waitpid(p2, NULL, 0);
    waitpid(p3, NULL, 0);

    shmdt(data);
    shmctl(shmid, IPC_RMID, NULL);
    printf("[Process 1] All 3 processes completed. Shared memory cleaned up.\n");

    return 0;
}
