/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 67: Implement IPC using shared memory (shmget, shmat, shmdt) where
 *              one process sends A-Z or 1-100 (from user input) and another
 *              process receives it.
 *
 * Compilation:
 *   gcc -Wall -O2 q67_shm_send_az_or_numbers.c -o q67_shm_send_az_or_numbers
 *
 * Execution:
 *   ./q67_shm_send_az_or_numbers
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define SHM_KEY 0x6767

struct data_packet {
    int ready; // 0 = empty, 1 = ready
    int mode;  // 1 = A-Z, 2 = 1-100
    char payload[1024];
};

int main() {
    int shmid = shmget(SHM_KEY, sizeof(struct data_packet), IPC_CREAT | 0666);
    if (shmid < 0) {
        perror("shmget failed");
        exit(EXIT_FAILURE);
    }

    struct data_packet *pkt = (struct data_packet*)shmat(shmid, NULL, 0);
    pkt->ready = 0;

    printf("============================================================\n");
    printf(" Q67: Shared Memory IPC - Send A-Z or 1-100                 \n");
    printf(" 1. Send Alphabet characters A-Z\n");
    printf(" 2. Send Numbers 1 to 100\n");
    printf("============================================================\n");

    int choice;
    printf("Select option (1 or 2): ");
    if (scanf("%d", &choice) != 1 || (choice != 1 && choice != 2)) {
        choice = 1;
        printf("Defaulting to option 1 (A-Z).\n");
    }

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Parent: Sender
        pkt->mode = choice;
        pkt->payload[0] = '\0';

        if (choice == 1) {
            printf("[Sender Process (PID %d)] Generating A-Z...\n", getpid());
            for (int i = 0; i < 26; i++) {
                char c[2] = {(char)('A' + i), '\0'};
                strcat(pkt->payload, c);
                if (i < 25) strcat(pkt->payload, " ");
            }
        } else {
            printf("[Sender Process (PID %d)] Generating 1 to 100...\n", getpid());
            for (int i = 1; i <= 100; i++) {
                char num_buf[16];
                snprintf(num_buf, sizeof(num_buf), "%d ", i);
                strcat(pkt->payload, num_buf);
            }
        }

        pkt->ready = 1;
        printf("[Sender] Placed data into shared memory. Waiting for receiver...\n");

        wait(NULL);
        shmdt(pkt);
        shmctl(shmid, IPC_RMID, NULL);
        printf("[Sender] IPC completed and shared memory cleaned up.\n");
    } else {
        // Child: Receiver
        printf("[Receiver Process (PID %d)] Waiting for data in shared memory...\n", getpid());
        while (pkt->ready == 0) {
            usleep(20000);
        }

        printf("\n==================== RECEIVED DATA ====================\n");
        printf("Mode: %s\n", (pkt->mode == 1) ? "Alphabet (A-Z)" : "Numbers (1-100)");
        printf("Content:\n%s\n", pkt->payload);
        printf("=======================================================\n");

        shmdt(pkt);
        exit(EXIT_SUCCESS);
    }

    return 0;
}
