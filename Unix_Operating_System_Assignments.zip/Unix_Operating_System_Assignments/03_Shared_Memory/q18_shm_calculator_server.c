/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 18: Shared memory calculator: One process writes two operands and an
 *              operator into shared memory. Another process reads the request,
 *              performs the calculation, and writes back the result.
 *              [CALCULATOR SERVER]
 *
 * Compilation:
 *   gcc -Wall -O2 q18_shm_calculator_server.c -o q18_shm_calculator_server
 *
 * Execution:
 *   Terminal 1: ./q18_shm_calculator_server
 *   Terminal 2: ./q18_shm_calculator_client
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define CALC_KEY 0x1818

// Status values:
// 0 = Idle / Initialized
// 1 = Client Request Pending (Server needs to compute)
// 2 = Calculation Complete (Client can read result)
// -1 = Terminate server

struct calc_packet {
    int status;
    double op1;
    double op2;
    char op;
    double result;
    int error_flag; // 1 = division by zero, 2 = invalid operator
};

int main() {
    int shmid = shmget(CALC_KEY, sizeof(struct calc_packet), IPC_CREAT | 0666);
    if (shmid < 0) {
        perror("shmget failed");
        exit(EXIT_FAILURE);
    }

    struct calc_packet *pkt = (struct calc_packet*)shmat(shmid, NULL, 0);
    pkt->status = 0;

    printf("============================================================\n");
    printf(" Q18: Shared Memory Calculator - Server Process             \n");
    printf(" Waiting for calculation requests from client...            \n");
    printf("============================================================\n");

    while (1) {
        while (pkt->status != 1 && pkt->status != -1) {
            usleep(50000);
        }

        if (pkt->status == -1) {
            printf("[Server] Shutdown command received. Exiting.\n");
            break;
        }

        printf("[Server] Request received: %.2f %c %.2f\n", pkt->op1, pkt->op, pkt->op2);
        pkt->error_flag = 0;

        switch (pkt->op) {
            case '+': pkt->result = pkt->op1 + pkt->op2; break;
            case '-': pkt->result = pkt->op1 - pkt->op2; break;
            case '*': pkt->result = pkt->op1 * pkt->op2; break;
            case '/':
                if (pkt->op2 == 0) {
                    pkt->error_flag = 1;
                    pkt->result = 0;
                } else {
                    pkt->result = pkt->op1 / pkt->op2;
                }
                break;
            default:
                pkt->error_flag = 2;
                pkt->result = 0;
        }

        if (pkt->error_flag == 1) {
            printf("[Server] Error: Division by zero!\n");
        } else if (pkt->error_flag == 2) {
            printf("[Server] Error: Unsupported operator '%c'!\n", pkt->op);
        } else {
            printf("[Server] Computed Result: %.4f\n", pkt->result);
        }

        pkt->status = 2; // Result ready for client
    }

    shmdt(pkt);
    shmctl(shmid, IPC_RMID, NULL);
    return 0;
}
