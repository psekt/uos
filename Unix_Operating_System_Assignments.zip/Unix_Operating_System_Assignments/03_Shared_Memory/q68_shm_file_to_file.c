/*
 * Assignment: Unix Operating System - External Practical Exam
 * Question 68: Implement IPC via shared memory where one process reads A-Z or
 *              1-100 from a file and writes it into shared memory, and another
 *              process reads from shared memory and writes to a different file
 *              (same directory, different filename).
 *
 * Compilation:
 *   gcc -Wall -O2 q68_shm_file_to_file.c -o q68_shm_file_to_file
 *
 * Execution:
 *   ./q68_shm_file_to_file
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define SHM_KEY 0x6868
#define IN_FILE "q68_source_input.txt"
#define OUT_FILE "q68_destination_output.txt"

struct file_shm {
    int ready;
    char buffer[2048];
};

int main() {
    // Step 0: Ensure source file exists with A-Z and 1-100 sample data
    FILE *in_init = fopen(IN_FILE, "w");
    if (in_init) {
        fprintf(in_init, "ALPHABETS A-Z:\n");
        for (char c = 'A'; c <= 'Z'; c++) fprintf(in_init, "%c ", c);
        fprintf(in_init, "\n\nNUMBERS 1 TO 100:\n");
        for (int i = 1; i <= 100; i++) fprintf(in_init, "%d ", i);
        fprintf(in_init, "\n");
        fclose(in_init);
        printf("[Setup] Initialized source file: %s\n", IN_FILE);
    }

    int shmid = shmget(SHM_KEY, sizeof(struct file_shm), IPC_CREAT | 0666);
    if (shmid < 0) {
        perror("shmget failed");
        exit(EXIT_FAILURE);
    }

    struct file_shm *shm = (struct file_shm*)shmat(shmid, NULL, 0);
    shm->ready = 0;

    printf("============================================================\n");
    printf(" Q68: Shared Memory File-to-File Pipeline                   \n");
    printf(" %s -> Shared Memory -> %s\n", IN_FILE, OUT_FILE);
    printf("============================================================\n");

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork error");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        // Process 1 (Parent): Reads from input file and writes into shared memory
        printf("[Process 1 (PID: %d)] Reading '%s' into shared memory...\n", getpid(), IN_FILE);
        FILE *fin = fopen(IN_FILE, "r");
        if (!fin) {
            perror("fopen input error");
            shmdt(shm);
            exit(EXIT_FAILURE);
        }

        size_t n = fread(shm->buffer, 1, sizeof(shm->buffer) - 1, fin);
        shm->buffer[n] = '\0';
        fclose(fin);

        shm->ready = 1; // Signal child
        printf("[Process 1] Read %zu bytes into shared memory. Signalled Process 2.\n", n);

        wait(NULL); // Wait for child to finish writing output file
        shmdt(shm);
        shmctl(shmid, IPC_RMID, NULL);
        printf("[Process 1] Shared memory segment removed.\n");
    } else {
        // Process 2 (Child): Reads from shared memory and writes to destination file
        printf("[Process 2 (PID: %d)] Waiting for shared memory data...\n", getpid());
        while (shm->ready == 0) {
            usleep(20000);
        }

        printf("[Process 2] Writing shared memory data into '%s'...\n", OUT_FILE);
        FILE *fout = fopen(OUT_FILE, "w");
        if (!fout) {
            perror("fopen output error");
            shmdt(shm);
            exit(EXIT_FAILURE);
        }

        fputs(shm->buffer, fout);
        fclose(fout);

        printf("[Process 2] Successfully saved transferred content to '%s'.\n", OUT_FILE);
        shmdt(shm);
        exit(EXIT_SUCCESS);
    }

    return 0;
}
