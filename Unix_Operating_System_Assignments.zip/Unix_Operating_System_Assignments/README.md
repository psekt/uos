# Unix Operating System - External Practical Exam Assignment Repository
### TY (IT) - Comprehensive Practical Exam Solutions (Questions 1 to 87)

This repository contains complete, robust, well-documented, and error-handled programs for all 87 questions from the **Unix Operating System - Probable Assignment List for External Practical Exam**.

---

## 📁 Repository Structure & Concept-Based Organization

All programs are neatly organized into **10 concept-based folders**. File and folder names are descriptive and prefixed with their question number(s) for immediate identification:

```
Unix_Operating_System_Assignments/
├── 01_Pipes_and_FIFOs/
├── 02_Message_Queues/
├── 03_Shared_Memory/
├── 04_Process_Synchronization_and_Semaphores/
├── 05_Process_Management/
├── 06_Signals_and_Alarms/
├── 07_File_Subsystem_and_Locking/
├── 08_Threads_and_Multithreading/
├── 09_Network_and_Socket_Programming_Java/
├── 10_Shell_Scripts_and_Linux_Utilities/
├── Makefile
└── README.md
```

> **Language Specification Policy:**
> - **Core Unix System & IPC Programs:** Written in **C** using POSIX and System V APIs (`fork`, `vfork`, `pipe`, `mkfifo`, `shmget`, `semget`, `msgget`, `pthread`, `stat`, `lockf`, `flock`, etc.).
> - **Network & Socket Programs:** Written in **Java** (`java.net.*`, `java.io.*`, `java.util.concurrent.*`) featuring multithreading, concurrent server logic, datagram packets, and group chat systems. Companion C implementations are also provided where explicitly referenced.
> - **Shell Scripts & Utilities:** Written in standard POSIX **Bash** and **Python 3**.

---

## 📑 Complete Question-to-File Mapping Index (Q1 to Q87)

| Question # | Folder | Primary File(s) | Language | Topic / Problem Statement Description |
|:---:|:---|:---|:---:|:---|
| **Q01** | `01_Pipes_and_FIFOs` | `q01_pipe_file_transfer_parent_to_child.c` | C | Transfer file contents parent to child using unnamed pipe |
| **Q02** | `01_Pipes_and_FIFOs` | `q02_fifo_sender.c`<br>`q02_fifo_receiver.c`<br>`q02_named_pipe_fifo_combined_demo.c` | C | Named pipe (FIFO) one process sends text, another receives and displays |
| **Q03** | `01_Pipes_and_FIFOs` | `q03_pipe_filter_upper_to_lower.c` | C | Pipe filter converting text uppercase to lowercase before printing |
| **Q04** | `02_Message_Queues` | `q04_msgqueue_send_receive.c` | C | System V message queue send and receive between two processes |
| **Q05** | `02_Message_Queues` | `q05_msgqueue_chat_proc1.c`<br>`q05_msgqueue_chat_proc2.c`<br>`q05_msgqueue_chat_combined.c` | C | Two-process bidirectional chat application using message queues |
| **Q06** | `02_Message_Queues` | `q06_msgqueue_sum_sender.c`<br>`q06_msgqueue_sum_receiver.c`<br>`q06_msgqueue_sum_combined.c` | C | Send sequence of numbers via message queue; second process prints sum |
| **Q07** | `03_Shared_Memory` | `q07_shm_writer.c`<br>`q07_shm_reader.c`<br>`q07_shm_string_combined.c` | C | Shared memory (`shmget`, `shmat`, `shmdt`): P1 writes string, P2 reads |
| **Q08** | `03_Shared_Memory` | `q08_shm_three_proc_sort.c` | C | 3 processes: P1 user input, P2 sorts numbers, P3 displays sorted list |
| **Q09** | `03_Shared_Memory` | `q09_shm_chars_to_file.c` | C | P1 writes characters A-Z into shared memory; P2 writes data to file |
| **Q10** | `04_Process_Synchronization_and_Semaphores` | `q10_sem_even_odd_synchronization.c` | C | Semaphores synchronize 2 processes: one prints evens, other odds in order |
| **Q11** | `04_Process_Synchronization_and_Semaphores` | `q11_producer_consumer_shm_sem.c` | C | Classical Producer-Consumer problem using shared memory and semaphores |
| **Q12** | `04_Process_Synchronization_and_Semaphores` | `q12_reader_writer_sem.c` | C | Reader-Writer problem using semaphores to control mutual exclusion |
| **Q13** | `09_Network_and_Socket_Programming_Java` | `q13_TCPServerStringReverse.java`<br>`q13_TCPClientStringReverse.java`<br>`q13_tcp_reverse_server.c`<br>`q13_tcp_reverse_client.c` | Java & C | TCP client-server: Client sends string, Server replies with reversed string |
| **Q14** | `09_Network_and_Socket_Programming_Java` | `q14_UDPServerFactorial.java`<br>`q14_UDPClientFactorial.java`<br>`q14_udp_factorial_server.c`<br>`q14_udp_factorial_client.c` | Java & C | UDP client-server: Client sends number, Server responds with factorial |
| **Q15** | `09_Network_and_Socket_Programming_Java` | `q15_TCPEchoServerIterative.java`<br>`q15_TCPEchoServerConcurrent.java`<br>`q15_TCPEchoClient.java` | Java | TCP Echo Server (both iterative single-threaded & concurrent versions) |
| **Q16** | `02_Message_Queues` | `q16_msgqueue_job_scheduler_server.c`<br>`q16_msgqueue_job_scheduler_client.c` | C | Job scheduler via message queues (Factorial, Fibonacci, Prime check) |
| **Q17** | `02_Message_Queues` | `q17_msgqueue_priority_server.c`<br>`q17_msgqueue_priority_client.c` | C | Priority-based messaging: multiple clients send, server displays in priority |
| **Q18** | `03_Shared_Memory` | `q18_shm_calculator_server.c`<br>`q18_shm_calculator_client.c`<br>`q18_shm_calculator_combined.c` | C | Shared memory calculator: operands and operator written, result returned |
| **Q19** | `04_Process_Synchronization_and_Semaphores` | `q19_shm_sem_four_proc_sort.c` | C | 4-process shm sort: P1 writes array, P2 sorts, P3 median/mean, P4 displays |
| **Q20** | `03_Shared_Memory` | `q20_shm_file_transfer.c` | C | Shared memory file transfer in chunks; receiver reconstructs file |
| **Q21** | `04_Process_Synchronization_and_Semaphores` | `q21_dining_philosophers_sem.c` | C | Classical Dining Philosophers synchronization problem using semaphores |
| **Q22** | `04_Process_Synchronization_and_Semaphores` | `q22_producer_consumer_bounded_buffer_multi.c` | C | Producer-Consumer with bounded buffer: multiple producers & consumers |
| **Q23** | `04_Process_Synchronization_and_Semaphores` | `q23_reader_writer_writer_priority.c` | C | Reader-Writer with Writer Priority using semaphores |
| **Q24** | `09_Network_and_Socket_Programming_Java` | `q24_ConcurrentTCPEchoServer.java`<br>`q24_ConcurrentTCPEchoClient.java` | Java | Concurrent TCP echo server handling multiple clients concurrently |
| **Q25** | `09_Network_and_Socket_Programming_Java` | `q25_UDPServerFileTransfer.java`<br>`q25_UDPClientFileTransfer.java` | Java | UDP file transfer in chunks with Stop-and-Wait ACKs |
| **Q26** | `09_Network_and_Socket_Programming_Java` | `q26_TCPDistributedComputeServer.java`<br>`q26_TCPDistributedComputeClient.java` | Java | Distributed compute server: Factorial, Matrix Multiplication, String Reverse |
| **Q27** | `09_Network_and_Socket_Programming_Java` | `q27_TCPGroupChatServer.java`<br>`q27_TCPGroupChatClient.java` | Java | Multi-user TCP group chat system with broadcast messaging |
| **Q28** | `05_Process_Management` | `q28_fork_five_children.c` | C | `fork()` creates 5 child processes assigning distinct operation to each |
| **Q29** | `05_Process_Management` | `q29_vfork_login_password.c` | C | `vfork()` child reads login name, parent reads password |
| **Q30** | `05_Process_Management` | `q30_fork_launch_app.c` | C | Launch external application using `fork()` and `execvp()` |
| **Q31** | `05_Process_Management` | `q31_vfork_launch_app.c` | C | Launch application using `vfork()` |
| **Q32** | `05_Process_Management` | `q32_fork_wait_parent_child_sync.c` | C | Demonstrate `wait()` with `fork()` for parent-child synchronization |
| **Q33** | `05_Process_Management` | `q33_exec_variants_demo.c` | C | Illustrate 6 variants of exec family (`execl`, `execlp`, `execle`, `execv`, `execvp`, `execvpe`) |
| **Q34** | `05_Process_Management` | `q34_fork_exit_wait_status.c` | C | Demonstrate `exit()` combined with `wait()` and status extraction macros |
| **Q35** | `06_Signals_and_Alarms` | `q35_kill_unrelated_receiver.c`<br>`q35_kill_unrelated_sender.c` | C | `kill()` to send signals between two unrelated processes |
| **Q36** | `06_Signals_and_Alarms` | `q36_kill_related_processes.c` | C | `kill()` to send signals between related processes (`fork`) |
| **Q37** | `06_Signals_and_Alarms` | `q37_alarm_user_input_timeout.c` | C | `alarm()` and `signal()` to require user input within specified time limit |
| **Q38** | `06_Signals_and_Alarms` | `q38_alarm_clock.c` | C | Alarm clock countdown application using `alarm()` and `SIGALRM` handler |
| **Q39** | `07_File_Subsystem_and_Locking` | `q39_file_statistics_stat.c` | C | Report file statistics using `stat()` (permissions, type, size, inode) |
| **Q40** | `07_File_Subsystem_and_Locking` | `q40_file_statistics_fstat.c` | C | Report file statistics using `fstat()` on file descriptor |
| **Q41** | `08_Threads_and_Multithreading` | `q41_MultithreadedChatServer.java`<br>`q41_MultithreadedChatClient.java` | Java | Multithreaded chat application in Java |
| **Q42** | `08_Threads_and_Multithreading` | `q42_three_threads_even_odd_prime.c` | C | Spawn 3 threads: one prints even, second odd, third prime numbers |
| **Q43** | `08_Threads_and_Multithreading` | `q43_pthread_demo_linux.c` | C | Multithreaded program on Linux using POSIX `pthread` library & mutex |
| **Q44** | `08_Threads_and_Multithreading` | `q44_ProducerConsumerJava.java` | Java | Producer-Consumer problem using Java multithreading (`wait`/`notifyAll`) |
| **Q45** | `10_Shell_Scripts_and_Linux_Utilities` | `q45_simple_calculator.sh` | Shell | Shell script menu-driven simple calculator (+, -, *, /, %) |
| **Q46** | `10_Shell_Scripts_and_Linux_Utilities` | `q46_digital_clock.sh` | Shell | Live digital clock with ANSI colors using a shell script |
| **Q47** | `10_Shell_Scripts_and_Linux_Utilities` | `q47_check_network_ping.sh` | Shell | Check system network connectivity using `ping` command |
| **Q48** | `10_Shell_Scripts_and_Linux_Utilities` | `q48_sort_ten_numbers.sh` | Shell | Shell script sorting ten given numbers in ascending order |
| **Q49** | `10_Shell_Scripts_and_Linux_Utilities` | `q49_hello_world_text_effects.sh`<br>`q49_hello_world_ansi_effects.c` | Shell & C | Print "Hello World" with bold, blinking, and colored text effects |
| **Q50** | `10_Shell_Scripts_and_Linux_Utilities` | `q50_check_file_exists.sh` | Shell | Check whether specified file exists in a given folder or drive |
| **Q51** | `10_Shell_Scripts_and_Linux_Utilities` | `q51_disk_partitions_usage.sh` | Shell | Display disk partitions, sizes, mount points, and free space |
| **Q52** | `10_Shell_Scripts_and_Linux_Utilities` | `q52_locate_file.sh` | Shell | Locate a given file on the system using `find` or `locate` |
| **Q53 & Q54** | `10_Shell_Scripts_and_Linux_Utilities` | `q53_54_download_webpage_wget.sh` | Shell | Download a webpage from a given URL using `wget` |
| **Q55** | `10_Shell_Scripts_and_Linux_Utilities` | `q55_display_system_users.sh` | Shell | Display system users using `who`, `w`, and `finger` |
| **Q56** | `10_Shell_Scripts_and_Linux_Utilities` | `q56_recursive_primes.py`<br>`q56_recursive_primes.c` | Python & C | Recursive function generating prime numbers up to a given limit |
| **Q57** | `10_Shell_Scripts_and_Linux_Utilities` | `q57_pyramid_centered_pattern.c` | C | Print centered pyramid pattern with nested loops |
| **Q58** | `10_Shell_Scripts_and_Linux_Utilities` | `q58_word_frequency_counter.c` | C | Count word frequencies in text file using file handling in C |
| **Q59** | `10_Shell_Scripts_and_Linux_Utilities` | `q59_top_five_history_commands.sh` | Shell | Display top five shell commands from history with their counts |
| **Q60** | `10_Shell_Scripts_and_Linux_Utilities` | `q60_check_remove_execute_permission.sh` | Shell | Check if file is executable and remove execute permission |
| **Q61** | `10_Shell_Scripts_and_Linux_Utilities` | `q61_word_freq_wonderland.sh` | Shell | Produce word-frequency list for `wonderland.txt` (tr, sort, uniq) |
| **Q62** | `10_Shell_Scripts_and_Linux_Utilities` | `q62_bash_concatenate_files.sh` | Shell | Bash script validating 2+ arguments and concatenating files |
| **Q63** | `10_Shell_Scripts_and_Linux_Utilities` | `q63_lftp_download_file.sh` | Shell | Download file from remote machine using `lftp` (get/mget) |
| **Q64** | `04_Process_Synchronization_and_Semaphores` | `q64_producer_consumer_posix_semaphore.c` | C | Producer-Consumer problem using POSIX semaphores (`semaphore.h`) |
| **Q65** | `04_Process_Synchronization_and_Semaphores` | `q65_reader_writer_posix_semaphore.c` | C | Reader-Writer problem using POSIX semaphores (`semaphore.h`) |
| **Q66** | `02_Message_Queues` | `q66_msgqueue_three_user_chat.c` | C | Message queues (`msgget`, `msgsnd`, `msgrcv`) chat among 2-3 users |
| **Q67** | `03_Shared_Memory` | `q67_shm_send_az_or_numbers.c` | C | Shared memory IPC: process sends A-Z or 1-100, other receives |
| **Q68** | `03_Shared_Memory` | `q68_shm_file_to_file.c` | C | Read A-Z / 1-100 from file to shm; second process writes to destination file |
| **Q69** | `03_Shared_Memory` | `q69_shm_input_sort_display.c` | C | P1 inputs numbers to shm, P2 sorts and writes back, P3 displays |
| **Q70** | `03_Shared_Memory` | `q70_shm_operations_create_attach_detach_delete.c` | C | Dedicated demonstration of create, attach, detach, and delete shm |
| **Q71** | `10_Shell_Scripts_and_Linux_Utilities` | `q71_simulate_linux_commands.c` | C | Simulates common Linux commands: `cat`, `ls`, `cp`, `mv`, `head` |
| **Q72** | `04_Process_Synchronization_and_Semaphores` | `q72_sem_function_order_f1_before_f2.c` | C | Semaphores enforce execution order: f1() runs before f2() |
| **Q73-76** | `02_Message_Queues` | `q73_to_76_dialog_proc1.c`<br>`q73_to_76_dialog_proc2.c`<br>`q73_to_76_dialog_combined.c` | C | System V msg queue dialog: P1 "Hi?" -> P2 "Hello" -> P1 "I am fine" |
| **Q77** | `09_Network_and_Socket_Programming_Java` | `q77_TCPSocketCallsDemoServer.java`<br>`q77_TCPSocketCallsDemoClient.java` | Java & C | TCP socket system calls demo (socket, bind, listen, accept, read, write) |
| **Q78** | `09_Network_and_Socket_Programming_Java` | `q78_UDPSocketCallsDemoServer.java`<br>`q78_UDPSocketCallsDemoClient.java` | Java & C | UDP socket system calls demo (socket, bind, sendto, recvfrom, close) |
| **Q79** | `09_Network_and_Socket_Programming_Java` | `q79_TCPEchoServer.java`<br>`q79_TCPEchoClient.java` | Java | TCP Echo server using concurrent multithreaded logic |
| **Q80** | `09_Network_and_Socket_Programming_Java` | `q80_UDPEchoServer.java`<br>`q80_UDPEchoClient.java` | Java | UDP Echo server using iterative/concurrent logic |
| **Q81** | `01_Pipes_and_FIFOs` | `q81_unnamed_pipe_data_parent_to_child.c` | C | Unnamed pipe sending data from parent to child |
| **Q82** | `01_Pipes_and_FIFOs` | `q82_unnamed_pipe_file_parent_to_child.c` | C | Unnamed pipe sending an entire file from parent to child |
| **Q83** | `01_Pipes_and_FIFOs` | `q83_pipe_filter_convert_case.c` | C | Pipe filter converting uppercase text to lowercase from command or file |
| **Q84** | `04_Process_Synchronization_and_Semaphores` | `q84_sem_fork_coordination_and_note.c` | C | Semaphore coordination with fork() + Note on `<sys/sem.h>` vs `<semaphore.h>` |
| **Q85** | `04_Process_Synchronization_and_Semaphores` | `q85_1_sem_init.c`<br>`q85_2_sem_wait_p.c`<br>`q85_3_sem_signal_v.c` | C | 3 separate programs on same semaphore: (1) Init, (2) P wait, (3) V signal |
| **Q86** | `07_File_Subsystem_and_Locking` | `q86_file_locking_lockf.c` | C | File record locking demonstration using `lockf()` |
| **Q87** | `07_File_Subsystem_and_Locking` | `q87_file_locking_flock.c` | C | Advisory/exclusive file locking demonstration using `flock()` |

---

## 🛠 Compilation and Execution Instructions

### 1. Compiling C Programs (GCC on Linux/Unix)
Standard compilation:
```bash
gcc -Wall -O2 filename.c -o output_name
./output_name
```
For multithreaded and POSIX semaphore programs (e.g., Q42, Q43, Q64, Q65, Q72):
```bash
gcc -Wall -O2 filename.c -o output_name -lpthread
./output_name
```

### 2. Compiling and Running Java Programs
```bash
javac ProgramName.java
java ProgramName
```
For Client-Server programs, open two separate terminal windows:
- **Terminal 1:** Run the Server (`java ServerProgram`)
- **Terminal 2:** Run the Client (`java ClientProgram`)

### 3. Executing Shell Scripts
```bash
chmod +x script_name.sh
./script_name.sh
```

### 4. Running Python Scripts
```bash
python3 script_name.py
```

---
*Created for TY(IT) Unix Operating System External Practical Examination Preparation.*
